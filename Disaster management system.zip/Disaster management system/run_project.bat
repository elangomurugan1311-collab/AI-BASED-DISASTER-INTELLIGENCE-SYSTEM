@echo off
echo ==================================================================
echo      Aegis 10-Year Disaster Intelligence System - Startup & Reload
echo ==================================================================

:: Clean up any existing instances holding ports 8080 and 8000
echo [CLEANUP] Freeing ports 8080 and 8000 for clean reload...
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":8080" ^| findstr "LISTENING"') do (
    taskkill /f /pid %%a >nul 2>&1
)
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":8000" ^| findstr "LISTENING"') do (
    taskkill /f /pid %%a >nul 2>&1
)
timeout /t 1 >nul

:: Check if Java is installed
javac -version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [WARNING] Java JDK is not installed or not in PATH! Java backend server will not run.
    set RUN_BACKEND=0
) else (
    set RUN_BACKEND=1
)

:: Compile and start Java Backend if available
if "%RUN_BACKEND%"=="1" (
    echo [1/3] Compiling Java Backend Server...
    javac backend\DisasterServer.java
    if %ERRORLEVEL% neq 0 (
        echo [ERROR] Java compilation failed!
        set RUN_BACKEND=0
    ) else (
        echo [2/3] Starting Java Backend on http://localhost:8080...
        start "Aegis Java Backend" java backend.DisasterServer
    )
)

:: Detect Python environment to host server
set PY_CMD=
python --version >nul 2>&1
if %ERRORLEVEL% == 0 (
    set PY_CMD=python
) else (
    py --version >nul 2>&1
    if %ERRORLEVEL% == 0 (
        set PY_CMD=py
    ) else (
        python3 --version >nul 2>&1
        if %ERRORLEVEL% == 0 (
            set PY_CMD=python3
        )
    )
)

if not "%PY_CMD%"=="" (
    echo [3/3] Starting Frontend Server on http://localhost:8000...
    start "Aegis Frontend Web Server" cmd /c "cd frontend && %PY_CMD% -m http.server 8000"
    timeout /t 2 >nul
    echo [LAUNCH] Opening Dashboard at http://localhost:8000/index.html...
    start http://localhost:8000/index.html
) else (
    echo [WARNING] Python is not installed. Fallback to direct file preview...
    timeout /t 2 >nul
    echo [LAUNCH] Opening index.html directly in browser...
    start "" "frontend\index.html"
)

echo ==================================================================
echo Aegis Disaster Intelligence System is successfully launched!
echo ==================================================================
pause

