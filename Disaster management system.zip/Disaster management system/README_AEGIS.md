﻿# AegisAI — Multimodal Disaster Intelligence and Emergency Decision Support System for India

AegisAI is a modular, high-rigor prototype designed for real-time natural hazard surveillance, edge telemetry ingestion from ESP32 portable monitoring devices, multi-hazard risk assessment, and standard operating procedure (SOP) emergency decision support tailored to the Republic of India.

---

## Technical Stack

* **Language & Runtime:** Python 3.10+
* **Dashboard Framework:** Streamlit
* **Data Processing & Analytics:** Pandas, NumPy
* **Data Visualization & Gauges:** Plotly (Express & Graph Objects)
* **Geospatial Intelligence:** Folium & `streamlit-folium` (WGS84 EPSG:4326)
* **Hardware Integration Ready:** REST JSON and MQTT interfaces designed for Espressif ESP32 microcontrollers

---

## Core System Modules

1. **Overview Dashboard:**
   - Consolidated national monitoring status across 13 disaster categories.
   - Summary telemetry indicators for active alerts (Severe, Warning, Watch, Normal).
   - Monitored field node health and hardware link status.
   - Standardized directory aligned with NDMA / IMD criteria.

2. **Multi-Hazard Monitoring (13 Sovereign Domains):**
   - Floods (Riverine, flash flood, and urban inundation)
   - Heavy rainfall (IMD criteria: Heavy, Very Heavy, Extremely Heavy >= 204.5 mm/24h)
   - Cyclones (Bay of Bengal & Arabian Sea RSMC tropical cyclone scales)
   - Earthquakes (Richter magnitude, focal depth, peak ground acceleration in Zones II-V)
   - Landslides (Antecedent rainfall threshold and slope creep displacement)
   - Forest fires (Forest Fire Danger Index - FFDI and MODIS/VIIRS thermal anomalies)
   - Urban fires (MQ-2 smoke particulate density and thermal gradient)
   - Heatwaves (IMD plains departure criteria >= 4.5°C and max temp >= 45°C)
   - Droughts (Standardized Precipitation Index - SPI and soil moisture deficit)
   - Tsunamis (INCOIS bottom pressure recorder telemetry and wave amplitude)
   - Thunderstorms & Lightning (IITM Damini lightning flash density)
   - Extreme cold (Core cold wave zones and minimum temperature thresholds)
   - Industrial and chemical hazards (Major Accident Hazard units and toxic gas dispersion)

3. **Sensor Monitoring (ESP32 Field Gateway):**
   - Micro-station interface measuring:
     - Water level (HC-SR04 / Hydrostatic)
     - Rainfall rate (Tipping bucket pulse counter)
     - Ambient temperature & relative humidity (SHT31 / DHT22)
     - Smoke / combustible gases (MQ-2)
     - Vibration / ground acceleration (MPU-6050 3-axis accelerometer)
   - **Hardware Status:** Disconnected (No physical hardware claimed connected; running in simulated mode).
   - Full Arduino C++ firmware template and JSON telemetry contract provided.

4. **Geospatial Intelligence Map:**
   - Interactive Folium map of India on high-contrast CartoDB tiles.
   - Demonstration incident locations across Indian river basins, hill corridors, and coastlines.
   - Overlay layer for simulated ESP32 field units.
   - Architecture blueprint for live OGC WMS/WFS integration with Bhuvan ISRO, GSI, and NCS.

5. **AI Risk Analysis & Model Registry:**
   - Catalog of hazard-specific models with evaluation benchmarks (AUC-ROC, F1 score, validation datasets).
   - **Rigor Policy:** Uncalibrated models are explicitly flagged as *"Model not configured"*. Unvalidated synthetic numbers are never claimed as true ML probabilities.
   - Explainable rule-based heuristic engineering calculator with explicit feature weights.

6. **Emergency Decision Support:**
   - Chronological standard operating procedures (Pre-disaster, During-disaster, Post-disaster) based on National Disaster Management Authority (NDMA) guidelines.
   - Interactive Incident Action Plan (IAP / SITREP) generator for field commanders.
   - **Disclaimer:** General preparedness recommendations are strictly distinguished from official administrative orders. The prototype does not automatically contact emergency services.

7. **Data Sources & Integration Suite:**
   - Connector directory for Indian sovereign agencies: IMD, NDMA (CAP-India ITU X.1303), INCOIS, CWC (WIMS), NCS, and FSI (Van Agni).
   - Active HTTP ping diagnostics for open endpoints (USGS Seismology, Open-Meteo) verifying live reachability before displaying online badges.

---

## Local Installation & Launch

### Step 1: Install Dependencies
Open a command prompt or terminal in the project directory:
```bash
python -m pip install -r requirements.txt
```

### Step 2: Run the Streamlit Dashboard
```bash
streamlit run app.py
```
*Alternatively on Windows, double-click `run_aegis.bat`.*

### Step 3: Access AegisAI
Open your web browser and navigate to:
```
http://localhost:8501
```

---

## Operational & Ethical Directives

* **Simulated Data Notice:** All telemetry traces, incident locations, and alerts in this prototype are generated from baseline demonstration seeds for engineering evaluation.
* **Hardware Status:** The interface clearly distinguishes between virtual data streams and physical serial/network connections.
* **Emergency Calling:** AegisAI does not automatically dispatch first responders or dial emergency lines (112 / NDRF). Official warnings must be corroborated through authorized district disaster management authorities.

