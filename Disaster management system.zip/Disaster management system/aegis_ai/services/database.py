﻿"""
SQLite Database Service for AegisAI.
Provides persistence for edge devices, validated sensor readings, and alert audit logs.
"""

import sqlite3
import os
import json
from datetime import datetime
from typing import Dict, List, Optional, Any

DB_PATH = os.path.join(os.path.abspath(os.path.dirname(__file__)), "..", "..", "aegis.db")

def get_connection(db_path: str = DB_PATH) -> sqlite3.Connection:
    """Returns a SQLite connection with row factory enabled."""
    conn = sqlite3.connect(db_path, check_same_thread=False, timeout=10.0)
    conn.row_factory = sqlite3.Row
    return conn

def init_database(db_path: str = DB_PATH):
    """Initializes tables for devices, sensor_readings, and alerts."""
    conn = get_connection(db_path)
    cursor = conn.cursor()

    # Devices table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS devices (
        device_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        connection_type TEXT NOT NULL,
        status TEXT NOT NULL,
        last_seen DATETIME,
        ip_address TEXT,
        firmware_version TEXT,
        metadata_json TEXT
    );
    """)

    # Sensor readings table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sensor_readings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id TEXT NOT NULL,
        timestamp DATETIME NOT NULL,
        water_level_cm REAL,
        rainfall_mm_hr REAL,
        temperature_c REAL,
        humidity_pct REAL,
        smoke_ppm REAL,
        vibration_g REAL,
        is_simulated INTEGER DEFAULT 0,
        raw_payload TEXT,
        FOREIGN KEY (device_id) REFERENCES devices(device_id)
    );
    """)

    # Alerts history table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp DATETIME NOT NULL,
        device_id TEXT,
        hazard_type TEXT NOT NULL,
        severity TEXT NOT NULL,
        metric_name TEXT NOT NULL,
        metric_value REAL NOT NULL,
        threshold_value REAL NOT NULL,
        message TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Active'
    );
    """)

    conn.commit()
    conn.close()

def upsert_device(device_id: str, name: str, connection_type: str, status: str,
                  ip_address: Optional[str] = None, firmware_version: Optional[str] = None,
                  metadata: Optional[Dict[str, Any]] = None, db_path: str = DB_PATH):
    """Registers or updates a device record."""
    conn = get_connection(db_path)
    cursor = conn.cursor()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    meta_str = json.dumps(metadata) if metadata else "{}"

    cursor.execute("""
    INSERT INTO devices (device_id, name, connection_type, status, last_seen, ip_address, firmware_version, metadata_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(device_id) DO UPDATE SET
        name=excluded.name,
        connection_type=excluded.connection_type,
        status=excluded.status,
        last_seen=excluded.last_seen,
        ip_address=COALESCE(excluded.ip_address, devices.ip_address),
        firmware_version=COALESCE(excluded.firmware_version, devices.firmware_version),
        metadata_json=excluded.metadata_json;
    """, (device_id, name, connection_type, status, now_str, ip_address, firmware_version, meta_str))

    conn.commit()
    conn.close()

def insert_reading(device_id: str, water_level_cm: float, rainfall_mm_hr: float,
                   temperature_c: float, humidity_pct: float, smoke_ppm: float,
                   vibration_g: float, is_simulated: bool = False,
                   raw_payload: Optional[str] = None, timestamp: Optional[datetime] = None,
                   db_path: str = DB_PATH) -> int:
    """Inserts a validated sensor reading and updates device last_seen."""
    conn = get_connection(db_path)
    cursor = conn.cursor()
    ts_str = (timestamp or datetime.now()).strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute("""
    INSERT INTO sensor_readings (
        device_id, timestamp, water_level_cm, rainfall_mm_hr,
        temperature_c, humidity_pct, smoke_ppm, vibration_g, is_simulated, raw_payload
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    """, (
        device_id, ts_str, water_level_cm, rainfall_mm_hr,
        temperature_c, humidity_pct, smoke_ppm, vibration_g, 1 if is_simulated else 0, raw_payload or ""
    ))

    reading_id = cursor.lastrowid

    # Update device last seen
    dev_status = "simulated" if is_simulated else "connected"
    cursor.execute("""
    UPDATE devices SET last_seen = ?, status = ? WHERE device_id = ?;
    """, (ts_str, dev_status, device_id))

    conn.commit()
    conn.close()
    return reading_id

def insert_alert(hazard_type: str, severity: str, metric_name: str,
                 metric_value: float, threshold_value: float, message: str,
                 device_id: Optional[str] = None, db_path: str = DB_PATH) -> int:
    """Logs an emergency threshold breach alert to the audit history."""
    conn = get_connection(db_path)
    cursor = conn.cursor()
    ts_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute("""
    INSERT INTO alerts (timestamp, device_id, hazard_type, severity, metric_name, metric_value, threshold_value, message, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Active');
    """, (ts_str, device_id or "SYSTEM", hazard_type, severity, metric_name, metric_value, threshold_value, message))

    alert_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return alert_id

def get_devices(db_path: str = DB_PATH, timeout_seconds: int = 30) -> List[Dict[str, Any]]:
    """Returns all registered devices with computed real-time connection status."""
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM devices ORDER BY last_seen DESC;")
    rows = cursor.fetchall()
    conn.close()

    devices = []
    now = datetime.now()

    for r in rows:
        d = dict(r)
        # Re-evaluate live connection if not simulated
        if d["connection_type"] != "simulated" and d["last_seen"]:
            try:
                last_dt = datetime.strptime(d["last_seen"], "%Y-%m-%d %H:%M:%S")
                diff = (now - last_dt).total_seconds()
                if diff > timeout_seconds:
                    d["status"] = "disconnected"
                else:
                    d["status"] = "connected"
            except Exception:
                d["status"] = "disconnected"
        devices.append(d)
    return devices

def get_latest_readings(device_id: Optional[str] = None, limit: int = 50, db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    """Retrieves recent sensor telemetry ordered by timestamp descending."""
    conn = get_connection(db_path)
    cursor = conn.cursor()

    if device_id:
        cursor.execute("""
        SELECT * FROM sensor_readings WHERE device_id = ? ORDER BY id DESC LIMIT ?;
        """, (device_id, limit))
    else:
        cursor.execute("""
        SELECT * FROM sensor_readings ORDER BY id DESC LIMIT ?;
        """, (limit,))

    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_alerts(severity: Optional[str] = None, limit: int = 50, db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    """Retrieves alert history ordered by timestamp descending."""
    conn = get_connection(db_path)
    cursor = conn.cursor()

    if severity and severity != "All":
        cursor.execute("SELECT * FROM alerts WHERE severity = ? ORDER BY id DESC LIMIT ?;", (severity, limit))
    else:
        cursor.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT ?;", (limit,))

    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

# Auto-initialize database schema on module import
init_database()
