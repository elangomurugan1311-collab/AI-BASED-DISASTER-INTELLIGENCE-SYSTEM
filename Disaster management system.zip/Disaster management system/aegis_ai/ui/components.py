﻿"""
Reusable UI components for AegisAI.
Maintains consistent layout, typography, and explicit status labeling.
"""

import streamlit as st
from aegis_ai.config import (
    APP_TITLE,
    APP_SUBTITLE,
    APP_VERSION,
    SIMULATION_NOTICE,
    HARDWARE_NOTICE,
    EMERGENCY_DISCLAIMER
)

def render_header(current_module: str = "Overview"):
    """Renders the top executive header bar with version and current module indicator."""
    st.markdown(
        f"""
        <div class="aegis-header">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap;">
                <div>
                    <h1 class="aegis-title">{APP_TITLE}</h1>
                    <p class="aegis-subtitle">{APP_SUBTITLE}</p>
                </div>
                <div style="text-align: right; margin-top: 4px;">
                    <span class="hazard-pill pill-normal">Active Prototype</span>
                    <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 4px;" class="mono-font">
                        Build: v{APP_VERSION} | Region: India (IN)
                    </div>
                </div>
            </div>
            <div style="margin-top: 12px; padding-top: 10px; border-top: 1px solid #334155; font-size: 0.8rem; color: #cbd5e1;">
                <strong>Current Workspace:</strong> {current_module} &nbsp;|&nbsp; 
                <span class="status-dot dot-yellow"></span> Simulation Baseline: Active &nbsp;|&nbsp;
                <span class="status-dot dot-gray"></span> Physical ESP32 Link: Unbound
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

def render_simulation_banner(extra_detail: str = ""):
    """Renders the mandatory simulated data banner."""
    detail_html = f" &mdash; <em>{extra_detail}</em>" if extra_detail else ""
    st.markdown(
        f"""
        <div class="banner-simulation">
            <div>
                <strong>SIMULATED DATASET:</strong> {SIMULATION_NOTICE}{detail_html}
            </div>
            <span class="hazard-pill pill-watch">DEMO MODE</span>
        </div>
        """,
        unsafe_allow_html=True
    )

def render_hardware_status(connected: bool = False, device_id: str = "ESP32-AEGIS-IN-01"):
    """Displays unambiguous hardware connection status."""
    if connected:
        st.markdown(
            f"""
            <div class="banner-simulation" style="border-left-color: #10b981;">
                <div>
                    <strong>HARDWARE STATUS:</strong> Connected to physical telemetry device <code>{device_id}</code>.
                </div>
                <span class="hazard-pill pill-normal">ONLINE</span>
            </div>
            """,
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            f"""
            <div class="banner-hardware-disconnected">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <strong>HARDWARE STATUS: Disconnected</strong> &mdash; {HARDWARE_NOTICE}
                    </div>
                    <span class="hazard-pill pill-offline">NO PHYSICAL LINK</span>
                </div>
                <div style="font-size: 0.75rem; color: #a1a1aa; margin-top: 6px;">
                    To ingest physical telemetry from an ESP32 micro-station, configure WiFi/LoRa/GSM POST endpoint to <code>/api/v1/sensor-ingest</code>.
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

def render_emergency_disclaimer():
    """Renders the required emergency decision support disclaimer."""
    st.markdown(
        f"""
        <div class="banner-disclaimer">
            <strong>CRITICAL PROTOCOL DISCLAIMER:</strong> {EMERGENCY_DISCLAIMER}
        </div>
        """,
        unsafe_allow_html=True
    )

def render_metric_card(title: str, value: str, subtitle: str = "", status: str = "normal"):
    """Renders a command-center metric card."""
    pill_class = {
        "normal": "pill-normal",
        "watch": "pill-watch",
        "warning": "pill-warning",
        "severe": "pill-severe",
        "offline": "pill-offline"
    }.get(status, "pill-normal")

    st.markdown(
        f"""
        <div class="metric-card">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div class="metric-card-title">{title}</div>
                <span class="hazard-pill {pill_class}">{status.upper()}</span>
            </div>
            <div class="metric-card-value">{value}</div>
            <div class="metric-card-subtitle">{subtitle}</div>
        </div>
        """,
        unsafe_allow_html=True
    )
