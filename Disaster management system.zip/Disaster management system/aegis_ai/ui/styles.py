﻿"""
Custom styling for AegisAI.
Provides a modern, executive command-and-control visual theme.
"""

def get_custom_css() -> str:
    return """
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

        html, body, [class*="css"] {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            letter-spacing: -0.01em;
        }

        code, pre, .mono-font {
            font-family: 'JetBrains Mono', monospace !important;
        }

        /* Top header bar */
        .aegis-header, .sentinel-header {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 20px 24px;
            margin-bottom: 20px;
            color: #f8fafc;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2);
        }

        .aegis-title, .sentinel-title {
            font-size: 1.65rem;
            font-weight: 700;
            color: #ffffff;
            margin: 0;
            line-height: 1.2;
            letter-spacing: -0.02em;
        }

        .aegis-subtitle, .sentinel-subtitle {
            font-size: 0.9rem;
            color: #94a3b8;
            margin-top: 4px;
            margin-bottom: 0;
            font-weight: 400;
        }

        /* Notice & Disclaimer Banners */
        .banner-simulation {
            background-color: #1e293b;
            border-left: 4px solid #38bdf8;
            padding: 10px 14px;
            border-radius: 4px;
            font-size: 0.82rem;
            color: #cbd5e1;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .banner-hardware-disconnected {
            background-color: #27272a;
            border-left: 4px solid #f59e0b;
            padding: 10px 14px;
            border-radius: 4px;
            font-size: 0.82rem;
            color: #e4e4e7;
            margin-bottom: 16px;
        }

        .banner-disclaimer {
            background-color: #1e1e24;
            border-left: 4px solid #ef4444;
            padding: 12px 16px;
            border-radius: 4px;
            font-size: 0.82rem;
            color: #fca5a5;
            margin-top: 20px;
            line-height: 1.4;
        }

        /* Card styling */
        .metric-card {
            background: #182234;
            border: 1px solid #2d3e5a;
            border-radius: 8px;
            padding: 16px 18px;
            color: #f1f5f9;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.15);
            height: 100%;
        }

        .metric-card-title {
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #94a3b8;
            margin-bottom: 6px;
            font-weight: 600;
        }

        .metric-card-value {
            font-size: 1.6rem;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.1;
        }

        .metric-card-subtitle {
            font-size: 0.78rem;
            color: #64748b;
            margin-top: 6px;
        }

        /* Hazard summary badge */
        .hazard-pill {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }

        .pill-normal {
            background-color: #064e3b;
            color: #6ee7b7;
            border: 1px solid #059669;
        }

        .pill-watch {
            background-color: #713f12;
            color: #fde047;
            border: 1px solid #ca8a04;
        }

        .pill-warning {
            background-color: #7c2d12;
            color: #fdba74;
            border: 1px solid #ea580c;
        }

        .pill-severe {
            background-color: #7f1d1d;
            color: #fca5a5;
            border: 1px solid #dc2626;
        }

        .pill-offline {
            background-color: #27272a;
            color: #a1a1aa;
            border: 1px solid #52525b;
        }

        /* Sidebar enhancement */
        [data-testid="stSidebar"] {
            background-color: #0c1322 !important;
            border-right: 1px solid #1e293b;
        }

        /* Table styling */
        .styled-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.85rem;
            margin-top: 10px;
        }

        .styled-table th {
            background-color: #1e293b;
            color: #94a3b8;
            font-weight: 600;
            text-align: left;
            padding: 10px 12px;
            border-bottom: 2px solid #334155;
        }

        .styled-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #1e293b;
            color: #e2e8f0;
        }

        .styled-table tr:hover {
            background-color: #1e293b55;
        }

        /* Status indicator dot */
        .status-dot {
            height: 8px;
            width: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 6px;
        }
        .dot-green { background-color: #10b981; }
        .dot-yellow { background-color: #f59e0b; }
        .dot-red { background-color: #ef4444; }
        .dot-gray { background-color: #94a3b8; }
    </style>
    """
