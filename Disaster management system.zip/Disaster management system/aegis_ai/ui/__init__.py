"""
UI module initialization.
"""
