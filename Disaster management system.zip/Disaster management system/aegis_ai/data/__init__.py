"""
Data layer initialization.
"""
