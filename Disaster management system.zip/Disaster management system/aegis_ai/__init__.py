﻿"""
AegisAI - A Multimodal Disaster Intelligence and Emergency Decision Support System for India.
"""

__version__ = "1.0.0-prototype"
__app_name__ = "AegisAI"
