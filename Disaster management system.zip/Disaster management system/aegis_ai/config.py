﻿"""
Configuration and constants for AegisAI.
Contains hazard definitions, agency mappings, threshold configurations,
and ESP32 hardware telemetry specifications.
"""

APP_TITLE = "AegisAI"
APP_SUBTITLE = "Multimodal Disaster Intelligence and Emergency Decision Support System for India"
APP_VERSION = "1.0.0-Prototype"

# System-wide explicit notices
SIMULATION_NOTICE = "DEMONSTRATION PROTOTYPE: Displayed telemetry and hazard feeds are currently running on simulated baseline data for engineering evaluation."
HARDWARE_NOTICE = "HARDWARE STATUS: Physical ESP32 hardware is not currently bound over serial/network. Running in simulated telemetry mode."
AI_EVALUATION_NOTICE = "RIGOROUS MODEL NOTICE: AegisAI does not invent predictions or display unvalidated scores as real probabilities. If an ML model is untrained or uncalibrated, it is explicitly marked 'Model not configured'."
EMERGENCY_DISCLAIMER = "DECISION SUPPORT NOTICE: AegisAI provides advisory guidance only. This software does not place automatic calls to emergency services and does not supersede official directives issued by the NDMA, SDMA, or District Administration."

# 13 Hazard Categories Supported by AegisAI with scientific metadata
HAZARD_CATEGORIES = {
    "Floods": {
        "id": "flood",
        "nodal_agency": "Central Water Commission (CWC) / NDMA",
        "primary_metric": "River Gauge Height & Basin Discharge",
        "unit": "meters above danger level",
        "vulnerable_regions": ["Assam (Brahmaputra)", "Bihar (Kosi, Gandak)", "Uttar Pradesh (Ganga)", "Odisha (Mahanadi)", "Kerala"],
        "monitoring_sensors": ["Water Level (HC-SR04 / Hydrostatic)", "Basin Rainfall Gauge", "Stream Flow Velocity"],
        "critical_threshold": "River level > 1.5m above danger level or rising > 0.3m/hr",
        "color": "#2563eb"
    },
    "Heavy rainfall": {
        "id": "heavy_rainfall",
        "nodal_agency": "India Meteorological Department (IMD)",
        "primary_metric": "24-Hour Accumulated Rainfall",
        "unit": "mm / 24h",
        "vulnerable_regions": ["Konkan & Goa", "Coastal Karnataka", "Meghalaya (Cherrapunji/Mawsynram)", "Sub-Himalayan West Bengal"],
        "monitoring_sensors": ["Tipping Bucket Rain Gauge", "Optical Rain Detector", "Satellite Radar Reflectivity"],
        "critical_threshold": "Extremely Heavy Rainfall (>= 204.5 mm in 24 hours per IMD standards)",
        "color": "#0284c7"
    },
    "Cyclones": {
        "id": "cyclone",
        "nodal_agency": "IMD Regional Specialized Meteorological Centre (RSMC New Delhi)",
        "primary_metric": "Maximum Sustained Surface Wind Speed (MSW)",
        "unit": "knots (km/h)",
        "vulnerable_regions": ["Odisha Coast", "Andhra Pradesh", "Tamil Nadu", "West Bengal (Sundarbans)", "Gujarat (Saurashtra)"],
        "monitoring_sensors": ["Doppler Weather Radar", "Barometric Pressure (BMP280)", "Anemometer Wind Speed"],
        "critical_threshold": "Very Severe Cyclonic Storm (VSCS >= 64 knots / 118 km/h)",
        "color": "#7c3aed"
    },
    "Earthquakes": {
        "id": "earthquake",
        "nodal_agency": "National Centre for Seismology (NCS) / MoES",
        "primary_metric": "Richter Magnitude & Peak Ground Acceleration (PGA)",
        "unit": "Mw / %g",
        "vulnerable_regions": ["Zone V (Kashmir, Himachal, Uttarakhand, North-East, Rann of Kutch)", "Zone IV (Delhi NCR, Bihar, Northern UP)"],
        "monitoring_sensors": ["3-Axis Accelerometer (MPU-6050 / ADXL345)", "Broadband Seismometer", "GNSS Crustal Strain"],
        "critical_threshold": "Magnitude >= 5.5 in Zone IV/V or PGA > 0.25g",
        "color": "#dc2626"
    },
    "Landslides": {
        "id": "landslide",
        "nodal_agency": "Geological Survey of India (GSI) / NDMA",
        "primary_metric": "Cumulative Antecedent Rainfall & Slope Displacement",
        "unit": "mm / mm displacement",
        "vulnerable_regions": ["Uttarakhand (Chamoli, Rudraprayag)", "Himachal Pradesh (Kinnaur, Shimla)", "Western Ghats (Wayanad, Idukki)", "Sikkim"],
        "monitoring_sensors": ["Borehole Inclinometer", "Soil Moisture TDR Sensor", "Vibration / Acoustic Emissions"],
        "critical_threshold": "Rainfall threshold > 120 mm/48h with slope creep > 5 mm/hr",
        "color": "#b45309"
    },
    "Forest fires": {
        "id": "forest_fire",
        "nodal_agency": "Forest Survey of India (FSI) / MoEFCC",
        "primary_metric": "Forest Fire Danger Index (FFDI) & MODIS Thermal Hotspots",
        "unit": "FFDI Score (0-100)",
        "vulnerable_regions": ["Uttarakhand Garhwal & Kumaon", "Odisha (Similipal)", "Madhya Pradesh", "Chhattisgarh", "Mizoram"],
        "monitoring_sensors": ["Ambient Temperature", "Relative Humidity", "Optical Smoke Detection", "CO/CO2 Gas Sensor"],
        "critical_threshold": "FFDI > 75 (Extreme) with ambient temp > 40°C & humidity < 20%",
        "color": "#ea580c"
    },
    "Urban fires": {
        "id": "urban_fire",
        "nodal_agency": "State Fire & Emergency Services / National Building Code (NBC)",
        "primary_metric": "Smoke Particulate Density & Thermal Gradient",
        "unit": "ppm / °C rise per min",
        "vulnerable_regions": ["Mumbai High-density Wards", "Delhi NCR Commercial Hubs", "Kolkata Congested Markets", "Bengaluru Tech Parks"],
        "monitoring_sensors": ["MQ-2 Combustible Gas & Smoke", "IR Flame Detector", "Thermal Array Grid"],
        "critical_threshold": "Smoke > 450 ppm combined with thermal rise > 5°C/min",
        "color": "#c2410c"
    },
    "Heatwaves": {
        "id": "heatwave",
        "nodal_agency": "India Meteorological Department (IMD)",
        "primary_metric": "Maximum Temperature & Departure from Normal",
        "unit": "°C",
        "vulnerable_regions": ["Rajasthan (Churu, Bikaner)", "Vidarbha (Nagpur)", "Telangana", "Andhra Pradesh (Rayalaseema)", "Delhi NCR"],
        "monitoring_sensors": ["Shielded Thermistor (SHT31 / DS18B20)", "Wet Bulb Globe Temp (WBGT)", "Solar Irradiance"],
        "critical_threshold": "Max Temp >= 45°C in plains or departure >= 4.5°C for 2 consecutive days",
        "color": "#d97706"
    },
    "Droughts": {
        "id": "drought",
        "nodal_agency": "Department of Agriculture and Farmers Welfare (DA&FW) / IMD",
        "primary_metric": "Standardized Precipitation Index (SPI) & Soil Moisture Deficit",
        "unit": "SPI Index (-3 to +3)",
        "vulnerable_regions": ["Marathwada (Maharashtra)", "North Karnataka", "Bundelkhand (UP/MP)", "Western Rajasthan"],
        "monitoring_sensors": ["Multi-depth Soil Moisture Capacitive Sensors", "Evapotranspiration Pyranometer"],
        "critical_threshold": "SPI <= -1.5 (Severe Drought) for 4 consecutive weeks",
        "color": "#854d0e"
    },
    "Tsunamis": {
        "id": "tsunami",
        "nodal_agency": "Indian National Centre for Ocean Information Services (INCOIS)",
        "primary_metric": "Sea Surface Height Anomaly & Bottom Pressure Recorder (BPR)",
        "unit": "meters wave amplitude",
        "vulnerable_regions": ["Andaman & Nicobar Islands", "Tamil Nadu Coast", "Andhra Coast", "Kerala Coast"],
        "monitoring_sensors": ["Deep Ocean BPR Telemetry", "Coastal Tide Gauge Radar", "Coastal Acoustic Doppler"],
        "critical_threshold": "Submarine earthquake Mw >= 6.5 in Indian Ocean subduction zone with BPR anomaly > 0.5m",
        "color": "#0369a1"
    },
    "Thunderstorms": {
        "id": "thunderstorm",
        "nodal_agency": "IMD / Indian Institute of Tropical Meteorology (IITM - Damini)",
        "primary_metric": "Lightning Flash Density & Radar Reflectivity (dBZ)",
        "unit": "flashes/km² / dBZ",
        "vulnerable_regions": ["Odisha (Mayurbhanj, Sundargarh)", "West Bengal (Nor'westers / Kalbaishakhi)", "Jharkhand", "Bihar"],
        "monitoring_sensors": ["Acoustic Lightning Detector", "Atmospheric Electric Field Mill", "Doppler Radar dBZ"],
        "critical_threshold": "Radar reflectivity > 50 dBZ or flash density > 15 strikes/km²/hr",
        "color": "#9333ea"
    },
    "Extreme cold": {
        "id": "extreme_cold",
        "nodal_agency": "India Meteorological Department (IMD)",
        "primary_metric": "Minimum Temperature & Wind Chill Index",
        "unit": "°C",
        "vulnerable_regions": ["Punjab", "Haryana", "Rajasthan", "Jammu & Kashmir", "Ladakh", "Uttar Pradesh"],
        "monitoring_sensors": ["Calibrated Air Thermometer", "Cup Anemometer for Wind Chill"],
        "critical_threshold": "Minimum temp <= 4°C in plains or departure <= -4.5°C",
        "color": "#0891b2"
    },
    "Industrial and chemical hazards": {
        "id": "industrial_chemical",
        "nodal_agency": "Petroleum and Explosives Safety Organization (PESO) / NDMA / MoEFCC",
        "primary_metric": "Toxic Gas Concentration & Emergency Response Planning Guideline (ERPG-2)",
        "unit": "ppm / mg/m³",
        "vulnerable_regions": ["Gujarat Chemical Belt (Dahej, Ankleshwar)", "Visakhapatnam Industrial Corridor", "Manali Industrial Area (Chennai)", "Bhopal Zone"],
        "monitoring_sensors": ["Electrochemical Chlorine/Ammonia Sensors", "Photoionization PID for VOCs", "Ultrasonic Wind Vector"],
        "critical_threshold": "Toxic gas concentration exceeding Immediately Dangerous to Life or Health (IDLH) value",
        "color": "#475569"
    }
}

# ESP32 Portable Disaster Monitoring Device Specifications
ESP32_HARDWARE_SPECS = {
    "microcontroller": "Espressif ESP32-WROOM-32D (Dual-Core 240MHz)",
    "operating_voltage": "3.3V Logic / 5V DC Supply",
    "power_backup": "3.7V 2500mAh Li-Po battery with solar harvesting shield",
    "connectivity_protocols": ["Wi-Fi 802.11 b/g/n", "BLE 4.2", "LoRa 868/915 MHz (SX1276)", "GSM/GPRS SIM800L"],
    "supported_sensors": {
        "water_level": {
            "sensor": "Ultrasonic HC-SR04 / Submersible Hydrostatic Sensor",
            "pin": "Trig: GPIO 5, Echo: GPIO 18",
            "unit": "cm",
            "min_val": 0.0,
            "max_val": 500.0,
            "normal_range": (0.0, 100.0),
            "warning_range": (100.0, 250.0),
            "critical_range": (250.0, 500.0)
        },
        "rainfall": {
            "sensor": "Tipping Bucket Pulse Counter / Analog YL-83",
            "pin": "Interrupt Pin: GPIO 19",
            "unit": "mm/h",
            "min_val": 0.0,
            "max_val": 150.0,
            "normal_range": (0.0, 15.0),
            "warning_range": (15.0, 45.0),
            "critical_range": (45.0, 150.0)
        },
        "temperature": {
            "sensor": "DHT22 / SHT31 High Precision Sensor",
            "pin": "I2C SDA: GPIO 21, SCL: GPIO 22",
            "unit": "°C",
            "min_val": -10.0,
            "max_val": 60.0,
            "normal_range": (15.0, 38.0),
            "warning_range": (38.0, 44.0),
            "critical_range": (44.0, 60.0)
        },
        "humidity": {
            "sensor": "DHT22 / SHT31 Capacitive Relative Humidity",
            "pin": "I2C SDA: GPIO 21, SCL: GPIO 22",
            "unit": "%",
            "min_val": 0.0,
            "max_val": 100.0,
            "normal_range": (30.0, 75.0),
            "warning_range": (75.0, 90.0),
            "critical_range": (90.0, 100.0)
        },
        "smoke": {
            "sensor": "MQ-2 Combustible Gas & Smoke Detector",
            "pin": "Analog ADC1_CH0: GPIO 36 (VP)",
            "unit": "ppm",
            "min_val": 0.0,
            "max_val": 1000.0,
            "normal_range": (0.0, 120.0),
            "warning_range": (120.0, 350.0),
            "critical_range": (350.0, 1000.0)
        },
        "vibration": {
            "sensor": "MPU-6050 6-DoF Accelerometer & Gyroscope",
            "pin": "I2C SDA: GPIO 21, SCL: GPIO 22 (Addr 0x68)",
            "unit": "g-force (RMS)",
            "min_val": 0.0,
            "max_val": 4.0,
            "normal_range": (0.0, 0.08),
            "warning_range": (0.08, 0.25),
            "critical_range": (0.25, 4.0)
        }
    },
    "telemetry_format": {
        "device_id": "ESP32-AEGIS-IN-01",
        "timestamp_epoch": 1716284400,
        "water_level_cm": 42.5,
        "rainfall_mm_hr": 12.0,
        "temperature_c": 29.3,
        "humidity_pct": 74.2,
        "smoke_ppm": 48.0,
        "vibration_g": 0.03,
        "battery_volts": 4.12,
        "rssi_dbm": -68
    }
}

# External Official Data Sources Catalog
DATA_SOURCES_CATALOG = [
    {
        "name": "India Meteorological Department (IMD)",
        "acronym": "IMD",
        "coverage": "Weather, Rainfall, Cyclones, Heatwaves, Cold Waves",
        "official_url": "https://mausam.imd.gov.in",
        "api_spec": "REST JSON / FTP Gridded Data",
        "integration_status": "Ready for API Token Binding",
        "live_tested": False
    },
    {
        "name": "Central Water Commission (CWC)",
        "acronym": "CWC",
        "coverage": "River Basin Gauge Telemetry, Inundation Levels, Reservoir Levels",
        "official_url": "http://cwc.gov.in",
        "api_spec": "National Hydrology Project Portal (WIMS)",
        "integration_status": "Schema Configured",
        "live_tested": False
    },
    {
        "name": "Indian National Centre for Ocean Information Services (INCOIS)",
        "acronym": "INCOIS",
        "coverage": "Tsunami Early Warning, Storm Surges, Ocean State Forecast",
        "official_url": "https://incois.gov.in",
        "api_spec": "CAP / GeoServer WMS",
        "integration_status": "Connector Ready",
        "live_tested": False
    },
    {
        "name": "National Centre for Seismology (NCS)",
        "acronym": "NCS",
        "coverage": "Earthquake Hypocenter, Origin Time, Magnitude Catalog",
        "official_url": "https://seismo.gov.in",
        "api_spec": "RSS / GeoJSON",
        "integration_status": "Connector Ready",
        "live_tested": False
    },
    {
        "name": "Forest Survey of India (FSI)",
        "acronym": "FSI - Van Agni",
        "coverage": "SNPP-VIIRS and MODIS Forest Fire Thermal Anomalies",
        "official_url": "https://fsi.nic.in",
        "api_spec": "Van Agni 2.0 Web Portal / WMS",
        "integration_status": "Schema Configured",
        "live_tested": False
    },
    {
        "name": "USGS Global Earthquake Feed",
        "acronym": "USGS",
        "coverage": "Global & South Asian Seismicity Real-Time GeoJSON",
        "official_url": "https://earthquake.usgs.gov",
        "api_spec": "Public HTTPS GeoJSON",
        "integration_status": "Live Reachability Verified via Ping",
        "live_tested": True
    },
    {
        "name": "Open-Meteo Open Weather API",
        "acronym": "Open-Meteo",
        "coverage": "Global Ensemble Weather, Wind, Rain, Temperature Grid",
        "official_url": "https://open-meteo.com",
        "api_spec": "Public REST JSON API",
        "integration_status": "Live Reachability Verified via Ping",
        "live_tested": True
    }
]
