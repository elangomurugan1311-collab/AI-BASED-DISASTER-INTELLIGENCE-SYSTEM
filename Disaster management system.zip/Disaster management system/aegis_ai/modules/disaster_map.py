﻿"""
Module 4: Disaster Map.
Interactive geospatial intelligence interface for India.
Renders clearly labelled demonstration locations, simulated incident markers,
and prepares the architecture for live GIS / OGC WMS integration.
"""

import streamlit as st
import folium
from folium import plugins
from streamlit_folium import st_folium
from aegis_ai.ui.components import (
    render_header,
    render_simulation_banner,
    render_metric_card
)
from aegis_ai.data.simulated_engine import DEMO_GEOSPATIAL_INCIDENTS

# Simulated ESP32 Field Units coordinates
SIMULATED_FIELD_NODES = [
    {"id": "ESP32-NODE-01", "name": "Brahmaputra Flood Unit", "lat": 26.1850, "lon": 91.7500, "status": "Simulated Active", "sensors": "HC-SR04, Rain, Temp, Hum"},
    {"id": "ESP32-NODE-02", "name": "Chamoli Landslide Sensor", "lat": 30.5600, "lon": 79.5750, "status": "Simulated Active", "sensors": "MPU6050, Rain, Moisture"},
    {"id": "ESP32-NODE-03", "name": "Mahanadi Delta Station", "lat": 20.4625, "lon": 85.8830, "status": "Simulated Active", "sensors": "HC-SR04, Rain, MQ-2"}
]

def render_disaster_map_module():
    render_header(current_module="Geospatial Intelligence Map")
    render_simulation_banner("All map incident locations and markers are synthetic demonstration coordinates.")

    # Top Controls & Filters
    col_f1, col_f2, col_f3 = st.columns([1.2, 1.2, 1.6])
    with col_f1:
        selected_sev = st.multiselect(
            "Filter by Severity",
            ["Severe", "Warning", "Watch", "Normal"],
            default=["Severe", "Warning", "Watch", "Normal"]
        )
    with col_f2:
        layer_nodes = st.checkbox("Show ESP32 Field Units (Simulated)", value=True)
    with col_f3:
        st.markdown(
            """
            <div style="font-size: 0.78rem; color: #94a3b8; padding-top: 6px;">
                <strong>GIS Coordinate Reference:</strong> EPSG:4326 (WGS84)<br>
                Integrated with CartoDB Dark Matter base tiles.
            </div>
            """,
            unsafe_allow_html=True
        )

    # Filter incidents based on selection
    active_incidents = [
        inc for inc in DEMO_GEOSPATIAL_INCIDENTS
        if inc["severity"] in selected_sev
    ]

    # Create Folium Map centered on India (approx lat 22.0, lon 79.0)
    india_map = folium.Map(
        location=[22.5, 82.0],
        zoom_start=5,
        tiles="CartoDB dark_matter",
        control_scale=True
    )

    # Color codes for alert severity
    sev_color_map = {
        "Severe": "red",
        "Warning": "orange",
        "Watch": "beige",
        "Normal": "green"
    }

    # Add Incident Markers
    for inc in active_incidents:
        color = sev_color_map.get(inc["severity"], "blue")
        popup_html = f"""
        <div style="font-family: sans-serif; font-size: 12px; width: 240px; color: #1e293b;">
            <div style="font-size: 13px; font-weight: bold; margin-bottom: 4px;">{inc['hazard']} &mdash; {inc['severity']}</div>
            <div><strong>Location:</strong> {inc['location']}</div>
            <div><strong>Station ID:</strong> <code>{inc['station_id']}</code></div>
            <div><strong>Observed Metric:</strong> {inc['primary_metric']}</div>
            <div><strong>Nodal Agency:</strong> {inc['nodal_agency']}</div>
            <div style="margin-top: 6px; padding-top: 4px; border-top: 1px solid #cbd5e1; font-size: 10px; color: #64748b;">
                <strong>[DEMO DATA]:</strong> {inc['notes']}
            </div>
        </div>
        """
        folium.Marker(
            location=[inc["lat"], inc["lon"]],
            popup=folium.Popup(popup_html, max_width=260),
            tooltip=f"[SIMULATED] {inc['hazard']}: {inc['location']} ({inc['severity']})",
            icon=folium.Icon(color=color, icon="exclamation-sign" if inc["severity"] in ["Severe", "Warning"] else "info-sign")
        ).add_to(india_map)

    # Add Simulated ESP32 Nodes if selected
    if layer_nodes:
        for node in SIMULATED_FIELD_NODES:
            node_popup = f"""
            <div style="font-family: sans-serif; font-size: 12px; width: 220px; color: #1e293b;">
                <div style="font-size: 13px; font-weight: bold; color: #2563eb;">ESP32 Node: {node['id']}</div>
                <div><strong>Station:</strong> {node['name']}</div>
                <div><strong>Telemetry State:</strong> {node['status']}</div>
                <div><strong>Sensors:</strong> {node['sensors']}</div>
                <div style="font-size: 10px; color: #64748b; margin-top: 4px;">Hardware simulation active. No physical link.</div>
            </div>
            """
            folium.CircleMarker(
                location=[node["lat"], node["lon"]],
                radius=8,
                color="#38bdf8",
                fill=True,
                fill_color="#0284c7",
                fill_opacity=0.85,
                popup=folium.Popup(node_popup, max_width=240),
                tooltip=f"ESP32 Micro-Station: {node['id']}"
            ).add_to(india_map)

    # Render Folium Map in Streamlit
    st_folium(india_map, width="100%", height=520)

    st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)

    # Architecture Blueprint for Live GIS Integration
    st.subheader("Geographic & Remote Sensing Integration Architecture")
    st.caption("Roadmap for binding AegisAI to official Indian spatial data infrastructures (SDI).")

    c_g1, c_g2 = st.columns(2)
    with c_g1:
        st.markdown(
            """
            <div class="metric-card">
                <div class="metric-card-title">Supported OGC Standards</div>
                <ul style="font-size: 0.85rem; color: #cbd5e1; margin-top: 8px; padding-left: 20px;">
                    <li><strong>WMS / WMTS:</strong> Bhuvan ISRO Disaster Management Support Services (DMSS) flood inundation layers.</li>
                    <li><strong>WFS:</strong> Geological Survey of India (GSI) National Landslide Susceptibility raster.</li>
                    <li><strong>GeoJSON / Vector Tiles:</strong> NCS Earthquake epicenters and fault-line vectors.</li>
                </ul>
            </div>
            """,
            unsafe_allow_html=True
        )
    with c_g2:
        st.markdown(
            """
            <div class="metric-card">
                <div class="metric-card-title">Verification & Quality Pipeline</div>
                <ul style="font-size: 0.85rem; color: #cbd5e1; margin-top: 8px; padding-left: 20px;">
                    <li><strong>Data Integrity Validation:</strong> Cryptographic SHA-256 checksums on external polygon downloads.</li>
                    <li><strong>Temporal Expiry Checking:</strong> Automatic fallback to offline caches if external feeds drop.</li>
                    <li><strong>Strict Watermarking:</strong> Every raster overlay carries an explicit data providence banner.</li>
                </ul>
            </div>
            """,
            unsafe_allow_html=True
        )
