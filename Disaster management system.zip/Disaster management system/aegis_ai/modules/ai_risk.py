﻿"""
Module 5: AI Risk Analysis.
Modular framework for hazard-specific machine learning models.
Strictly adheres to scientific validation: unconfigured models are explicitly marked,
and demo heuristic indices are not falsely labeled as real probabilities.
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from aegis_ai.ui.components import (
    render_header,
    render_simulation_banner,
    render_metric_card
)
from aegis_ai.config import AI_EVALUATION_NOTICE

# Registered AI / ML Models Catalog
AI_MODELS_REGISTRY = [
    {
        "hazard": "Floods",
        "model_name": "Hydrological LSTM Basin Forecaster",
        "version": "v0.3-alpha",
        "status": "Model not configured",
        "architecture": "Bidirectional LSTM + Attention",
        "training_data": "Pending CWC WIMS 10-Year Catchment Gauge Archive",
        "auc_roc": "N/A",
        "f1_score": "N/A",
        "validation_status": "Uncalibrated - Ingest Pipeline Only",
        "description": "Predicts downstream gauge stage 24 hours ahead using upstream precipitation and soil moisture."
    },
    {
        "hazard": "Cyclones",
        "model_name": "Cyclone Intensity Estimator (Dvorak CNN)",
        "version": "v1.1-offline",
        "status": "Offline Benchmark Prototype",
        "architecture": "ResNet-50 Thermal Anomaly Extractor",
        "training_data": "INSAT-3D Historical Satellite IR Archives (2014-2023)",
        "auc_roc": "0.892",
        "f1_score": "0.841",
        "validation_status": "Validated on Offline Test Set (Non-Operational)",
        "description": "Estimates central pressure deficit and maximum sustained wind velocity from satellite imagery."
    },
    {
        "hazard": "Landslides",
        "model_name": "Spatial Slope Failure Susceptibility Index",
        "version": "v0.1-draft",
        "status": "Model not configured",
        "architecture": "Geospatial Random Forest",
        "training_data": "Awaiting Geological Survey of India (GSI) 1:50k Atlas",
        "auc_roc": "N/A",
        "f1_score": "N/A",
        "validation_status": "Unconfigured",
        "description": "Combines slope gradient, lithology, aspect, and cumulative antecedent rain."
    },
    {
        "hazard": "Earthquakes",
        "model_name": "Epidemic-Type Aftershock Sequence (ETAS)",
        "version": "v0.2-stub",
        "status": "Model not configured",
        "architecture": "Point Process Stochastic Inversion",
        "training_data": "Pending National Centre for Seismology (NCS) Hypocenter Catalog",
        "auc_roc": "N/A",
        "f1_score": "N/A",
        "validation_status": "Unconfigured",
        "description": "Calculates temporal probability density of aftershocks following mainshock Mw >= 5.0."
    },
    {
        "hazard": "Forest fires",
        "model_name": "Dry Biomass Flammability Classifier",
        "version": "v0.9-demo",
        "status": "Demo Heuristic Prototype",
        "architecture": "Extreme Gradient Boosting (XGBoost)",
        "training_data": "MODIS Active Fire History & ERA5 Reanalysis",
        "auc_roc": "0.865",
        "f1_score": "0.812",
        "validation_status": "Simulated Cross-Validation Only",
        "description": "Estimates fire outbreak propensity based on relative humidity, vapor pressure deficit, and canopy temperature."
    },
    {
        "hazard": "Urban fires",
        "model_name": "Structural Fire Propensity Detector",
        "version": "v0.1-stub",
        "status": "Model not configured",
        "architecture": "Edge Temporal CNN",
        "training_data": "Pending Municipal Fire Dept Incident Reports",
        "auc_roc": "N/A",
        "f1_score": "N/A",
        "validation_status": "Unconfigured",
        "description": "Analyzes real-time building electrical load surges and smoke telemetry."
    },
    {
        "hazard": "Heatwaves",
        "model_name": "Urban Heat Island Severe Temperature Regressor",
        "version": "v0.2-stub",
        "status": "Model not configured",
        "architecture": "Bayesian Additive Regression Trees",
        "training_data": "Pending IMD Gridded Temperature Products",
        "auc_roc": "N/A",
        "f1_score": "N/A",
        "validation_status": "Unconfigured",
        "description": "Predicts multi-day temperature anomalies and wet-bulb globe temperature."
    }
]

def render_ai_risk_module():
    render_header(current_module="AI Risk Analysis & Model Registry")
    
    # Rigor Notice Banner
    st.markdown(
        f"""
        <div class="banner-simulation" style="border-left-color: #8b5cf6;">
            <div>
                <strong>SCIENTIFIC RIGOR STANDARD:</strong> {AI_EVALUATION_NOTICE}
            </div>
            <span class="hazard-pill pill-watch">RIGOR POLICY</span>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Model Registry Table
    st.subheader("AegisAI Multimodal Model Registry")
    st.caption("Active status and empirical verification benchmarks of hazard-specific machine learning models.")

    df_models = pd.DataFrame(AI_MODELS_REGISTRY)

    # Render formatted table with status badges
    st.markdown(
        """
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Hazard Category</th>
                    <th>Model Architecture</th>
                    <th>Operational Status</th>
                    <th>AUC-ROC</th>
                    <th>F1 Score</th>
                    <th>Validation Baseline</th>
                </tr>
            </thead>
            <tbody>
        """
        + "".join([
            f"""
            <tr>
                <td><strong>{m['hazard']}</strong></td>
                <td>{m['model_name']} <br><span style='font-size: 0.75rem; color: #94a3b8;'>({m['architecture']} - {m['version']})</span></td>
                <td>
                    <span class="hazard-pill {'pill-normal' if 'Validated' in m['status'] or 'Benchmark' in m['status'] else ('pill-watch' if 'Demo' in m['status'] else 'pill-offline')}">
                        {m['status']}
                    </span>
                </td>
                <td class="mono-font">{m['auc_roc']}</td>
                <td class="mono-font">{m['f1_score']}</td>
                <td style="font-size: 0.8rem; color: #cbd5e1;">{m['validation_status']}</td>
            </tr>
            """ for m in AI_MODELS_REGISTRY
        ])
        + """
            </tbody>
        </table>
        """,
        unsafe_allow_html=True
    )

    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # Interactive Transparent Heuristic Evaluator
    st.subheader("Transparent Risk Scoring Calculator (Rule-Based Engineering Baseline)")
    st.caption("Demonstrates parameter evaluation using verifiable, deterministic engineering rules rather than opaque synthetic probabilities.")

    col_h1, col_h2 = st.columns([1.2, 1.8])
    with col_h1:
        st.markdown("**Hazard Evaluation Mode:**")
        eval_hazard = st.selectbox(
            "Select Hazard Domain for Inspection",
            ["Landslide Slope Failure", "Flash Flood Inundation", "Forest Fire Flammability"]
        )

        if eval_hazard == "Landslide Slope Failure":
            p_slope = st.slider("Slope Angle (°)", 10.0, 75.0, 38.0, 1.0)
            p_rain = st.slider("Antecedent 48h Rain (mm)", 0.0, 250.0, 135.0, 5.0)
            p_lith = st.selectbox("Lithology / Soil Class", ["Gneiss / Solid Rock (Stable)", "Weathered Shale (Moderate)", "Loose Debris / Colluvium (High Vulnerability)"])
            
            # Deterministic Score
            lith_mult = 1.0 if "Stable" in p_lith else (1.4 if "Moderate" in p_lith else 1.9)
            raw_score = (p_slope / 75.0 * 40.0) + (p_rain / 250.0 * 50.0)
            computed_index = min(100.0, raw_score * lith_mult)
            weights = {"Slope Factor": p_slope/75.0 * 40.0, "Rainfall Saturation": p_rain/250.0 * 50.0, "Lithology Multiplier": lith_mult}

        elif eval_hazard == "Flash Flood Inundation":
            p_discharge = st.slider("Basin Discharge Rate (m³/s)", 100.0, 5000.0, 2100.0, 100.0)
            p_capacity = st.slider("Channel Capacity (m³/s)", 500.0, 4000.0, 1800.0, 100.0)
            p_drainage = st.selectbox("Catchment Drainage Health", ["Unobstructed Riparian Floodplain", "Urbanized Silt Choked Channel", "Severely Encroached Drainage"])
            
            drain_mult = 1.0 if "Unobstructed" in p_drainage else (1.3 if "Urbanized" in p_drainage else 1.7)
            ratio = (p_discharge / max(1.0, p_capacity)) * 50.0
            computed_index = min(100.0, ratio * drain_mult)
            weights = {"Discharge vs Capacity": ratio, "Encroachment Factor": drain_mult}

        else:  # Forest Fire Flammability
            p_temp = st.slider("Canopy Air Temp (°C)", 20.0, 48.0, 42.0, 1.0)
            p_rh = st.slider("Relative Humidity (%)", 10.0, 90.0, 18.0, 2.0)
            p_wind = st.slider("Surface Wind Speed (km/h)", 0.0, 60.0, 28.0, 2.0)
            
            computed_index = min(100.0, (p_temp / 48.0 * 40.0) + ((100.0 - p_rh) / 100.0 * 35.0) + (p_wind / 60.0 * 25.0))
            weights = {"Temperature Stress": p_temp/48.0*40.0, "Dryness Deficit": (100.0-p_rh)/100.0*35.0, "Wind Acceleration": p_wind/60.0*25.0}

    with col_h2:
        st.markdown(
            f"""
            <div style="background: #182234; border: 1px solid #334155; border-radius: 8px; padding: 18px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div class="metric-card-title">Computed Heuristic Index</div>
                    <span class="hazard-pill {'pill-severe' if computed_index > 75 else ('pill-warning' if computed_index > 50 else 'pill-normal')}">
                        {'HIGH RISK' if computed_index > 75 else ('ELEVATED' if computed_index > 50 else 'NOMINAL')}
                    </span>
                </div>
                <div style="font-size: 2.4rem; font-weight: 700; color: #ffffff;">{computed_index:.1f} <span style="font-size: 1rem; color: #94a3b8;">/ 100</span></div>
                <div style="font-size: 0.8rem; color: #94a3b8; margin-top: 4px;">
                    <strong>Notice:</strong> This index is an engineering rule-based heuristic score, NOT an ML probabilistic output.
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
        st.caption("Explainable Component Contributions:")
        
        # Plotly horizontal bar showing explainable contribution breakdown
        items = list(weights.items())
        fig_exp = px.bar(
            x=[v if isinstance(v, (int, float)) else 10 for k, v in items],
            y=[k for k, v in items],
            orientation='h',
            labels={"x": "Contribution Weight", "y": ""},
            height=200
        )
        fig_exp.update_layout(
            paper_bgcolor="#182234",
            plot_bgcolor="#182234",
            font_color="#cbd5e1",
            margin=dict(l=10, r=10, t=10, b=30),
            xaxis=dict(showgrid=True, gridcolor="#334155"),
            yaxis=dict(showgrid=False)
        )
        st.plotly_chart(fig_exp, use_container_width=True)
