﻿"""
Module 3: Sensor Monitoring (ESP32 Field Gateway).
Provides an interface for ESP32 micro-stations measuring water level,
rainfall, temperature, humidity, smoke, and vibration.
Strictly differentiates simulated feeds from physical hardware connectivity.
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.subplots as sp
from aegis_ai.ui.components import (
    render_header,
    render_simulation_banner,
    render_hardware_status,
    render_metric_card
)
from aegis_ai.data.simulated_engine import generate_esp32_telemetry_stream
from aegis_ai.config import ESP32_HARDWARE_SPECS

def render_sensor_hub_module():
    render_header(current_module="Sensor Monitoring (ESP32 Gateway)")
    render_simulation_banner("Sensor readings displayed below are generated via the software physics engine.")
    render_hardware_status(connected=False, device_id="ESP32-AEGIS-IN-01")

    # Simulation Controls & Mode Selector
    st.subheader("Hardware Simulation Control Panel")
    st.caption("Inject calibrated physical phenomena to test the edge telemetry pipeline.")

    col_ctrl1, col_ctrl2 = st.columns([1.5, 2.5])
    with col_ctrl1:
        scenario = st.selectbox(
            "Select Telemetry Simulation Scenario",
            [
                "Nominal Baseline",
                "Flash Flood Scenario",
                "Urban Smoke / Fire Event",
                "Seismic Ground Tremor"
            ]
        )
    with col_ctrl2:
        st.markdown(
            """
            <div style="background: #182234; border: 1px solid #334155; border-radius: 6px; padding: 10px 14px; font-size: 0.8rem; color: #94a3b8; margin-top: 4px;">
                <strong>Hardware Interface Mode:</strong> <code>STANDBY_VIRTUAL_STREAM</code><br>
                Payload Schema: <code>ISO-8601 UTC+05:30 / Microcontroller ADC Calibration v1.2</code>
            </div>
            """,
            unsafe_allow_html=True
        )

    # Generate telemetry for selected scenario
    stream = generate_esp32_telemetry_stream(scenario=scenario, num_points=60)
    snap = stream["snapshot"]
    hist = stream["history"]

    st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)

    # Live Gauges & Current Readings for 6 mandatory sensors
    st.subheader("Real-Time Telemetry Snapshot (Simulated Stream)")
    
    c1, c2, c3, c4, c5, c6 = st.columns(6)
    with c1:
        st_water = "severe" if snap["water_level_cm"] > 250 else ("warning" if snap["water_level_cm"] > 100 else "normal")
        render_metric_card("Water Level", f"{snap['water_level_cm']} cm", "Ultrasonic HC-SR04", st_water)
    with c2:
        st_rain = "severe" if snap["rainfall_mm_hr"] > 45 else ("warning" if snap["rainfall_mm_hr"] > 15 else "normal")
        render_metric_card("Rainfall Rate", f"{snap['rainfall_mm_hr']} mm/h", "Pulse Tipping Gauge", st_rain)
    with c3:
        st_temp = "severe" if snap["temperature_c"] > 44 else ("warning" if snap["temperature_c"] > 38 else "normal")
        render_metric_card("Ambient Temp", f"{snap['temperature_c']} °C", "SHT31 Calibrated", st_temp)
    with c4:
        st_hum = "warning" if snap["humidity_pct"] > 85 else "normal"
        render_metric_card("Humidity", f"{snap['humidity_pct']} %", "Capacitive RH", st_hum)
    with c5:
        st_smoke = "severe" if snap["smoke_ppm"] > 350 else ("warning" if snap["smoke_ppm"] > 120 else "normal")
        render_metric_card("Smoke Level", f"{snap['smoke_ppm']} ppm", "MQ-2 Gas / Aerosol", st_smoke)
    with c6:
        st_vib = "severe" if snap["vibration_g"] > 0.25 else ("warning" if snap["vibration_g"] > 0.08 else "normal")
        render_metric_card("Vibration RMS", f"{snap['vibration_g']} g", "MPU-6050 3-Axis", st_vib)

    st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)

    # Telemetry Multi-Trace Historical Visualizer
    st.subheader("High-Frequency Sensor Channels (Last 60 Intervals)")
    st.caption("Sub-minute telemetry stream buffered from virtual ESP32 device.")

    fig = sp.make_subplots(
        rows=2, cols=3,
        subplot_titles=(
            "Water Level (cm)", "Rainfall Rate (mm/h)", "Temperature (°C)",
            "Relative Humidity (%)", "Smoke / Particulate (ppm)", "Vibration (g-force RMS)"
        ),
        vertical_spacing=0.15,
        horizontal_spacing=0.08
    )

    fig.add_trace(go.Scatter(x=hist["Timestamp"], y=hist["Water_Level_cm"], line=dict(color="#3b82f6", width=2)), row=1, col=1)
    fig.add_trace(go.Scatter(x=hist["Timestamp"], y=hist["Rainfall_mm_hr"], line=dict(color="#06b6d4", width=2)), row=1, col=2)
    fig.add_trace(go.Scatter(x=hist["Timestamp"], y=hist["Temperature_C"], line=dict(color="#f97316", width=2)), row=1, col=3)
    fig.add_trace(go.Scatter(x=hist["Timestamp"], y=hist["Humidity_pct"], line=dict(color="#10b981", width=2)), row=2, col=1)
    fig.add_trace(go.Scatter(x=hist["Timestamp"], y=hist["Smoke_ppm"], line=dict(color="#f43f5e", width=2)), row=2, col=2)
    fig.add_trace(go.Scatter(x=hist["Timestamp"], y=hist["Vibration_g"], line=dict(color="#a855f7", width=2)), row=2, col=3)

    fig.update_layout(
        paper_bgcolor="#182234",
        plot_bgcolor="#111827",
        font_color="#cbd5e1",
        showlegend=False,
        height=480,
        margin=dict(l=20, r=20, t=35, b=25)
    )
    fig.update_xaxes(showgrid=True, gridcolor="#1f2937", tickangle=-30)
    fig.update_yaxes(showgrid=True, gridcolor="#1f2937")

    st.plotly_chart(fig, use_container_width=True)

    st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)

    # Hardware Integration Architecture & Technical Blueprint
    st.subheader("Physical ESP32 Device Integration Blueprint")
    st.caption("Production hardware specification for interfacing field devices with AegisAI.")

    tab_schema, tab_c, tab_specs = st.tabs(["Telemetry JSON Contract", "ESP32 C++ Firmware Snippet", "GPIO Pinout Mapping"])

    with tab_schema:
        st.markdown(
            """
            The ESP32 communicates with AegisAI by issuing an HTTP `POST` to `/api/v1/sensor-ingest` 
            or publishing over MQTT topic `aegis/telemetry/<device_id>`.
            """
        )
        st.code(
            """{
  "device_id": "ESP32-AEGIS-IN-01",
  "firmware_version": "v1.2.0-esp32-freertos",
  "timestamp_epoch": 1716284400,
  "battery_voltage": 4.12,
  "wifi_rssi_dbm": -68,
  "sensors": {
    "water_level_cm": 42.5,
    "rainfall_mm_hr": 12.0,
    "temperature_c": 29.3,
    "humidity_pct": 74.2,
    "smoke_ppm": 48.0,
    "vibration_g": 0.03
  },
  "self_diagnostics": {
    "adc_calibrated": true,
    "i2c_bus_ok": true,
    "sd_card_mounted": true
  }
}""",
            language="json"
        )

    with tab_c:
        st.markdown("Minimal non-blocking Arduino/ESP-IDF HTTP client template for field deployments:")
        st.code(
            """#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

const char* ssid = "AEGIS_FIELD_NET";
const char* password = "DEVICE_SECURE_KEY";
const char* serverUrl = "http://aegisai.internal/api/v1/sensor-ingest";

void setup() {
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
  Serial.println("ESP32 Connected to Aegis Gateway");
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(serverUrl);
    http.addHeader("Content-Type", "application/json");

    StaticJsonDocument<256> doc;
    doc["device_id"] = "ESP32-AEGIS-IN-01";
    doc["water_level_cm"] = readUltrasonic();
    doc["rainfall_mm_hr"] = readRainGauge();
    doc["temperature_c"] = readTemp();
    doc["humidity_pct"] = readHumidity();
    doc["smoke_ppm"] = readMQ2();
    doc["vibration_g"] = readMPU6050();

    String requestBody;
    serializeJson(doc, requestBody);
    int httpResponseCode = http.POST(requestBody);
    http.end();
  }
  delay(5000); // 5-second sampling cadence
}""",
            language="cpp"
        )

    with tab_specs:
        st.markdown("**Hardware Platform Specifications:**")
        st.markdown(f"- **MCU:** {ESP32_HARDWARE_SPECS['microcontroller']}")
        st.markdown(f"- **Power Supply:** {ESP32_HARDWARE_SPECS['power_backup']}")
        st.markdown(f"- **Supported Links:** {', '.join(ESP32_HARDWARE_SPECS['connectivity_protocols'])}")
        
        specs_rows = []
        for s_key, s_data in ESP32_HARDWARE_SPECS["supported_sensors"].items():
            specs_rows.append({
                "Measurement": s_key.replace("_", " ").title(),
                "Sensor Model": s_data["sensor"],
                "ESP32 Pin Interface": s_data["pin"],
                "Safe Operating Range": f"{s_data['normal_range'][0]} - {s_data['normal_range'][1]} {s_data['unit']}",
                "Critical Threshold": f"> {s_data['critical_range'][0]} {s_data['unit']}"
            })
        st.table(specs_rows)
