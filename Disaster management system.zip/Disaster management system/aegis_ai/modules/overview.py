﻿"""
Module 1: Overview Dashboard.
Displays consolidated disaster monitoring status, supported categories,
telemetry connectivity, and active simulated alert tallies.
"""

import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from aegis_ai.ui.components import (
    render_header,
    render_simulation_banner,
    render_hardware_status,
    render_metric_card
)
from aegis_ai.data.simulated_engine import (
    get_hazard_summary_dataframe,
    DEMO_GEOSPATIAL_INCIDENTS
)
from aegis_ai.config import HAZARD_CATEGORIES

def render_overview_module():
    render_header(current_module="Overview Dashboard")
    render_simulation_banner("Consolidated multi-hazard status generated from baseline demonstration seeds.")
    render_hardware_status(connected=False, device_id="ESP32-AEGIS-IN-01")

    # High-level Summary Metrics Cards
    total_categories = len(HAZARD_CATEGORIES)
    monitored_nodes = len(DEMO_GEOSPATIAL_INCIDENTS)
    severe_count = sum(1 for inc in DEMO_GEOSPATIAL_INCIDENTS if inc["severity"] == "Severe")
    warning_count = sum(1 for inc in DEMO_GEOSPATIAL_INCIDENTS if inc["severity"] == "Warning")
    watch_count = sum(1 for inc in DEMO_GEOSPATIAL_INCIDENTS if inc["severity"] == "Watch")

    col1, col2, col3, col4, col5 = st.columns(5)
    with col1:
        render_metric_card("Hazard Classes", f"{total_categories}", "Full Multimodal Coverage", "normal")
    with col2:
        render_metric_card("Monitored Zones", f"{monitored_nodes}", "Simulated Field Nodes", "normal")
    with col3:
        render_metric_card("Severe Alerts", f"{severe_count}", "IMD / CWC Threshold Breached", "severe" if severe_count > 0 else "normal")
    with col4:
        render_metric_card("Warning States", f"{warning_count}", "Operational Action Advisory", "warning" if warning_count > 0 else "normal")
    with col5:
        render_metric_card("Watch States", f"{watch_count}", "Enhanced Sensor Surveillance", "watch")

    st.markdown("<div style='height: 18px;'></div>", unsafe_allow_html=True)

    # Two column layout: Hazard Distribution Chart + Live Simulated Ticker
    c_left, c_right = st.columns([1.1, 0.9])

    with c_left:
        st.subheader("Disaster Alert Matrix by Hazard Category")
        st.caption("Distribution of current simulated threat evaluations across 13 monitored domains.")

        df_summary = get_hazard_summary_dataframe()
        
        # Color mapping for severity
        color_discrete = {
            "Severe": "#ef4444",
            "Warning": "#f97316",
            "Watch": "#eab308",
            "Normal": "#10b981"
        }

        fig = px.bar(
            df_summary,
            x="Disaster Category",
            y=[1]*len(df_summary),
            color="Current Alert Level",
            color_discrete_map=color_discrete,
            labels={"y": "Count", "Disaster Category": ""},
            height=340
        )
        fig.update_layout(
            paper_bgcolor="#182234",
            plot_bgcolor="#182234",
            font_color="#cbd5e1",
            margin=dict(l=10, r=10, t=10, b=40),
            yaxis=dict(showticklabels=False, showgrid=False),
            xaxis=dict(tickangle=-40, showgrid=False),
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1,
                title_text=""
            )
        )
        st.plotly_chart(fig, use_container_width=True)

    with c_right:
        st.subheader("Field Node Health & Link Status")
        st.caption("Hardware abstraction layer ready for ESP32 micro-station streaming.")

        node_data = [
            {"Node": "ESP32-NODE-01 (Guwahati)", "Interface": "Virtual Serial", "Status": "Simulation Active", "Health": "100%"},
            {"Node": "ESP32-NODE-02 (Dehradun)", "Interface": "Virtual MQTT", "Status": "Simulation Active", "Health": "100%"},
            {"Node": "ESP32-NODE-03 (Cuttack)", "Interface": "Virtual LoRa", "Status": "Simulation Active", "Health": "100%"},
            {"Node": "ESP32-NODE-04 (Bhuj)", "Interface": "Unbound", "Status": "Offline / Standby", "Health": "0%"},
            {"Node": "ESP32-NODE-05 (Dahej)", "Interface": "Unbound", "Status": "Offline / Standby", "Health": "0%"},
        ]
        
        st.markdown(
            """
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Node ID & Location</th>
                        <th>Telemetry Link</th>
                        <th>Ingest State</th>
                    </tr>
                </thead>
                <tbody>
            """
            + "".join([
                f"""
                <tr>
                    <td><strong>{n['Node']}</strong></td>
                    <td class="mono-font">{n['Interface']}</td>
                    <td>
                        <span class="status-dot {'dot-green' if 'Active' in n['Status'] else 'dot-gray'}"></span>
                        <span class="hazard-pill {'pill-watch' if 'Active' in n['Status'] else 'pill-offline'}">{n['Status']}</span>
                    </td>
                </tr>
                """ for n in node_data
            ])
            + """
                </tbody>
            </table>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)

    # Master Table of all 13 Supported Categories
    st.subheader("Supported Disaster Categories Directory")
    st.caption("Standardized against NDMA Hazard Guidelines & IMD Early Warning Protocols.")

    # Filter controls
    col_f1, col_f2 = st.columns([1, 2])
    with col_f1:
        selected_level = st.selectbox(
            "Filter by Alert Level",
            ["All Alert Levels", "Severe", "Warning", "Watch", "Normal"]
        )

    filtered_df = df_summary.copy()
    if selected_level != "All Alert Levels":
        filtered_df = filtered_df[filtered_df["Current Alert Level"] == selected_level]

    st.dataframe(
        filtered_df[[
            "Disaster Category",
            "Nodal Agency",
            "Current Alert Level",
            "Primary Metric",
            "Key Vulnerable Zones",
            "Operational Status"
        ]],
        use_container_width=True,
        hide_index=True
    )
