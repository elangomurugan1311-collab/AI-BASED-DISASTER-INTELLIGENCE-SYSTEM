﻿"""
Module 7: Data Sources.
Integration suite for official Indian and global meteorological and disaster monitoring agencies.
Strictly verifies actual network connectivity before claiming any external data is live.
"""

import streamlit as st
import requests
import time
from aegis_ai.ui.components import (
    render_header,
    render_simulation_banner,
    render_metric_card
)
from aegis_ai.config import DATA_SOURCES_CATALOG

def test_endpoint_reachability(url: str, timeout: int = 3) -> dict:
    """Verifies HTTP connectivity to an external endpoint with latency measurement."""
    try:
        t0 = time.time()
        resp = requests.get(url, timeout=timeout)
        latency = round((time.time() - t0) * 1000, 1)
        if resp.status_code == 200:
            return {"status": "Verified Online", "code": resp.status_code, "latency_ms": latency, "error": None}
        else:
            return {"status": f"HTTP {resp.status_code}", "code": resp.status_code, "latency_ms": latency, "error": None}
    except Exception as e:
        return {"status": "Connection Failed / Unreachable", "code": None, "latency_ms": None, "error": str(e)}

def render_data_sources_module():
    render_header(current_module="Official Data Sources & Integration Suite")
    render_simulation_banner("Unverified external feeds are marked 'Pending Token/Binding' per AegisAI policy.")

    st.subheader("Official Disaster & Meteorological Integration Directory")
    st.caption("Registry of sovereign and multilateral data providers supported by AegisAI.")

    # Live Connectivity Verification Suite
    st.markdown("#### Live Connectivity Diagnostics")
    st.caption("Click to run an active HTTP handshake test against public open endpoints. Only successful connections are labeled 'Live'.")

    col_btn, col_info = st.columns([1, 2])
    run_test = False
    with col_btn:
        if st.button("Run Live Handshake Diagnostics", type="primary"):
            run_test = True

    if run_test:
        with st.spinner("Pinging verified endpoints..."):
            # Ping USGS Public Seismology Feed
            usgs_res = test_endpoint_reachability("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson", timeout=3)
            # Ping Open-Meteo Public Weather Feed
            meteo_res = test_endpoint_reachability("https://api.open-meteo.com/v1/forecast?latitude=28.61&longitude=77.20&current_weather=true", timeout=3)

            col_res1, col_res2 = st.columns(2)
            with col_res1:
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-card-title">USGS Seismology Feed</div>
                        <div style="font-size: 1.2rem; font-weight: 700; color: {'#10b981' if usgs_res['code'] == 200 else '#ef4444'};">
                            {usgs_res['status']}
                        </div>
                        <div style="font-size: 0.8rem; color: #94a3b8; margin-top: 4px;">
                            Latency: {usgs_res['latency_ms'] or 'N/A'} ms | Code: {usgs_res['code'] or 'ERR'}
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            with col_res2:
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-card-title">Open-Meteo Global Weather</div>
                        <div style="font-size: 1.2rem; font-weight: 700; color: {'#10b981' if meteo_res['code'] == 200 else '#ef4444'};">
                            {meteo_res['status']}
                        </div>
                        <div style="font-size: 0.8rem; color: #94a3b8; margin-top: 4px;">
                            Latency: {meteo_res['latency_ms'] or 'N/A'} ms | Code: {meteo_res['code'] or 'ERR'}
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

    st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)

    # Master Table of Data Sources
    st.subheader("Agency Ingestion Status & Specification Catalog")
    st.caption("Standardized against Common Alerting Protocol (CAP - ITU X.1303) and WMO Guidelines.")

    st.markdown(
        """
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Agency & Acronym</th>
                    <th>Domain Coverage</th>
                    <th>API Architecture</th>
                    <th>Live Binding Status</th>
                    <th>Official Portal</th>
                </tr>
            </thead>
            <tbody>
        """
        + "".join([
            f"""
            <tr>
                <td><strong>{src['name']}</strong> ({src['acronym']})</td>
                <td>{src['coverage']}</td>
                <td class="mono-font">{src['api_spec']}</td>
                <td>
                    <span class="hazard-pill {'pill-normal' if src['live_tested'] else 'pill-watch'}">
                        {src['integration_status']}
                    </span>
                </td>
                <td><a href="{src['official_url']}" target="_blank" style="color: #38bdf8; text-decoration: none;">Link ↗</a></td>
            </tr>
            """ for src in DATA_SOURCES_CATALOG
        ])
        + """
            </tbody>
        </table>
        """,
        unsafe_allow_html=True
    )

    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # Technical Integration Guide for Official Indian Feeds
    st.subheader("Official Ingestion Protocol Specifications")
    st.caption("Detailed schemas for binding official national portals.")

    t_cap, t_cwc, t_imd = st.tabs(["NDMA CAP-India Feed (ITU X.1303)", "CWC WIMS Basin Telemetry", "IMD Gridded Weather Products"])

    with t_cap:
        st.markdown(
            """
            **Common Alerting Protocol (CAP - India):**
            National Disaster Management Authority (NDMA) operates the Integrated Alert Dissemination Platform 
            using the ITU X.1303 OASIS standard. AegisAI's XML ingestion engine parses alert envelopes with the following schema:
            """
        )
        st.code(
            """<?xml version="1.0" encoding="UTF-8"?>
<alert xmlns="urn:oasis:names:tc:emergency:cap:1.2">
  <identifier>NDMA-IN-ALERT-2026-08192</identifier>
  <sender>imd_rsmc_delhi@imd.gov.in</sender>
  <sent>2026-10-21T06:30:00+05:30</sent>
  <status>Actual</status>
  <msgType>Alert</msgType>
  <scope>Public</scope>
  <info>
    <category>Met</category>
    <event>Severe Cyclonic Storm</event>
    <urgency>Immediate</urgency>
    <severity>Severe</severity>
    <certainty>Observed</certainty>
    <headline>Very Severe Cyclonic Storm Warning for Odisha Coast</headline>
    <area>
      <areaDesc>Puri, Jagatsinghpur, Kendrapara Districts</areaDesc>
      <circle>20.31,86.61,75.0</circle>
    </area>
  </info>
</alert>""",
            language="xml"
        )

    with t_cwc:
        st.markdown(
            """
            **Central Water Commission - Water Resources Information System (WIMS):**
            River stage gauges broadcast hourly telemetry with reference to site-specific High Flood Level (HFL) and Warning Level:
            - **REST Endpoint:** `https://wims.cwc.gov.in/api/v1/telemetry/station/{station_id}`
            - **Authentication:** HMAC SHA-256 with Ministry of Jal Shakti API Key
            - **Payload:** Station ID, River Basin, Stage Height (m), Discharge (m³/s), Battery Voltage
            """
        )

    with t_imd:
        st.markdown(
            """
            **India Meteorological Department (IMD) AWS & Gridded Feeds:**
            Automatic Weather Stations (AWS) transmit half-hourly data packages via INSAT-3DR DCP (Data Collection Platforms):
            - **Parameters:** Rainfall, Max/Min Temp, Station Pressure, Wind Direction & Speed, Relative Humidity
            - **Quality Control:** Automated Range Verification, Spike Detection, Step Test per WMO-No. 8
            """
        )
