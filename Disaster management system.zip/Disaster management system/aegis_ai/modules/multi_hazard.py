﻿"""
Module 2: Multi-Hazard Monitoring.
Detailed multi-hazard surveillance across all 13 distinct hazard domains in India.
Each hazard features scientific threshold tracking, simulated 14-day time series,
and rule-based parameter testing.
"""

import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from aegis_ai.ui.components import (
    render_header,
    render_simulation_banner,
    render_metric_card
)
from aegis_ai.data.simulated_engine import get_hazard_time_series
from aegis_ai.config import HAZARD_CATEGORIES

def render_multi_hazard_module():
    render_header(current_module="Multi-Hazard Monitoring")
    render_simulation_banner("Time-series telemetry and parameter scenarios are simulated using IMD / CWC baseline scales.")

    # Category Selector
    hazard_names = list(HAZARD_CATEGORIES.keys())
    
    col_sel, col_info = st.columns([1.2, 2.8])
    with col_sel:
        selected_hazard = st.selectbox(
            "Select Disaster Category",
            hazard_names,
            index=0,
            help="Select one of the 13 supported Indian multi-hazard domains."
        )

    hazard_meta = HAZARD_CATEGORIES[selected_hazard]

    with col_info:
        st.markdown(
            f"""
            <div style="background: #182234; border: 1px solid #334155; border-radius: 8px; padding: 12px 16px; margin-top: 4px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-weight: 700; color: #ffffff; font-size: 1.05rem;">{selected_hazard}</span>
                    <span class="hazard-pill" style="background-color: {hazard_meta['color']}33; color: {hazard_meta['color']}; border: 1px solid {hazard_meta['color']};">
                        {hazard_meta['nodal_agency']}
                    </span>
                </div>
                <div style="font-size: 0.82rem; color: #94a3b8; margin-top: 4px;">
                    <strong>Primary Metric:</strong> {hazard_meta['primary_metric']} &nbsp;|&nbsp; 
                    <strong>Critical Standard:</strong> {hazard_meta['critical_threshold']}
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)

    # 14-day Time-Series Chart
    st.subheader(f"14-Day Observed Telemetry Trend: {selected_hazard}")
    st.caption(f"Historical trajectory relative to official warning and critical thresholds (Simulated Data: {hazard_meta['unit']}).")

    df_series = get_hazard_time_series(selected_hazard, days=14)

    fig = go.Figure()

    # Observed simulated line
    fig.add_trace(go.Scatter(
        x=df_series["Timestamp"],
        y=df_series["Observed_Metric"],
        mode='lines+markers',
        name='Observed (Simulated)',
        line=dict(color='#38bdf8', width=2.5),
        marker=dict(size=4)
    ))

    # Warning Threshold Line
    warn_val = df_series["Warning_Threshold"].iloc[0]
    fig.add_trace(go.Scatter(
        x=df_series["Timestamp"],
        y=[warn_val] * len(df_series),
        mode='lines',
        name=f'Warning Threshold ({warn_val})',
        line=dict(color='#f59e0b', width=1.8, dash='dash')
    ))

    # Critical Threshold Line
    crit_val = df_series["Critical_Threshold"].iloc[0]
    fig.add_trace(go.Scatter(
        x=df_series["Timestamp"],
        y=[crit_val] * len(df_series),
        mode='lines',
        name=f'Critical Threshold ({crit_val})',
        line=dict(color='#ef4444', width=2, dash='dot')
    ))

    fig.update_layout(
        paper_bgcolor="#182234",
        plot_bgcolor="#111827",
        font_color="#cbd5e1",
        height=380,
        margin=dict(l=20, r=20, t=20, b=30),
        xaxis=dict(showgrid=True, gridcolor="#1f2937"),
        yaxis=dict(
            title=f"Metric Value ({df_series['Unit'].iloc[0]})",
            showgrid=True,
            gridcolor="#1f2937"
        ),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )

    st.plotly_chart(fig, use_container_width=True)

    st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)

    # In-depth Breakdown: Scientific Reference Standards + Regional Hotspots
    col_tech, col_sim = st.columns([1.1, 0.9])

    with col_tech:
        st.subheader("Standard Operating Metrics & Protocols")
        st.markdown(f"**Lead Agency:** {hazard_meta['nodal_agency']}")
        st.markdown(f"**Vulnerable Indian States/Basins:**")
        for region in hazard_meta["vulnerable_regions"]:
            st.markdown(f"- {region}")

        st.markdown(f"**Recommended Field Sensors & Telemetries:**")
        for sensor in hazard_meta["monitoring_sensors"]:
            st.markdown(f"- `{sensor}`")

    with col_sim:
        st.subheader("Interactive Threshold Simulator")
        st.caption("Simulate environmental parameters to test rule-based risk classification.")

        # Dynamic parameter controls tailored to the selected hazard
        if selected_hazard == "Floods":
            test_val = st.slider("River Level Relative to Danger Mark (m)", -2.0, 4.0, 1.2, 0.1)
            st.caption("Warning Threshold: +0.5m | Danger Mark: +1.5m")
            if test_val >= 1.5:
                status = ("SEVERE INUNDATION WARNING", "severe", "Deploy NDRF / SDRF units and evacuate low-lying riparian settlements.")
            elif test_val >= 0.5:
                status = ("RISING STAGE WATCH", "warning", "Continuous 15-minute gauge tracking; alert district disaster management cell.")
            else:
                status = ("NORMAL BASIN FLOW", "normal", "Safe hydrological baseline flow.")
        elif selected_hazard == "Heavy rainfall":
            test_val = st.slider("24-Hour Rainfall Accumulation (mm)", 0.0, 300.0, 140.0, 5.0)
            st.caption("IMD Criteria: Heavy (64.5-115.5mm) | Very Heavy (115.6-204.4mm) | Extremely Heavy (>=204.5mm)")
            if test_val >= 204.5:
                status = ("EXTREMELY HEAVY RAINFALL (RED ALERT)", "severe", "High risk of localized urban flash flooding and hill slope failures.")
            elif test_val >= 115.6:
                status = ("VERY HEAVY RAINFALL (ORANGE ALERT)", "warning", "Waterlogging alert; prepare pumps in municipal underpasses.")
            elif test_val >= 64.5:
                status = ("HEAVY RAINFALL (YELLOW WATCH)", "watch", "General advisory for vulnerable sectors.")
            else:
                status = ("LIGHT TO MODERATE RAIN (GREEN)", "normal", "Routine precipitation within seasonal baseline.")
        elif selected_hazard == "Cyclones":
            test_val = st.slider("Maximum Sustained Wind Speed (km/h)", 30.0, 250.0, 95.0, 5.0)
            if test_val >= 222:
                status = ("SUPER CYCLONIC STORM (SuCS)", "severe", "Catastrophic damage expected. Total coastal evacuation.")
            elif test_val >= 118:
                status = ("VERY SEVERE CYCLONIC STORM (VSCS)", "severe", "Extensive structural damage. Suspension of port operations.")
            elif test_val >= 62:
                status = ("CYCLONIC STORM (CS)", "warning", "Fishermen warning; alert coastal shelters.")
            else:
                status = ("DEPRESSION / LOW PRESSURE", "normal", "Squally weather monitoring.")
        elif selected_hazard == "Earthquakes":
            test_val = st.slider("Richter Magnitude (Mw)", 1.0, 8.5, 5.2, 0.1)
            if test_val >= 6.5:
                status = ("MAJOR DESTRUCTIVE SEISMIC EVENT", "severe", "Severe building damage expected; trigger National Response Plan.")
            elif test_val >= 5.0:
                status = ("MODERATE SHAKING", "warning", "Structural inspection of bridges and multi-story masonry structures.")
            else:
                status = ("MINOR / MICRO-SEISMICITY", "normal", "Felt locally; negligible structural impact.")
        elif selected_hazard == "Heatwaves":
            test_val = st.slider("Maximum Recorded Temperature (°C)", 32.0, 52.0, 44.5, 0.5)
            if test_val >= 47.0:
                status = ("SEVERE HEATWAVE (RED WARNING)", "severe", "High risk of heat stroke. Restrict outdoor labour between 11 AM - 4 PM.")
            elif test_val >= 44.0:
                status = ("HEATWAVE CONDITIONS (ORANGE)", "warning", "Provide drinking water kiosks and adjust hospital emergency beds.")
            else:
                status = ("NORMAL SUMMER TEMPERATURE", "normal", "Standard seasonal hydration precautions.")
        else:
            test_val = st.slider("Relative Stress Factor (%)", 0.0, 100.0, 55.0, 5.0)
            if test_val >= 75.0:
                status = ("CRITICAL HAZARD TRIGGER", "severe", "Immediate emergency containment protocols required.")
            elif test_val >= 50.0:
                status = ("ELEVATED ADVISORY", "warning", "Intensify sensor polling rate and notify duty engineer.")
            else:
                status = ("SAFE OPERATING BASELINE", "normal", "Parameters nominal.")

        st.markdown(
            f"""
            <div style="background: #111827; border: 1px solid #374151; border-radius: 8px; padding: 14px; margin-top: 10px;">
                <div style="font-size: 0.78rem; text-transform: uppercase; color: #9ca3af; font-weight: 600;">Evaluated Classification:</div>
                <div style="font-size: 1.1rem; font-weight: 700; color: #ffffff; margin-top: 4px;">{status[0]}</div>
                <div style="font-size: 0.85rem; color: #d1d5db; margin-top: 6px;">{status[2]}</div>
            </div>
            """,
            unsafe_allow_html=True
        )
