﻿"""
Module 6: Emergency Decision Support.
Provides general preparedness guidelines and incident command checklists
aligned with National Disaster Management Authority (NDMA) frameworks.
Explicitly distinguishes advisory recommendations from official administrative orders.
"""

import streamlit as st
from aegis_ai.ui.components import (
    render_header,
    render_emergency_disclaimer,
    render_simulation_banner
)
from aegis_ai.config import HAZARD_CATEGORIES

# Standard Operating Procedures & Guidelines per Hazard (NDMA / SDMA standards)
NDMA_GUIDELINES = {
    "Floods": {
        "pre_event": [
            "Identify designated high-ground flood shelters and safe evacuation routes.",
            "Install check-valves in sewer traps to prevent floodwater backflow into premises.",
            "Assemble 72-hour emergency survival kit: potable chlorine tablets, torch, battery radio, copies of identity documents in waterproof bags.",
            "Tie down or elevate electrical appliances and fuel tanks above the 100-year flood line."
        ],
        "during_event": [
            "Never walk, swim, or drive through flowing water; 15 cm of moving water can knock down an adult.",
            "Disconnect electrical main breakers and turn off LPG cylinder regulators immediately.",
            "Move elderly individuals, children, and livestock to higher elevations or pre-designated cyclone/flood shelters.",
            "Listen exclusively to All India Radio (AIR) or official District Magistrate press releases for evacuation notices."
        ],
        "post_event": [
            "Avoid downed power lines and report broken water/sewer mains to municipal authorities.",
            "Boil all drinking water for at least 10 minutes or use accredited purification tablets.",
            "Do not consume food that has come into direct contact with stagnant floodwaters.",
            "Document structural damage with photos before initiating debris cleanup for insurance/relief assessment."
        ]
    },
    "Cyclones": {
        "pre_event": [
            "Trim dead tree branches and repair loose roof tiles or corrugated iron sheets.",
            "Board up large glass windows or tape them securely in an X-pattern to reduce shattering.",
            "Keep emergency vehicles fueled and parked away from trees and power lines.",
            "Fishermen must suspend all offshore marine activity and haul small crafts to inland berths."
        ],
        "during_event": [
            "Remain indoors in the most reinforced central room away from windows until the all-clear is announced.",
            "Beware of the 'Eye of the Cyclone': a sudden lull in wind does not mean the storm has passed; destructive reverse winds follow.",
            "Keep mobile devices fully charged and use SMS instead of voice calls to conserve cellular network bandwidth.",
            "Do not venture out during periods of calm without official confirmation."
        ],
        "post_event": [
            "Clear debris cautiously, watching for displaced snakes, scorpions, and exposed electrical wires.",
            "Drive only if strictly necessary; keep clear of rescue vehicle corridors and NDRF search parties.",
            "Check for gas leaks before lighting matches, stoves, or electrical switches."
        ]
    },
    "Earthquakes": {
        "pre_event": [
            "Anchor heavy furniture, bookshelves, and water heaters securely to structural wall studs.",
            "Identify safe spots in each room: under sturdy desks, interior doorways, or against interior load-bearing walls.",
            "Conduct periodic family and workplace 'Drop, Cover, and Hold On' earthquake drills.",
            "Maintain an updated inventory of emergency first aid equipment and prescription medications."
        ],
        "during_event": [
            "DROP to your hands and knees. COVER your head and neck under a sturdy table. HOLD ON until shaking stops completely.",
            "If in bed, stay there and protect your head with a pillow.",
            "If outdoors, move away from buildings, power cables, streetlights, and overpasses into open clearings.",
            "DO NOT use elevators; stairs may also be compromised during active shaking."
        ],
        "post_event": [
            "Expect aftershocks which may trigger collapse of already weakened masonry structures.",
            "Extinguish small fires immediately with dry chemical extinguishers.",
            "Inspect chimneys and structural columns for shear cracks before re-entering buildings."
        ]
    },
    "Landslides": {
        "pre_event": [
            "Monitor hill slopes for new tension cracks, tilting trees, or sudden changes in stream turbidity.",
            "Avoid building on steep slopes, close to mountain edges, or along natural drainage gullies.",
            "Plant native deep-rooted vegetation on bare slopes to improve surface cohesion.",
            "Establish an evacuation signal with neighboring mountain communities."
        ],
        "during_event": [
            "Quickly move away from the path of debris flow or rockfall towards higher stable ridges.",
            "If escape is impossible, curl into a tight ball and protect your head with your arms.",
            "Listen for unusual sounds: cracking trees, rumbling boulders, or sudden surges in muddy water."
        ],
        "post_event": [
            "Stay away from slide areas; secondary landslides often follow initial slope failures.",
            "Check for trapped or injured persons without directly entering the active slide zone.",
            "Report damaged roadways, blocked culverts, and sheared utility lines to the Public Works Department (PWD)."
        ]
    },
    "Industrial and chemical hazards": {
        "pre_event": [
            "Familiarize yourself with nearby Major Accident Hazard (MAH) industrial facilities and siren signals.",
            "Keep personal protective equipment (PPE): N95/N99 respirators, safety goggles, and heavy rubber gloves on hand.",
            "Ensure awareness of facility wind socks to determine prevailing wind direction during a release."
        ],
        "during_event": [
            "Evacuate immediately UPWIND and CROSSWIND from the toxic gas dispersion plume.",
            "If shelter-in-place is advised: close all windows, doors, and dampers; seal gaps with wet towels and duct tape.",
            "Cover mouth and nose with a damp cloth if caught in a chemical aerosol cloud.",
            "Turn off air conditioning systems and ventilation fans drawing outside air."
        ],
        "post_event": [
            "Do not return to the chemical exclusion perimeter until certified safe by hazardous materials specialists.",
            "Decontaminate clothing and wash skin thoroughly with clean running water and mild soap.",
            "Seek medical evaluation if experiencing respiratory irritation, burning eyes, or dizziness."
        ]
    }
}

def render_emergency_decision_module():
    render_header(current_module="Emergency Decision Support")
    render_emergency_disclaimer()
    render_simulation_banner("Preparedness guides and incident action plans reflect general NDMA SOP frameworks.")

    # Hazard Selector
    col_sel, col_mode = st.columns([1.5, 2.5])
    with col_sel:
        hazard_options = list(HAZARD_CATEGORIES.keys())
        selected_hazard = st.selectbox(
            "Select Hazard Domain",
            hazard_options,
            index=0
        )
    with col_mode:
        st.markdown(
            """
            <div style="background: #182234; border: 1px solid #334155; border-radius: 6px; padding: 10px 14px; font-size: 0.8rem; color: #94a3b8; margin-top: 4px;">
                <strong>Decision Hierarchy:</strong> General Preparedness SOP &nbsp;|&nbsp; 
                <strong>Statutory Authority:</strong> Disaster Management Act, 2005 (GoI)
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)

    # General Preparedness Recommendations based on Hazard
    st.subheader(f"Standard Preparedness Protocol: {selected_hazard}")
    st.caption("Actionable directives organized chronologically across the disaster life cycle.")

    # Fetch specific guidelines or provide comprehensive defaults
    guidelines = NDMA_GUIDELINES.get(selected_hazard, {
        "pre_event": [
            f"Review local district disaster management plan (DDMP) for {selected_hazard}.",
            "Maintain emergency communication contact directory and spare power banks.",
            "Ensure emergency water, first aid supplies, and dry rations are stocked."
        ],
        "during_event": [
            "Follow instructions broadcast by local district administration and emergency services.",
            "Prioritize the safety of vulnerable populations: children, pregnant women, the elderly, and persons with disabilities.",
            "Avoid spreading unverified rumors on social media."
        ],
        "post_event": [
            "Cooperate with local search-and-rescue teams and municipal relief officers.",
            "Report damaged infrastructure to relevant civic authorities.",
            "Maintain hygiene and sanitation to prevent secondary disease outbreaks."
        ]
    })

    t_pre, t_during, t_post = st.tabs(["Phase 1: Pre-Disaster Preparedness", "Phase 2: During-Disaster Protective Action", "Phase 3: Post-Disaster Relief & Recovery"])

    with t_pre:
        for idx, item in enumerate(guidelines["pre_event"], 1):
            st.markdown(f"**{idx}.** {item}")

    with t_during:
        for idx, item in enumerate(guidelines["during_event"], 1):
            st.markdown(f"**{idx}.** {item}")

    with t_post:
        for idx, item in enumerate(guidelines["post_event"], 1):
            st.markdown(f"**{idx}.** {item}")

    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # Incident Action Plan (IAP) Generator for Field Incident Commanders
    st.subheader("Field Incident Action Plan (IAP) Generator")
    st.caption("Generate a structured situational report (SITREP) for inter-agency coordination.")

    c_iap1, c_iap2 = st.columns(2)
    with c_iap1:
        iap_location = st.text_input("Operational Sector / District", value="Kamrup Metropolitan, Assam")
        iap_commander = st.text_input("Incident Commander ID / Call Sign", value="IC-AEGIS-ALPHA")
        iap_phase = st.selectbox("Current Operational Phase", ["Initial Assessment", "Search & Rescue", "Relief Logistics", "Demobilization"])
    with c_iap2:
        iap_evac_target = st.number_input("Target Population in Zone", min_value=100, max_value=500000, value=12500, step=500)
        iap_shelters = st.number_input("Designated Emergency Shelters Active", min_value=1, max_value=50, value=8)
        iap_channels = st.multiselect("Active Inter-Agency Channels", ["NDRF VHF Ch 4", "State Police Wireless", "Amateur Ham Radio", "Satellite Phone BGAN"], default=["NDRF VHF Ch 4", "State Police Wireless"])

    if st.button("Generate Formatted Incident Action Plan"):
        st.success("Incident Action Plan generated successfully.")
        st.markdown(
            f"""
            <div style="background: #111827; border: 1px solid #374151; border-radius: 8px; padding: 18px; margin-top: 10px;" class="mono-font">
                <div style="border-bottom: 1px solid #374151; padding-bottom: 8px; margin-bottom: 10px;">
                    <strong>[SITREP-01 / ICS FORM 201 COMPLIANT]</strong><br>
                    INCIDENT: {selected_hazard.upper()} RESPONSE &nbsp;|&nbsp; SECTOR: {iap_location.upper()}
                </div>
                <div><strong>INCIDENT COMMANDER:</strong> {iap_commander}</div>
                <div><strong>OPERATIONAL PHASE:</strong> {iap_phase}</div>
                <div><strong>POPULATION ENVELOPE:</strong> {iap_evac_target:,} persons across {iap_shelters} operational shelters</div>
                <div><strong>COMMS CHANNELS:</strong> {', '.join(iap_channels)}</div>
                <div style="margin-top: 10px; padding-top: 8px; border-top: 1px dashed #4b5563; font-size: 0.8rem; color: #9ca3af;">
                    * AegisAI Advisory Output. Non-binding operational template for training and simulation exercises.
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )
