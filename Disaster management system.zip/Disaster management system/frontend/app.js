﻿// ==========================================================================
// AEGIS CONTROL CENTER - CORE SYSTEM SCRIPT (10-YEAR DATASET EDITION)
// ==========================================================================

const API_BASE = (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1")
    ? "http://localhost:8080/api"
    : "/api";
let activeTab = "tab-tactical";

// Leaflet Map variables
let map = null;
let hHQMarker = null;
let hazardMarkers = {};
let clickTargetMarker = null;

// Chart.js instances
let trendChart = null;
let typeChart = null;
let regionChart = null;
let severityChart = null;
let currentTypeChartMode = "bar"; // Default: Square Bar Matrix
let cachedHazardsForCharts = [];

// Audio context for siren synthesis (zero-dependency Web Audio API)
let audioCtx = null;
let sirenInterval = null;

// Keep track of acknowledged alerts
let acknowledgedAlertIds = new Set();
let knownHazardIds = new Set();

// Active disaster tracking
let currentDisasters = [];

// Offline Fallback State & Seeds
let isOfflineMode = false;
let localResourceInventory = {
    "Ambulances": 25,
    "Rescue Boats": 15,
    "Medical Teams": 40,
    "Food Supplies": 800,
    "Shelters Available": 120
};

// ADIS State Variables
let weatherLayers = { rain: null, heat: null, wind: null };
let activeRoutePolyline = null;
let selectedNlpPost = null;
let cvScanInterval = null;
let nlpStreamInterval = null;
let iotSensorInterval = null;
let currentCvProfileIndex = 0;

// 48-Hour Early Warning & Evacuation State
let earlyWarningData = null;
let evacShelterMarkers = [];
let evacRouteLayers = [];
let evacDangerCircle = null;
let lastEarlyWarningSync = 0;


const FALLBACK_HAZARDS = [
    // --- TAMIL NADU & COROMANDEL COAST (Densely Populated Living Cities, Wards & Coastal Settlements) ---
    { id: 1, year: 2016, location: "Tamil Nadu & Coromandel Coast", city: "Chennai - Velachery & Madipakkam Wards", lat: 12.9792, lng: 80.2185, type: "Hurricane", severity: "Critical", risk: 94, affectedPopulation: 420000, damageCost: 45.0, status: "Resolved", timestamp: "2016-12-12 14:00:00", resourcesAllocated: {} },
    { id: 2, year: 2016, location: "Tamil Nadu & Coromandel Coast", city: "Chennai - Tambaram & Chromepet Townships", lat: 12.9249, lng: 80.1275, type: "Flash Flood", severity: "High", risk: 88, affectedPopulation: 380000, damageCost: 35.0, status: "Resolved", timestamp: "2016-12-13 09:30:00", resourcesAllocated: {} },
    { id: 3, year: 2017, location: "Tamil Nadu & Coromandel Coast", city: "Kanyakumari - Nagercoil Town & Vadasery Colony", lat: 8.1833, lng: 77.4119, type: "Hurricane", severity: "Critical", risk: 91, affectedPopulation: 230000, damageCost: 28.0, status: "Resolved", timestamp: "2017-11-30 08:00:00", resourcesAllocated: {} },
    { id: 4, year: 2017, location: "Tamil Nadu & Coromandel Coast", city: "Chennai - Royapuram & Ennore Coastal Fisher Colony", lat: 13.1147, lng: 80.2974, type: "Hurricane", severity: "High", risk: 85, affectedPopulation: 290000, damageCost: 22.0, status: "Resolved", timestamp: "2017-12-01 16:00:00", resourcesAllocated: {} },
    { id: 5, year: 2018, location: "Tamil Nadu & Coromandel Coast", city: "Nagapattinam - Velankanni Coastal Settlement", lat: 10.7656, lng: 79.8424, type: "Hurricane", severity: "Critical", risk: 93, affectedPopulation: 160000, damageCost: 52.0, status: "Resolved", timestamp: "2018-11-15 20:00:00", resourcesAllocated: {} },
    { id: 6, year: 2018, location: "Tamil Nadu & Coromandel Coast", city: "Thanjavur - Kumbakonam & Cauvery Delta Colony", lat: 10.7870, lng: 79.1378, type: "Flash Flood", severity: "High", risk: 84, affectedPopulation: 310000, damageCost: 38.0, status: "Resolved", timestamp: "2018-11-16 11:15:00", resourcesAllocated: {} },
    { id: 7, year: 2019, location: "Tamil Nadu & Coromandel Coast", city: "Coimbatore - Gandhipuram & RS Puram Central Wards", lat: 11.0168, lng: 76.9558, type: "Flash Flood", severity: "High", risk: 79, affectedPopulation: 510000, damageCost: 19.5, status: "Resolved", timestamp: "2019-08-08 17:00:00", resourcesAllocated: {} },
    { id: 8, year: 2019, location: "Tamil Nadu & Coromandel Coast", city: "Nilgiris - Ooty & Coonoor Hill Town Settlement", lat: 11.4102, lng: 76.6950, type: "Landslide", severity: "High", risk: 82, affectedPopulation: 140000, damageCost: 14.0, status: "Resolved", timestamp: "2019-08-09 06:30:00", resourcesAllocated: {} },
    { id: 9, year: 2020, location: "Tamil Nadu & Coromandel Coast", city: "Cuddalore - Silver Beach Coastal Habitation", lat: 11.7480, lng: 79.7714, type: "Hurricane", severity: "Critical", risk: 90, affectedPopulation: 180000, damageCost: 32.0, status: "Resolved", timestamp: "2020-11-25 22:00:00", resourcesAllocated: {} },
    { id: 10, year: 2020, location: "Tamil Nadu & Coromandel Coast", city: "Chennai - T. Nagar & Mambalam Residential Hub", lat: 13.0418, lng: 80.2341, type: "Flash Flood", severity: "High", risk: 86, affectedPopulation: 310000, damageCost: 26.0, status: "Resolved", timestamp: "2020-11-26 10:00:00", resourcesAllocated: {} },
    { id: 11, year: 2021, location: "Tamil Nadu & Coromandel Coast", city: "Madurai - Goripalayam & Vaigai Riverside Habitations", lat: 9.9252, lng: 78.1198, type: "Flash Flood", severity: "High", risk: 82, affectedPopulation: 450000, damageCost: 21.0, status: "Resolved", timestamp: "2021-11-18 15:45:00", resourcesAllocated: {} },
    { id: 12, year: 2021, location: "Tamil Nadu & Coromandel Coast", city: "Tiruchirappalli - Srirangam Island & K.K. Nagar Wards", lat: 10.7905, lng: 78.7047, type: "Flash Flood", severity: "High", risk: 80, affectedPopulation: 490000, damageCost: 18.5, status: "Resolved", timestamp: "2021-11-19 12:00:00", resourcesAllocated: {} },
    { id: 13, year: 2022, location: "Tamil Nadu & Coromandel Coast", city: "Salem - Suramangalam & Shevapet Living Sector", lat: 11.6643, lng: 78.1460, type: "Flash Flood", severity: "Medium", risk: 65, affectedPopulation: 430000, damageCost: 12.0, status: "Resolved", timestamp: "2022-10-15 18:20:00", resourcesAllocated: {} },
    { id: 14, year: 2022, location: "Tamil Nadu & Coromandel Coast", city: "Erode - Bhavani River Basin Residential Colony", lat: 11.3410, lng: 77.7172, type: "Flash Flood", severity: "Medium", risk: 68, affectedPopulation: 320000, damageCost: 11.5, status: "Resolved", timestamp: "2022-10-18 08:30:00", resourcesAllocated: {} },
    { id: 15, year: 2023, location: "Tamil Nadu & Coromandel Coast", city: "Chennai - Velachery & Pallikaranai Marsh Residential Belt", lat: 12.9349, lng: 80.2137, type: "Flash Flood", severity: "Critical", risk: 95, affectedPopulation: 480000, damageCost: 62.0, status: "Resolved", timestamp: "2023-12-04 14:00:00", resourcesAllocated: {} },
    { id: 16, year: 2023, location: "Tamil Nadu & Coromandel Coast", city: "Thoothukudi (Tuticorin) - Salt Pan & Fishing Hamlet", lat: 8.7642, lng: 78.1348, type: "Flash Flood", severity: "Critical", risk: 96, affectedPopulation: 240000, damageCost: 48.0, status: "Resolved", timestamp: "2023-12-18 09:30:00", resourcesAllocated: {} },
    { id: 17, year: 2023, location: "Tamil Nadu & Coromandel Coast", city: "Tirunelveli - Palayamkottai & Thamirabarani Riverside Wards", lat: 8.7139, lng: 77.7567, type: "Flash Flood", severity: "Critical", risk: 94, affectedPopulation: 360000, damageCost: 42.0, status: "Resolved", timestamp: "2023-12-18 16:00:00", resourcesAllocated: {} },
    { id: 18, year: 2024, location: "Tamil Nadu & Coromandel Coast", city: "Nilgiris - Kotagiri & Coonoor Tea Labour Settlements", lat: 11.4200, lng: 76.8600, type: "Landslide", severity: "High", risk: 78, affectedPopulation: 95000, damageCost: 6.5, status: "Resolved", timestamp: "2024-08-02 11:00:00", resourcesAllocated: {} },
    { id: 19, year: 2024, location: "Tamil Nadu & Coromandel Coast", city: "Vellore - Katpadi & Fort Town Living District", lat: 12.9165, lng: 79.1325, type: "Flash Flood", severity: "Medium", risk: 62, affectedPopulation: 390000, damageCost: 8.0, status: "Resolved", timestamp: "2024-09-14 17:40:00", resourcesAllocated: {} },
    { id: 20, year: 2025, location: "Tamil Nadu & Coromandel Coast", city: "Tiruppur - Avinashi Textile Workers Living Clusters", lat: 11.1085, lng: 77.3411, type: "Flash Flood", severity: "High", risk: 75, affectedPopulation: 440000, damageCost: 15.0, status: "Resolved", timestamp: "2025-10-12 13:20:00", resourcesAllocated: {} },
    { id: 21, year: 2025, location: "Tamil Nadu & Coromandel Coast", city: "Ramanathapuram - Rameswaram Island & Pamban Living Villages", lat: 9.2876, lng: 79.3129, type: "Hurricane", severity: "High", risk: 86, affectedPopulation: 120000, damageCost: 24.0, status: "Resolved", timestamp: "2025-11-28 07:45:00", resourcesAllocated: {} },
    { id: 22, year: 2026, location: "Tamil Nadu & Coromandel Coast", city: "Puducherry / Coromandel - Lawspet & White Town Wards", lat: 11.9416, lng: 79.8083, type: "Flash Flood", severity: "High", risk: 76, affectedPopulation: 250000, damageCost: 4.8, status: "Resources Dispatched", timestamp: "2026-08-10 09:00:00", resourcesAllocated: { "Rescue Boats": 6, "Medical Teams": 8 } },
    { id: 23, year: 2026, location: "Tamil Nadu & Coromandel Coast", city: "Madurai - Thiruparankundram & Mattuthavani Settlements", lat: 9.8828, lng: 78.0718, type: "Flash Flood", severity: "High", risk: 81, affectedPopulation: 280000, damageCost: 9.5, status: "Pending", timestamp: "2026-08-11 11:20:00", resourcesAllocated: {} },

    // --- KERALA & WESTERN GHATS (Living Coastal, Hill & Backwater Habitations) ---
    { id: 24, year: 2018, location: "Kerala & Western Ghats", city: "Kochi - Ernakulam & Marine Drive Coastal Suburbs", lat: 9.9312, lng: 76.2673, type: "Flash Flood", severity: "Critical", risk: 96, affectedPopulation: 610000, damageCost: 65.0, status: "Resolved", timestamp: "2018-08-16 11:30:00", resourcesAllocated: {} },
    { id: 25, year: 2018, location: "Kerala & Western Ghats", city: "Alappuzha - Kuttanad Water-bound Village Living Zone", lat: 9.4981, lng: 76.3388, type: "Flash Flood", severity: "Critical", risk: 95, affectedPopulation: 190000, damageCost: 45.0, status: "Resolved", timestamp: "2018-08-18 15:00:00", resourcesAllocated: {} },
    { id: 26, year: 2019, location: "Kerala & Western Ghats", city: "Kozhikode - Beypore & Beach Road Residential District", lat: 11.2588, lng: 75.7804, type: "Flash Flood", severity: "High", risk: 83, affectedPopulation: 480000, damageCost: 28.0, status: "Resolved", timestamp: "2019-08-10 14:15:00", resourcesAllocated: {} },
    { id: 27, year: 2020, location: "Kerala & Western Ghats", city: "Idukki - Munnar Tea Plantation Worker Colonies", lat: 10.0889, lng: 77.0595, type: "Landslide", severity: "Critical", risk: 92, affectedPopulation: 85000, damageCost: 35.0, status: "Resolved", timestamp: "2020-08-07 05:45:00", resourcesAllocated: {} },
    { id: 28, year: 2021, location: "Kerala & Western Ghats", city: "Thrissur - Swaraj Round & Ollur Living Quarters", lat: 10.5276, lng: 76.2144, type: "Flash Flood", severity: "High", risk: 78, affectedPopulation: 370000, damageCost: 19.0, status: "Resolved", timestamp: "2021-10-16 16:30:00", resourcesAllocated: {} },
    { id: 29, year: 2024, location: "Kerala & Western Ghats", city: "Wayanad - Meppadi & Chooralmala Hill Settlement", lat: 11.5284, lng: 76.1664, type: "Landslide", severity: "Critical", risk: 97, affectedPopulation: 65000, damageCost: 58.0, status: "Resolved", timestamp: "2024-07-30 02:00:00", resourcesAllocated: {} },
    { id: 30, year: 2026, location: "Kerala & Western Ghats", city: "Thiruvananthapuram - Kazhakkoottam & Kowdiar Wards", lat: 8.5241, lng: 76.9366, type: "Flash Flood", severity: "High", risk: 80, affectedPopulation: 580000, damageCost: 14.5, status: "Pending", timestamp: "2026-08-10 15:00:00", resourcesAllocated: {} },

    // --- ODISHA & BENGAL COAST (Living Coastal Delta, Pilgrim Towns & Port Colonies) ---
    { id: 31, year: 2017, location: "Odisha & Bengal Coast", city: "Puri - Swargadwar Coastal Pilgrim Residential Zone", lat: 19.8135, lng: 85.8312, type: "Hurricane", severity: "Critical", risk: 95, affectedPopulation: 210000, damageCost: 45.0, status: "Resolved", timestamp: "2017-09-05 10:30:00", resourcesAllocated: {} },
    { id: 32, year: 2019, location: "Odisha & Bengal Coast", city: "Bhubaneswar - Chandrasekharpur & Nayapalli Colony", lat: 20.2961, lng: 85.8245, type: "Hurricane", severity: "Critical", risk: 94, affectedPopulation: 880000, damageCost: 85.0, status: "Resolved", timestamp: "2019-05-03 08:30:00", resourcesAllocated: {} },
    { id: 33, year: 2020, location: "Odisha & Bengal Coast", city: "Kolkata - Howrah & Salt Lake Residential Townships", lat: 22.5726, lng: 88.3639, type: "Hurricane", severity: "Critical", risk: 96, affectedPopulation: 4500000, damageCost: 120.0, status: "Resolved", timestamp: "2020-05-20 14:00:00", resourcesAllocated: {} },
    { id: 34, year: 2021, location: "Odisha & Bengal Coast", city: "Sundarbans - Gosaba Coastal Fisherfolk Settlements", lat: 22.1643, lng: 88.8070, type: "Hurricane", severity: "Critical", risk: 92, affectedPopulation: 220000, damageCost: 48.0, status: "Resolved", timestamp: "2021-05-26 11:45:00", resourcesAllocated: {} },
    { id: 35, year: 2022, location: "Odisha & Bengal Coast", city: "Paradip - Port Worker Colony & Fishing Settlement", lat: 20.3167, lng: 86.6111, type: "Hurricane", severity: "High", risk: 88, affectedPopulation: 140000, damageCost: 38.0, status: "Resolved", timestamp: "2022-05-10 11:00:00", resourcesAllocated: {} },
    { id: 36, year: 2023, location: "Odisha & Bengal Coast", city: "Cuttack - Mahanadi Riverbank Residential Enclave", lat: 20.4625, lng: 85.8828, type: "Flash Flood", severity: "High", risk: 84, affectedPopulation: 650000, damageCost: 22.0, status: "Resolved", timestamp: "2023-08-18 19:10:00", resourcesAllocated: {} },
    { id: 37, year: 2025, location: "Odisha & Bengal Coast", city: "Balasore - Chandipur Coastal Living Village", lat: 21.0500, lng: 86.9167, type: "Hurricane", severity: "High", risk: 88, affectedPopulation: 175000, damageCost: 26.0, status: "Resolved", timestamp: "2025-10-24 10:00:00", resourcesAllocated: {} },

    // --- ASSAM & NORTH-EAST (Brahmaputra Valley, River Island Villages & Hill Towns) ---
    { id: 38, year: 2016, location: "Assam & North-East", city: "Guwahati - Dispur & Bharalu Riverbank Wards", lat: 26.1445, lng: 91.7362, type: "Flash Flood", severity: "High", risk: 79, affectedPopulation: 980000, damageCost: 17.0, status: "Resolved", timestamp: "2016-08-20 18:00:00", resourcesAllocated: {} },
    { id: 39, year: 2018, location: "Assam & North-East", city: "Dibrugarh - Tea Garden Labour Living Colonies", lat: 27.4728, lng: 94.9120, type: "Flash Flood", severity: "High", risk: 82, affectedPopulation: 155000, damageCost: 14.5, status: "Resolved", timestamp: "2018-07-14 12:45:00", resourcesAllocated: {} },
    { id: 40, year: 2020, location: "Assam & North-East", city: "Shillong - Police Bazar & Laitumkhrah Residential Zone", lat: 25.5788, lng: 91.8933, type: "Landslide", severity: "High", risk: 77, affectedPopulation: 160000, damageCost: 8.2, status: "Resolved", timestamp: "2020-09-22 09:15:00", resourcesAllocated: {} },
    { id: 41, year: 2022, location: "Assam & North-East", city: "Silchar - Barak Valley Residential Lowlands", lat: 24.8333, lng: 92.7789, type: "Flash Flood", severity: "Critical", risk: 91, affectedPopulation: 230000, damageCost: 24.0, status: "Resolved", timestamp: "2022-06-20 15:30:00", resourcesAllocated: {} },
    { id: 42, year: 2026, location: "Assam & North-East", city: "Majuli - River Island Tribal Village Settlements", lat: 26.9500, lng: 94.2167, type: "Flash Flood", severity: "Critical", risk: 93, affectedPopulation: 170000, damageCost: 14.0, status: "Pending", timestamp: "2026-08-08 16:00:00", resourcesAllocated: {} },

    // --- UTTARAKHAND & HIMALAYAS (Populated Valleys, Slope Settlements & Hill Towns) ---
    { id: 43, year: 2017, location: "Uttarakhand & Himalayas", city: "Rishikesh - Tapovan & Muni Ki Reti Communities", lat: 30.0869, lng: 78.2676, type: "Flash Flood", severity: "High", risk: 83, affectedPopulation: 110000, damageCost: 15.0, status: "Resolved", timestamp: "2017-07-28 07:15:00", resourcesAllocated: {} },
    { id: 44, year: 2020, location: "Uttarakhand & Himalayas", city: "Chamoli - Alaknanda Valley Village Settlements", lat: 30.4227, lng: 79.3326, type: "Wildfire", severity: "High", risk: 81, affectedPopulation: 45000, damageCost: 6.0, status: "Resolved", timestamp: "2020-05-24 11:20:00", resourcesAllocated: {} },
    { id: 45, year: 2021, location: "Uttarakhand & Himalayas", city: "Joshimath - Upper Bazaar & Subsidence Hazard Living Zone", lat: 30.4853, lng: 79.7042, type: "Flash Flood", severity: "Critical", risk: 92, affectedPopulation: 32000, damageCost: 18.0, status: "Resolved", timestamp: "2021-02-07 10:00:00", resourcesAllocated: {} },
    { id: 46, year: 2023, location: "Uttarakhand & Himalayas", city: "Dehradun - Rajpur Road & Prem Nagar Valley", lat: 30.3165, lng: 78.0322, type: "Flash Flood", severity: "High", risk: 80, affectedPopulation: 580000, damageCost: 21.0, status: "Resolved", timestamp: "2023-08-20 16:40:00", resourcesAllocated: {} },

    // --- HIMACHAL & J&K RANGES (Hill Townships, River Valleys & Dal Lake Habitations) ---
    { id: 47, year: 2019, location: "Himachal & J&K Ranges", city: "Kullu-Manali - Beas Riverbank Living Clusters", lat: 31.9579, lng: 77.1095, type: "Landslide", severity: "Medium", risk: 58, affectedPopulation: 95000, damageCost: 1.5, status: "Resolved", timestamp: "2019-11-20 08:45:00", resourcesAllocated: {} },
    { id: 48, year: 2021, location: "Himachal & J&K Ranges", city: "Dharamshala - McLeodganj Residential Colony", lat: 32.2190, lng: 76.3234, type: "Landslide", severity: "High", risk: 74, affectedPopulation: 60000, damageCost: 9.0, status: "Resolved", timestamp: "2021-07-12 11:30:00", resourcesAllocated: {} },
    { id: 49, year: 2023, location: "Himachal & J&K Ranges", city: "Shimla - Sanjauli & Lakkar Bazaar Hill Habitations", lat: 31.1048, lng: 77.1734, type: "Landslide", severity: "Critical", risk: 92, affectedPopulation: 175000, damageCost: 35.0, status: "Resolved", timestamp: "2023-08-14 08:30:00", resourcesAllocated: {} },
    { id: 50, year: 2024, location: "Himachal & J&K Ranges", city: "Srinagar - Dal Lake & Downtown Habitations", lat: 34.0837, lng: 74.7973, type: "Flash Flood", severity: "High", risk: 85, affectedPopulation: 1200000, damageCost: 42.0, status: "Resolved", timestamp: "2024-04-29 14:00:00", resourcesAllocated: {} },
    { id: 51, year: 2025, location: "Himachal & J&K Ranges", city: "Jammu - Tawi Riverbank Housing Colonies", lat: 32.7266, lng: 74.8570, type: "Flash Flood", severity: "Medium", risk: 68, affectedPopulation: 540000, damageCost: 12.0, status: "Resolved", timestamp: "2025-08-11 10:15:00", resourcesAllocated: {} },

    // --- GUJARAT & WESTERN COAST (Metropolitan Suburbs, River Basins & Coastal Ports) ---
    { id: 52, year: 2017, location: "Gujarat & Western Coast", city: "Ahmedabad - Sabarmati Riverfront Residential Wards", lat: 23.0225, lng: 72.5714, type: "Flash Flood", severity: "High", risk: 82, affectedPopulation: 2400000, damageCost: 36.0, status: "Resolved", timestamp: "2017-07-25 15:30:00", resourcesAllocated: {} },
    { id: 53, year: 2019, location: "Gujarat & Western Coast", city: "Surat - Tapi Riverbank & Varachha Residential Sector", lat: 21.1702, lng: 72.8311, type: "Flash Flood", severity: "High", risk: 84, affectedPopulation: 2800000, damageCost: 48.0, status: "Resolved", timestamp: "2019-08-04 18:00:00", resourcesAllocated: {} },
    { id: 54, year: 2021, location: "Gujarat & Western Coast", city: "Veraval / Somnath - Gir Coastal Fishermen Settlements", lat: 20.9159, lng: 71.3989, type: "Hurricane", severity: "Critical", risk: 94, affectedPopulation: 160000, damageCost: 70.0, status: "Resolved", timestamp: "2021-05-17 19:00:00", resourcesAllocated: {} },
    { id: 55, year: 2023, location: "Gujarat & Western Coast", city: "Kutch (Bhuj / Mandvi) - Coastal Port Habitations", lat: 23.2420, lng: 68.8198, type: "Hurricane", severity: "Critical", risk: 93, affectedPopulation: 190000, damageCost: 55.0, status: "Resolved", timestamp: "2023-06-15 17:30:00", resourcesAllocated: {} },
    { id: 56, year: 2026, location: "Gujarat & Western Coast", city: "Mumbai - Kurla, Dharavi & Mithi River Residential Belt", lat: 19.0760, lng: 72.8777, type: "Structural Collapse", severity: "High", risk: 80, affectedPopulation: 3200000, damageCost: 4.5, status: "Pending", timestamp: "2026-08-10 15:00:00", resourcesAllocated: {} },

    // --- INDO-GANGETIC & CENTRAL PLAINS (Densely Populated Gangetic Wards & Delta Cities) ---
    { id: 57, year: 2018, location: "Indo-Gangetic & Central Plains", city: "Varanasi - Assi Ghat & Chitaipur Residential Blocks", lat: 25.3176, lng: 82.9739, type: "Flash Flood", severity: "High", risk: 78, affectedPopulation: 1400000, damageCost: 16.0, status: "Resolved", timestamp: "2018-09-08 11:20:00", resourcesAllocated: {} },
    { id: 58, year: 2019, location: "Indo-Gangetic & Central Plains", city: "Patna - Kankarbagh & Ganga Riverbank Living Sectors", lat: 25.5941, lng: 85.1376, type: "Flash Flood", severity: "High", risk: 80, affectedPopulation: 2100000, damageCost: 29.0, status: "Resolved", timestamp: "2019-09-29 14:00:00", resourcesAllocated: {} },
    { id: 59, year: 2020, location: "Indo-Gangetic & Central Plains", city: "Lucknow - Gomti Nagar & River Colony", lat: 26.8467, lng: 80.9462, type: "Flash Flood", severity: "Medium", risk: 65, affectedPopulation: 1600000, damageCost: 14.0, status: "Resolved", timestamp: "2020-08-19 16:45:00", resourcesAllocated: {} },
    { id: 60, year: 2022, location: "Indo-Gangetic & Central Plains", city: "Bengaluru - Bellandur Lake Basin & Outer Ring Road Quarters", lat: 12.9716, lng: 77.5946, type: "Flash Flood", severity: "High", risk: 86, affectedPopulation: 2900000, damageCost: 35.0, status: "Resolved", timestamp: "2022-09-05 21:00:00", resourcesAllocated: {} },
    { id: 61, year: 2023, location: "Indo-Gangetic & Central Plains", city: "Delhi NCR - Yamuna Floodplain & Yamuna Bazar Settlements", lat: 28.6139, lng: 77.2090, type: "Flash Flood", severity: "Critical", risk: 93, affectedPopulation: 4100000, damageCost: 52.0, status: "Resolved", timestamp: "2023-07-13 13:00:00", resourcesAllocated: {} },
    { id: 62, year: 2024, location: "Indo-Gangetic & Central Plains", city: "Hyderabad - Musi Riverbank & Old City Residential Wards", lat: 17.3850, lng: 78.4867, type: "Flash Flood", severity: "High", risk: 84, affectedPopulation: 2300000, damageCost: 31.0, status: "Resolved", timestamp: "2024-09-02 18:30:00", resourcesAllocated: {} },
    { id: 63, year: 2025, location: "Indo-Gangetic & Central Plains", city: "Visakhapatnam - MVP Colony & Coastal Fishing Harbour", lat: 17.6868, lng: 83.2185, type: "Flash Flood", severity: "High", risk: 82, affectedPopulation: 920000, damageCost: 18.0, status: "Resolved", timestamp: "2025-09-08 16:00:00", resourcesAllocated: {} }
];

// Initialize Dashboard
document.addEventListener("DOMContentLoaded", () => {
    initRadarPreloader();
    initTabs();
    initMap();
    initFormHandlers();
    initDatabaseFilters();
    initDashboardFilters();
    initCharts();
    initAdisComponents();
    initEarlyWarningModule();

    // Initial data load and start polling sync loops
    syncData();
    setInterval(syncData, 1000); // 1-second interval sync

    // System clock update
    setInterval(updateSystemClock, 1000);
});

// ==========================================================================
// TACTICAL RADAR PRELOADER & SERVER RELOAD CONTROLLER (mrhyddenn Uiverse.io)
// ==========================================================================
function initRadarPreloader() {
    const preloader = document.getElementById("app-loading-screen");
    const progressFill = document.getElementById("loading-progress-fill");
    const statusText = document.getElementById("loading-status-text");

    if (!preloader) return;

    // Animate progress smoothly on initial load
    let progress = 0;
    const progressInterval = setInterval(() => {
        progress += 14;
        if (progressFill) progressFill.style.width = `${Math.min(100, progress)}%`;

        if (statusText) {
            if (progress < 30) statusText.innerText = "CONNECTING TO JAVA BACKEND SERVER [PORT 8080]...";
            else if (progress < 60) statusText.innerText = "INGESTING 10-YEAR HISTORICAL DISASTER MATRIX...";
            else if (progress < 85) statusText.innerText = "SYNCHRONIZING PERSISTENT COUNTDOWN TIMERS...";
            else statusText.innerText = "RADAR SURVEILLANCE READY — LAUNCHING AEGIS CORE";
        }

        if (progress >= 100) {
            clearInterval(progressInterval);
            setTimeout(() => {
                preloader.classList.add("fade-out");
            }, 300);
        }
    }, 70);

    // Hard fail-safe: Ensure preloader is dismissed after 1.5s regardless of network delays
    setTimeout(() => {
        preloader.classList.add("fade-out");
    }, 1500);

    // Wire up "Reload Server" / "Radar Scan" button in topbar (#reload-loader-btn)
    const reloadBtn = document.getElementById("reload-loader-btn");
    if (reloadBtn) {
        reloadBtn.addEventListener("click", () => {
            triggerRadarPreloaderScan("RE-SCANNING SATELLITE RADAR MATRIX & RELOADING SERVERS...");
        });
    }

    // Wire up sidebar server status badge (#server-status)
    const serverStatusBadge = document.getElementById("server-status");
    if (serverStatusBadge) {
        serverStatusBadge.style.cursor = "pointer";
        serverStatusBadge.setAttribute("title", "Click to Re-sync & Reload Backend Server");
        serverStatusBadge.addEventListener("click", () => {
            triggerRadarPreloaderScan("RE-CONNECTING & RELOADING JAVA BACKEND (PORT 8080)...");
        });
    }
}

function triggerRadarPreloaderScan(customMessage) {
    const preloader = document.getElementById("app-loading-screen");
    const progressFill = document.getElementById("loading-progress-fill");
    const statusText = document.getElementById("loading-status-text");

    if (!preloader) return;

    preloader.classList.remove("fade-out");
    if (statusText) statusText.innerText = customMessage || "RE-SCANNING DISASTER MATRIX & LIVE TELEMETRY...";
    if (progressFill) progressFill.style.width = "0%";

    // Trigger backend server reload API
    fetch(`${API_BASE}/server/reload`, { method: "POST" })
        .catch(() => console.log("Reloading local data state..."))
        .finally(() => {
            syncData();
            if (typeof fetchEarlyWarnings === "function") fetchEarlyWarnings(true);
            if (typeof syncPersistentCountdowns === "function") syncPersistentCountdowns();
            if (typeof updateGlobeBeacons === "function" && Array.isArray(currentDisasters)) updateGlobeBeacons(currentDisasters);
        });

    let p = 0;
    const interval = setInterval(() => {
        p += 20;
        if (progressFill) progressFill.style.width = `${p}%`;
        if (p >= 100) {
            clearInterval(interval);
            setTimeout(() => {
                preloader.classList.add("fade-out");
            }, 350);
        }
    }, 90);
}

// Update Header System Clock
function updateSystemClock() {
    const clockEl = document.getElementById("system-clock");
    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const yyyy = now.getFullYear();
    const mm = pad(now.getMonth() + 1);
    const dd = pad(now.getDate());
    const hh = pad(now.getHours());
    const min = pad(now.getMinutes());
    const ss = pad(now.getSeconds());
    clockEl.innerHTML = `<i class="fa-regular fa-clock"></i> ${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
}

// ------------------ TAB NAVIGATION ------------------
function initTabs() {
    const tabs = document.querySelectorAll(".nav-tab");
    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            const target = tab.getAttribute("data-tab");

            tabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");

            document.querySelectorAll(".tab-content").forEach(content => {
                content.classList.remove("active");
            });
            document.getElementById(target).classList.add("active");

            activeTab = target;

            const titles = {
                "tab-tactical": "Live Incident Reconnaissance Map",
                "tab-capture": "Satellite Computer Vision & NLP Stream",
                "tab-esp32": "ESP32-S3 IoT Autonomous Disaster Gateway & Risk Pipeline",
                "tab-dashboard": "Operations & Incident Overview",
                "tab-analytics": "10-Year Historical Trend Analytics",
                "tab-prediction": "AI Predictive Risk Planner",
                "tab-data": "10-Year Historical Kaggle Dataset",
                "tab-earlywarning": "30-Hour Early Warning & Life Safety Evacuation Center"
            };
            const titleEl = document.getElementById("page-title");
            if (titleEl && titles[target]) {
                titleEl.innerText = titles[target];
            }

            if (target === "tab-esp32") {
                if (typeof esp32HistoryChart !== "undefined" && esp32HistoryChart) {
                    setTimeout(() => esp32HistoryChart.resize(), 100);
                }
            }

            if (target === "tab-earlywarning") {
                if (typeof fetchEarlyWarnings === "function") fetchEarlyWarnings(true);
                if (typeof updateEarlyWarningCountdown === "function") updateEarlyWarningCountdown();
            }

            // Trigger Leaflet map invalidateSize when switching back to Tactical map
            if (activeTab === "tab-tactical" && map) {
                setTimeout(() => {
                    map.invalidateSize();
                }, 100);
            }
        });
    });

    // Check URL parameter or hash to automatically open a specific tab (e.g. ?tab=tab-earlywarning)
    try {
        const urlParams = new URLSearchParams(window.location.search);
        const tabParam = urlParams.get("tab") || window.location.hash.replace("#", "");
        if (tabParam) {
            const targetId = tabParam.startsWith("tab-") ? tabParam : `tab-${tabParam}`;
            const targetBtn = document.querySelector(`.nav-tab[data-tab="${targetId}"]`);
            if (targetBtn) {
                setTimeout(() => targetBtn.click(), 100);
            }
        }
    } catch (e) {}

    const btnOpenEsp32 = document.getElementById("btn-open-esp32-tab");
    if (btnOpenEsp32) {
        btnOpenEsp32.addEventListener("click", () => {
            const esp32TabBtn = document.getElementById("tab-btn-esp32");
            if (esp32TabBtn) esp32TabBtn.click();
        });
    }
}

// ------------------ TACTICAL MAP & 3D DIGITAL EARTH SETUP ------------------
let satelliteGroup = null;
let darkLayer = null;
let activeMapMode = "satellite"; // "satellite", "3d", "dark"

// 3D Digital Earth Globe variables
let globeScene = null;
let globeCamera = null;
let globeRenderer = null;
let globeGroup = null;
let globeDisasterPins = [];
let globeAutoRotate = true;
let isGlobeInitialized = false;

function initMap() {
    // Center map around Geographic Center of India
    const indiaCenter = [22.5937, 78.9629];
    map = L.map("map", {
        zoomControl: true,
        doubleClickZoom: false
    }).setView(indiaCenter, 5);
    window.map = map;

    // 1. High-Resolution Photorealistic Satellite Earth (Esri World Imagery)
    const satelliteBase = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
        attribution: '&copy; Esri, Maxar, Earthstar Geographics, USDA, USGS',
        maxZoom: 19
    });

    const satelliteLabels = L.tileLayer("https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}", {
        attribution: '',
        maxZoom: 19
    });

    satelliteGroup = L.layerGroup([satelliteBase, satelliteLabels]);
    satelliteGroup.addTo(map);

    // 2. Dark Vector Map Layer (Alternative)
    darkLayer = L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
        subdomains: 'abcd',
        maxZoom: 20
    });

    // Create a Custom DivIcon for the system center
    const hqLatLng = [28.6139, 77.2090]; // National Disaster Management Command, New Delhi
    const hHQIcon = L.divIcon({
        className: 'custom-home-icon',
        html: '<div style="background-color: #38BDF8; width: 14px; height: 14px; border-radius: 50%; border: 2px solid #FFF; box-shadow: 0 0 12px rgba(56,189,248,0.9);"></div>',
        iconSize: [14, 14],
        iconAnchor: [7, 7]
    });
    hHQMarker = L.marker(hqLatLng, { icon: hHQIcon }).addTo(map);
    hHQMarker.bindPopup("<b>AEGIS DISASTER MONITORING DIVISION</b><br>National Command Headquarters (New Delhi)");

    // Map click to auto-fill logging coordinates
    map.on("click", (e) => {
        const lat = e.latlng.lat.toFixed(6);
        const lng = e.latlng.lng.toFixed(6);

        document.getElementById("report-lat").value = lat;
        document.getElementById("report-lng").value = lng;

        if (clickTargetMarker) {
            map.removeLayer(clickTargetMarker);
        }

        const targetIcon = L.divIcon({
            className: 'custom-target-icon',
            html: '<div style="border: 2px solid #EF4444; width: 22px; height: 22px; border-radius: 50%; box-shadow: 0 0 10px rgba(239,68,68,0.8); position: relative;"><div style="position: absolute; width: 2px; height: 26px; background: #EF4444; left: 8px; top: -4px;"></div><div style="position: absolute; width: 26px; height: 2px; background: #EF4444; left: -4px; top: 8px;"></div></div>',
            iconSize: [22, 22],
            iconAnchor: [11, 11]
        });

        clickTargetMarker = L.marker(e.latlng, { icon: targetIcon }).addTo(map);
    });

    // Setup map view mode toggles (Satellite Earth vs 3D Globe vs Dark)
    initMapModeControls();

    // Invalidate map size after DOM settles so tiles render immediately
    setTimeout(() => { if (map) map.invalidateSize(); }, 200);
    setTimeout(() => { if (map) map.invalidateSize(); }, 600);
}

function initMapModeControls() {
    const btnSat = document.getElementById("map-mode-satellite");
    const btn3D = document.getElementById("map-mode-3d");
    const btnDark = document.getElementById("map-mode-dark");
    const mapEl = document.getElementById("map");
    const globeContainer = document.getElementById("globe-3d-container");

    function setMode(mode) {
        activeMapMode = mode;
        [btnSat, btn3D, btnDark].forEach(btn => {
            if (btn) btn.classList.remove("active");
        });

        if (mode === "satellite") {
            if (btnSat) btnSat.classList.add("active");
            if (globeContainer) globeContainer.classList.add("hidden");
            if (mapEl) mapEl.style.display = "block";
            if (map) {
                if (map.hasLayer(darkLayer)) map.removeLayer(darkLayer);
                if (!map.hasLayer(satelliteGroup)) map.addLayer(satelliteGroup);
                map.invalidateSize();
            }
        } else if (mode === "dark") {
            if (btnDark) btnDark.classList.add("active");
            if (globeContainer) globeContainer.classList.add("hidden");
            if (mapEl) mapEl.style.display = "block";
            if (map) {
                if (map.hasLayer(satelliteGroup)) map.removeLayer(satelliteGroup);
                if (!map.hasLayer(darkLayer)) map.addLayer(darkLayer);
                map.invalidateSize();
            }
        } else if (mode === "3d") {
            if (btn3D) btn3D.classList.add("active");
            if (mapEl) mapEl.style.display = "none";
            if (globeContainer) {
                globeContainer.classList.remove("hidden");
                resizeDigitalEarthGlobe();
                if (!isGlobeInitialized) {
                    initDigitalEarthGlobe();
                } else {
                    updateGlobeBeacons(currentDisasters);
                }
            }
        }
    }

    if (btnSat) btnSat.addEventListener("click", () => setMode("satellite"));
    if (btn3D) btn3D.addEventListener("click", () => setMode("3d"));
    if (btnDark) btnDark.addEventListener("click", () => setMode("dark"));
}

// ------------------ 3D DIGITAL EARTH GLOBE (THREE.JS) ------------------
function initDigitalEarthGlobe() {
    const container = document.getElementById("globe-3d-container");
    const canvas = document.getElementById("globe-canvas");
    if (!container || !canvas || typeof THREE === "undefined" || isGlobeInitialized) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 580;

    globeScene = new THREE.Scene();
    globeCamera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    globeCamera.position.set(0, 3, 14);

    globeRenderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });
    globeRenderer.setSize(width, height);
    globeRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    globeGroup = new THREE.Group();
    globeScene.add(globeGroup);

    // Initial orientation focusing on India (Lat ~22°N, Lng ~78°E)
    globeGroup.rotation.set(0.35, 1.85, 0);

    // Ambient and Directional Lighting for realism
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    globeScene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0x38bdf8, 1.4);
    sunLight.position.set(15, 12, 10);
    globeScene.add(sunLight);

    const backLight = new THREE.DirectionalLight(0x06b6d4, 0.6);
    backLight.position.set(-15, -10, -10);
    globeScene.add(backLight);

    // Earth Sphere Geometry
    const radius = 5.0;
    const sphereGeo = new THREE.SphereGeometry(radius, 64, 64);

    // High-resolution satellite Earth texture with procedural canvas fallback
    const textureLoader = new THREE.TextureLoader();
    const earthTexture = textureLoader.load(
        "https://cdn.jsdelivr.net/gh/mrdoob/three.js@r128/examples/textures/planets/earth_atmos_2048.jpg",
        () => {
            if (globeRenderer && globeScene && globeCamera) {
                globeRenderer.render(globeScene, globeCamera);
            }
        },
        undefined,
        () => {
            // Fallback digital earth procedural texture
            const canvasTex = createDigitalEarthProceduralTexture();
            const fallbackTex = new THREE.CanvasTexture(canvasTex);
            earthMat.map = fallbackTex;
            earthMat.needsUpdate = true;
        }
    );

    const earthMat = new THREE.MeshPhongMaterial({
        map: earthTexture,
        shininess: 20,
        specular: new THREE.Color(0x38bdf8)
    });
    const earthMesh = new THREE.Mesh(sphereGeo, earthMat);
    globeGroup.add(earthMesh);

    // Digital Latitude / Longitude Holographic Coordinate Rings
    const gridGeo = new THREE.SphereGeometry(radius + 0.05, 36, 18);
    const gridMat = new THREE.MeshBasicMaterial({
        wireframe: true,
        color: 0x06b6d4,
        transparent: true,
        opacity: 0.14
    });
    const gridMesh = new THREE.Mesh(gridGeo, gridMat);
    globeGroup.add(gridMesh);

    // Glowing Atmospheric Aura
    const atmosGeo = new THREE.SphereGeometry(radius + 0.22, 64, 64);
    const atmosMat = new THREE.MeshBasicMaterial({
        color: 0x38bdf8,
        transparent: true,
        opacity: 0.12,
        side: THREE.BackSide
    });
    const atmosMesh = new THREE.Mesh(atmosGeo, atmosMat);
    globeGroup.add(atmosMesh);

    // Mouse & Touch 3D Drag Rotation Controls
    let isDragging = false;
    let prevMouseX = 0, prevMouseY = 0;

    canvas.addEventListener("mousedown", (e) => {
        isDragging = true;
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
    });

    window.addEventListener("mouseup", () => { isDragging = false; });

    window.addEventListener("mousemove", (e) => {
        if (!isDragging) return;
        const deltaX = e.clientX - prevMouseX;
        const deltaY = e.clientY - prevMouseY;
        globeGroup.rotation.y += deltaX * 0.005;
        globeGroup.rotation.x += deltaY * 0.005;
        // Limit pitch
        globeGroup.rotation.x = Math.max(-Math.PI / 2.2, Math.min(Math.PI / 2.2, globeGroup.rotation.x));
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
    });

    // Touch controls for mobile / trackpad
    canvas.addEventListener("touchstart", (e) => {
        if (e.touches.length === 1) {
            isDragging = true;
            prevMouseX = e.touches[0].clientX;
            prevMouseY = e.touches[0].clientY;
        }
    }, { passive: true });

    window.addEventListener("touchend", () => { isDragging = false; });

    window.addEventListener("touchmove", (e) => {
        if (!isDragging || e.touches.length !== 1) return;
        const deltaX = e.touches[0].clientX - prevMouseX;
        const deltaY = e.touches[0].clientY - prevMouseY;
        globeGroup.rotation.y += deltaX * 0.005;
        globeGroup.rotation.x += deltaY * 0.005;
        prevMouseX = e.touches[0].clientX;
        prevMouseY = e.touches[0].clientY;
    }, { passive: true });

    // Zoom on wheel
    canvas.addEventListener("wheel", (e) => {
        e.preventDefault();
        globeCamera.position.z += e.deltaY * 0.01;
        globeCamera.position.z = Math.max(7.5, Math.min(24, globeCamera.position.z));
    }, { passive: false });

    // Auto-Rotate Button
    const rotateBtn = document.getElementById("globe-rotate-btn");
    if (rotateBtn) {
        rotateBtn.addEventListener("click", () => {
            globeAutoRotate = !globeAutoRotate;
            rotateBtn.innerHTML = globeAutoRotate
                ? '<i class="fa-solid fa-rotate"></i> Auto-Rotate: ON'
                : '<i class="fa-solid fa-pause"></i> Auto-Rotate: OFF';
            rotateBtn.classList.toggle("active", globeAutoRotate);
        });
    }

    // Reset View Button
    const resetBtn = document.getElementById("globe-reset-btn");
    if (resetBtn) {
        resetBtn.addEventListener("click", () => {
            globeGroup.rotation.set(0.35, 1.85, 0);
            globeCamera.position.set(0, 3, 14);
        });
    }

    // Tooltip Raycasting on click/hover
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    const tooltip = document.getElementById("globe-tooltip");

    canvas.addEventListener("click", (e) => {
        const rect = canvas.getBoundingClientRect();
        mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

        raycaster.setFromCamera(mouse, globeCamera);
        const pinMeshes = globeDisasterPins.map(p => p.mesh).filter(Boolean);
        const intersects = raycaster.intersectObjects(pinMeshes);

        if (intersects.length > 0 && tooltip) {
            const hit = globeDisasterPins.find(p => p.mesh === intersects[0].object);
            if (hit && hit.hazard) {
                const h = hit.hazard;
                tooltip.innerHTML = `
                    <div style="font-weight:700; color:${hit.colorHex}; margin-bottom:4px;">
                        <i class="fa-solid fa-triangle-exclamation"></i> ${h.type.toUpperCase()} [ID: #${h.id}]
                    </div>
                    <div><b>Populated Place:</b> ${h.city || h.location}</div>
                    <div><b>Civilians Living Here:</b> ${(h.affectedPopulation || 0).toLocaleString()}</div>
                    <div><b>Sector:</b> ${h.location}</div>
                    <div><b>Severity:</b> ${h.severity} (${h.risk}%)</div>
                    <div><b>Status:</b> ${h.status}</div>
                `;
                tooltip.style.left = `${e.clientX - rect.left + 15}px`;
                tooltip.style.top = `${e.clientY - rect.top + 15}px`;
                tooltip.classList.remove("hidden");
                setTimeout(() => { if (tooltip) tooltip.classList.add("hidden"); }, 5000);
            }
        }
    });

    // Populate Initial 3D Hazard Pins
    updateGlobeBeacons(currentDisasters);

    // Animation Loop
    function animate() {
        requestAnimationFrame(animate);

        if (globeAutoRotate && !isDragging) {
            globeGroup.rotation.y += 0.0016;
        }

        // Pulse beacon rings
        const time = Date.now() * 0.004;
        globeDisasterPins.forEach((pin, idx) => {
            if (pin.ring) {
                const scale = 1 + Math.sin(time + idx) * 0.35;
                pin.ring.scale.set(scale, scale, scale);
            }
        });

        if (container.offsetParent !== null) {
            globeRenderer.render(globeScene, globeCamera);
        }
    }
    animate();

    isGlobeInitialized = true;
}

function resizeDigitalEarthGlobe() {
    const container = document.getElementById("globe-3d-container");
    if (!container || !globeRenderer || !globeCamera) return;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 580;
    globeCamera.aspect = width / height;
    globeCamera.updateProjectionMatrix();
    globeRenderer.setSize(width, height);
}

// Convert Geographic Latitude & Longitude to 3D Cartesian Coordinates
function latLngToVector3(lat, lng, radius) {
    const phi = (90 - lat) * (Math.PI / 180);
    const theta = (lng + 180) * (Math.PI / 180);
    const x = -(radius * Math.sin(phi) * Math.cos(theta));
    const z = (radius * Math.sin(phi) * Math.sin(theta));
    const y = (radius * Math.cos(phi));
    return new THREE.Vector3(x, y, z);
}

// Update 3D Pins on the Digital Earth Globe
function updateGlobeBeacons(hazards) {
    if (!globeGroup || !isGlobeInitialized || typeof THREE === "undefined") return;

    // Clear previous pins
    globeDisasterPins.forEach(p => {
        if (p.mesh) globeGroup.remove(p.mesh);
        if (p.ring) globeGroup.remove(p.ring);
        if (p.line) globeGroup.remove(p.line);
    });
    globeDisasterPins = [];

    const radius = 5.0;

    hazards.forEach(hazard => {
        const lat = parseFloat(hazard.lat);
        const lng = parseFloat(hazard.lng);
        if (isNaN(lat) || isNaN(lng)) return;

        let pinColor = 0xef4444; // Red
        let hexStr = "#ef4444";
        if (hazard.type === "Flash Flood") {
            pinColor = 0x06b6d4; // Cyan
            hexStr = "#06b6d4";
        } else if (hazard.type === "Hurricane") {
            pinColor = 0xa855f7; // Purple
            hexStr = "#a855f7";
        } else if (hazard.type === "Landslide") {
            pinColor = 0xf59e0b; // Amber
            hexStr = "#f59e0b";
        }

        const basePos = latLngToVector3(lat, lng, radius);
        const elevatedPos = latLngToVector3(lat, lng, radius + 0.45);

        // Pin Head Sphere
        const pinGeo = new THREE.SphereGeometry(0.12, 16, 16);
        const pinMat = new THREE.MeshBasicMaterial({ color: pinColor });
        const pinMesh = new THREE.Mesh(pinGeo, pinMat);
        pinMesh.position.copy(elevatedPos);
        globeGroup.add(pinMesh);

        // Vertical Stalk Line from surface to pin head
        const lineGeo = new THREE.BufferGeometry().setFromPoints([basePos, elevatedPos]);
        const lineMat = new THREE.LineBasicMaterial({ color: pinColor, transparent: true, opacity: 0.75 });
        const line = new THREE.Line(lineGeo, lineMat);
        globeGroup.add(line);

        // Pulsing Epicenter Ring
        const ringGeo = new THREE.RingGeometry(0.12, 0.22, 24);
        const ringMat = new THREE.MeshBasicMaterial({
            color: pinColor,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.7
        });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.position.copy(basePos);
        ring.lookAt(new THREE.Vector3(0, 0, 0));
        globeGroup.add(ring);

        globeDisasterPins.push({
            mesh: pinMesh,
            line: line,
            ring: ring,
            hazard: hazard,
            colorHex: hexStr
        });
    });
}

function createDigitalEarthProceduralTexture() {
    const c = document.createElement("canvas");
    c.width = 1024;
    c.height = 512;
    const ctx = c.getContext("2d");

    ctx.fillStyle = "#030c1e";
    ctx.fillRect(0, 0, 1024, 512);

    ctx.strokeStyle = "rgba(6, 182, 212, 0.22)";
    ctx.lineWidth = 1;

    for (let x = 0; x < 1024; x += 64) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, 512);
        ctx.stroke();
    }
    for (let y = 0; y < 512; y += 48) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(1024, y);
        ctx.stroke();
    }

    ctx.fillStyle = "rgba(14, 165, 233, 0.35)";
    ctx.beginPath();
    ctx.ellipse(250, 180, 100, 70, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(320, 340, 70, 110, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(650, 160, 140, 90, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(580, 300, 80, 95, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(820, 360, 60, 45, 0, 0, Math.PI * 2);
    ctx.fill();

    return c;
}

// ------------------ DATA SYNC LOOP (HTTP REST API) ------------------
async function syncData() {
    try {
        // 1. Sync Resources Ledger
        const resRes = await fetch(`${API_BASE}/resources`);
        if (resRes.ok) {
            const stock = await resRes.json();
            document.getElementById("inv-ambulances").innerText = stock["Ambulances"] || 0;
            document.getElementById("inv-rescue-boats").innerText = stock["Rescue Boats"] || 0;
            document.getElementById("inv-medical-teams").innerText = stock["Medical Teams"] || 0;
            document.getElementById("inv-food-supplies").innerText = stock["Food Supplies"] || 0;
            document.getElementById("inv-shelters").innerText = stock["Shelters Available"] || 0;
        }

        // 2. Sync Disaster Hazards List
        const resHazards = await fetch(`${API_BASE}/hazards`);
        if (resHazards.ok) {
            const hazards = await resHazards.json();
            currentDisasters = hazards;
            updateDashboardMetrics(hazards);
            updateMapHazards(hazards);
            updateDisasterFeed(hazards);
            updateDatabaseTable(hazards);
            updateChartsData(hazards);
            updateResourceHazardSelect(hazards);
            checkNewDisasterAlerts(hazards);
        }

        // 3. Sync 48-Hour Early Warning & Evacuation Advisories
        fetchEarlyWarnings();

        // Set server link active
        const statusInd = document.getElementById("server-status");
        statusInd.className = "status-indicator active";
        statusInd.querySelector(".status-label").innerText = "SERVER LINK: ACTIVE";
        isOfflineMode = false;

    } catch (err) {
        // Set server link offline
        const statusInd = document.getElementById("server-status");
        statusInd.className = "status-indicator error";
        statusInd.querySelector(".status-label").innerText = "SERVER LINK: OFFLINE";

        // Enter offline simulation mode
        isOfflineMode = true;
        loadOfflineState();
    }
}

// Loads local mock database when Java Server is unavailable
function loadOfflineState() {
    currentDisasters = FALLBACK_HAZARDS;

    // 1. Draw Mock Inventory
    document.getElementById("inv-ambulances").innerText = localResourceInventory["Ambulances"];
    document.getElementById("inv-rescue-boats").innerText = localResourceInventory["Rescue Boats"];
    document.getElementById("inv-medical-teams").innerText = localResourceInventory["Medical Teams"];
    document.getElementById("inv-food-supplies").innerText = localResourceInventory["Food Supplies"];
    document.getElementById("inv-shelters").innerText = localResourceInventory["Shelters Available"];

    // 2. Update all tables, charts, map pins
    updateDashboardMetrics(FALLBACK_HAZARDS);
    updateMapHazards(FALLBACK_HAZARDS);
    updateDisasterFeed(FALLBACK_HAZARDS);
    updateDatabaseTable(FALLBACK_HAZARDS);
    updateChartsData(FALLBACK_HAZARDS);
    updateResourceHazardSelect(FALLBACK_HAZARDS);
    checkNewDisasterAlerts(FALLBACK_HAZARDS);
}

// ------------------ DASHBOARD METRIC FILTERS ------------------
function initDashboardFilters() {
    const filters = ["dash-filter-year", "dash-filter-type", "dash-filter-region"];
    filters.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener("change", () => {
                updateDashboardMetrics(currentDisasters);
            });
        }
    });

    const resetBtn = document.getElementById("dash-reset-filters");
    if (resetBtn) {
        resetBtn.addEventListener("click", () => {
            document.getElementById("dash-filter-year").value = "All";
            document.getElementById("dash-filter-type").value = "All";
            document.getElementById("dash-filter-region").value = "All";
            updateDashboardMetrics(currentDisasters);
        });
    }
}

function getFilteredHazards(hazards) {
    const yearEl = document.getElementById("dash-filter-year");
    const typeEl = document.getElementById("dash-filter-type");
    const regionEl = document.getElementById("dash-filter-region");

    if (!yearEl || !typeEl || !regionEl) return hazards;

    const yearVal = yearEl.value;
    const typeVal = typeEl.value;
    const regionVal = regionEl.value;

    return hazards.filter(h => {
        const matchesYear = yearVal === "All" || String(h.year) === yearVal;
        const matchesType = typeVal === "All" || h.type === typeVal;
        const matchesRegion = regionVal === "All" || h.location === regionVal;
        return matchesYear && matchesType && matchesRegion;
    });
}

// ------------------ DASHBOARD KPI METRICS ------------------
function updateDashboardMetrics(hazards) {
    const filtered = getFilteredHazards(hazards);

    document.getElementById("stat-total-disasters").innerText = filtered.length;

    const activeThreats = filtered.filter(h => h.status !== "Resolved").length;
    document.getElementById("stat-high-risk").innerText = activeThreats;

    const resolvedIncidents = filtered.filter(h => h.status === "Resolved").length;
    document.getElementById("stat-resolved-events").innerText = resolvedIncidents;

    const uniqueLocs = new Set(filtered.map(h => h.location));
    document.getElementById("stat-affected-areas").innerText = uniqueLocs.size;

    // Economic Impact
    const totalDamage = filtered.reduce((acc, h) => acc + parseFloat(h.damageCost || 0), 0);
    const formattedDamage = totalDamage >= 1000 ? `$${(totalDamage / 1000).toFixed(2)}B` : `$${totalDamage.toFixed(1)}M`;
    document.getElementById("stat-economic-impact").innerText = formattedDamage;

    // Civilians Affected
    const totalAffected = filtered.reduce((acc, h) => acc + parseInt(h.affectedPopulation || 0), 0);
    document.getElementById("stat-civilians-affected").innerText = totalAffected.toLocaleString();

    // Call sub-components updates
    updateResourceUtilization(hazards);
    updateSectorRanking(filtered);
    updateSystemTimeline(filtered);
}

// ------------------ RESOURCE UTILIZATION PROGRESS BARS ------------------
function updateResourceUtilization(hazards) {
    const container = document.getElementById("resource-utilization-list");
    if (!container) return;
    container.innerHTML = "";

    const resourceTypes = [
        { key: "Ambulances", icon: "fa-truck-medical", name: "Ambulances", capacity: 25 },
        { key: "Rescue Boats", icon: "fa-ship", name: "Rescue Boats", capacity: 15 },
        { key: "Medical Teams", icon: "fa-user-doctor", name: "Medical Teams", capacity: 40 },
        { key: "Food Supplies", icon: "fa-box-open", name: "Food Supplies Ration Kits", capacity: 800 },
        { key: "Shelters Available", icon: "fa-tents", name: "Emergency Shelters", capacity: 120 }
    ];

    resourceTypes.forEach(res => {
        let deployed = 0;
        hazards.forEach(h => {
            if (h.resourcesAllocated && h.resourcesAllocated[res.key]) {
                deployed += parseInt(h.resourcesAllocated[res.key]);
            }
        });

        const capacity = res.capacity;
        const available = Math.max(0, capacity - deployed);
        const utilizationPct = Math.round((deployed / capacity) * 100);

        let progressClass = "safe";
        if (utilizationPct > 80) progressClass = "danger";
        else if (utilizationPct > 50) progressClass = "warning";

        const row = document.createElement("div");
        row.className = "utilization-row";
        row.innerHTML = `
            <div class="utilization-info">
                <div class="utilization-name-wrapper">
                    <i class="fa-solid ${res.icon}"></i>
                    <span>${res.name.toUpperCase()}</span>
                </div>
                <span class="utilization-stats">${deployed} Deployed / ${available} Available (Cap: ${capacity})</span>
            </div>
            <div class="utilization-bar-wrapper">
                <div class="utilization-bar-bg">
                    <div class="utilization-bar-fill ${progressClass}" style="width: ${utilizationPct}%"></div>
                </div>
                <span class="utilization-pct font-orbitron">${utilizationPct}%</span>
            </div>
        `;
        container.appendChild(row);
    });
}

// ------------------ SECTOR RISK BREAKDOWN TABLE ------------------
function updateSectorRanking(hazards) {
    const tbody = document.getElementById("sector-ranking-tbody");
    if (!tbody) return;
    tbody.innerHTML = "";

    const sectors = [
        "Tamil Nadu & Coromandel Coast",
        "Kerala & Western Ghats",
        "Odisha & Bengal Coast",
        "Assam & North-East",
        "Uttarakhand & Himalayas",
        "Himachal & J&K Ranges",
        "Gujarat & Western Coast",
        "Indo-Gangetic & Central Plains"
    ];

    const sectorStats = sectors.map(sector => {
        const sectorHazards = hazards.filter(h => h.location === sector);
        const total = sectorHazards.length;
        const active = sectorHazards.filter(h => h.status !== "Resolved").length;
        const resolved = sectorHazards.filter(h => h.status === "Resolved").length;

        let avgRisk = 0;
        if (total > 0) {
            avgRisk = Math.round(sectorHazards.reduce((acc, h) => acc + parseInt(h.risk), 0) / total);
        }

        let maxSeverity = "Low";
        if (sectorHazards.some(h => h.severity === "Critical" && h.status !== "Resolved")) {
            maxSeverity = "Critical";
        } else if (sectorHazards.some(h => h.severity === "High" && h.status !== "Resolved")) {
            maxSeverity = "High";
        } else if (sectorHazards.some(h => h.severity === "Medium" && h.status !== "Resolved")) {
            maxSeverity = "Medium";
        }

        return { sector, total, active, resolved, avgRisk, maxSeverity };
    });

    // Sort by incident count descending
    sectorStats.sort((a, b) => b.total - a.total);

    sectorStats.forEach(stat => {
        const tr = document.createElement("tr");

        let severityColor = "var(--text-dimmed)";
        let severityGlow = "none";
        if (stat.maxSeverity === "Critical") {
            severityColor = "var(--color-red)";
            severityGlow = "0 0 8px var(--color-red-glow)";
        } else if (stat.maxSeverity === "High") {
            severityColor = "var(--color-orange)";
            severityGlow = "0 0 8px var(--color-orange-glow)";
        } else if (stat.maxSeverity === "Medium") {
            severityColor = "var(--color-cyan)";
            severityGlow = "0 0 8px var(--color-cyan-glow)";
        }

        tr.innerHTML = `
            <td class="ranking-sector-name">${stat.sector}</td>
            <td class="ranking-sector-incidents font-orbitron">${stat.total}</td>
            <td class="ranking-sector-ratio">${stat.active} <span style="color:var(--text-dimmed);">/</span> <span style="color:var(--color-green);">${stat.resolved}</span></td>
            <td class="ranking-sector-risk font-orbitron" style="color: ${stat.avgRisk >= 75 ? 'var(--color-red)' : stat.avgRisk >= 50 ? 'var(--color-orange)' : 'var(--color-green)'}">${stat.avgRisk}%</td>
            <td class="ranking-sector-threat"><span class="badge" style="color:${severityColor}; border-color:${severityColor}; background:rgba(255,255,255,0.01); text-shadow:${severityGlow}; box-shadow:${severityGlow ? 'inset ' + severityGlow : 'none'};">${stat.maxSeverity.toUpperCase()}</span></td>
        `;
        tbody.appendChild(tr);
    });
}

// ------------------ CHRONOLOGICAL SYSTEM TIMELINE ------------------
function updateSystemTimeline(hazards) {
    const container = document.getElementById("system-timeline-feed");
    if (!container) return;
    container.innerHTML = "";

    let events = [];

    hazards.forEach(h => {
        const baseTime = new Date(h.timestamp.replace(/-/g, "/"));

        // 1. Creation event
        events.push({
            type: "alert",
            icon: "fa-triangle-exclamation",
            text: `Critical hazard: ${h.type} reported in ${h.city ? h.city + ' (' + h.location + ')' : h.location} exposing ${(h.affectedPopulation || 0).toLocaleString()} residents (ID: #${h.id}, Risk: ${h.risk}%).`,
            time: baseTime,
            timeStr: h.timestamp
        });

        // 2. Resource Dispatch event (if resources are allocated)
        const keys = Object.keys(h.resourcesAllocated || {});
        if (keys.length > 0) {
            const dispatchTime = new Date(baseTime.getTime() + 5 * 60 * 1000); // 5 mins later
            const resourcesStr = keys.map(k => `${h.resourcesAllocated[k]}x ${k}`).join(", ");
            const formattedTime = formatDateForTimeline(dispatchTime);
            events.push({
                type: "logistics",
                icon: "fa-truck-ramp-box",
                text: `Logistics: ${resourcesStr} dispatched to ${h.city || h.location} to safeguard living population.`,
                time: dispatchTime,
                timeStr: formattedTime
            });
        }

        // 3. Resolution event (if status is Resolved)
        if (h.status === "Resolved") {
            const resolveTime = new Date(baseTime.getTime() + 90 * 60 * 1000); // 1.5 hours later
            const formattedTime = formatDateForTimeline(resolveTime);
            events.push({
                type: "resolve",
                icon: "fa-circle-check",
                text: `Mitigation complete: Disaster Event #${h.id} (${h.type}) in ${h.city || h.location} marked as RESOLVED.`,
                time: resolveTime,
                timeStr: formattedTime
            });
        }
    });

    // Sort events by date descending
    events.sort((a, b) => b.time - a.time);

    // Limit to latest 10 events
    const latestEvents = events.slice(0, 10);

    if (latestEvents.length === 0) {
        container.innerHTML = `<div style="color:var(--text-dimmed); text-align:center; font-size:11px; padding:20px;">No system events for current search filters.</div>`;
        return;
    }

    latestEvents.forEach(evt => {
        const item = document.createElement("div");
        item.className = `timeline-item ${evt.type}`;
        item.innerHTML = `
            <div class="timeline-marker">
                <i class="fa-solid ${evt.icon}"></i>
            </div>
            <div class="timeline-content">
                <span class="timeline-text">${evt.text}</span>
                <span class="timeline-time">${evt.timeStr}</span>
            </div>
        `;
        container.appendChild(item);
    });
}

function formatDateForTimeline(date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    const hh = String(date.getHours()).padStart(2, '0');
    const mm = String(date.getMinutes()).padStart(2, '0');
    const ss = String(date.getSeconds()).padStart(2, '0');
    return `${y}-${m}-${d} ${hh}:${mm}:${ss}`;
}

// ------------------ TACTICAL MAP HAZARD MARKERS ------------------
function updateMapHazards(hazards) {
    hazards.forEach(hazard => {
        const id = hazard.id;
        const lat = parseFloat(hazard.lat);
        const lng = parseFloat(hazard.lng);

        let markerColor = "#EF4444"; // Red for Critical/High
        let shadowColor = "var(--color-red-glow)";
        if (hazard.severity === "Medium") {
            markerColor = "#F59E0B"; // Orange
            shadowColor = "var(--color-orange-glow)";
        } else if (hazard.severity === "Low") {
            markerColor = "#FBBF24"; // Yellow
        }

        if (hazard.status === "Resolved") {
            markerColor = "#10B981"; // Green
            shadowColor = "var(--color-green-glow)";
        }

        const tooltipContent = `
            <div style="font-family:'Outfit',sans-serif; color:#FFF; font-size:11px; min-width:190px;">
                <b style="color:${markerColor}">DISASTER INCIDENT [ID: #${id}]</b><br>
                <b>Populated Area:</b> ${hazard.city || hazard.location}<br>
                <b>Civilians Living Here:</b> ${(hazard.affectedPopulation || 0).toLocaleString()} residents<br>
                <b>Sector:</b> ${hazard.location}<br>
                <b>Type:</b> ${hazard.type}<br>
                <b>Risk Score:</b> ${hazard.risk}% (${hazard.severity})<br>
                <b>Status:</b> ${hazard.status}<br>
                <b>Year:</b> ${hazard.year} (${hazard.timestamp})
            </div>
        `;

        if (hazardMarkers[id]) {
            hazardMarkers[id].setLatLng([lat, lng]);
            hazardMarkers[id].getPopup().setContent(tooltipContent);

            const div = hazardMarkers[id].getElement();
            if (div) {
                const markerDot = div.querySelector(".hazard-pulse-dot");
                if (markerDot) {
                    markerDot.style.backgroundColor = markerColor;
                    markerDot.style.boxShadow = `0 0 10px ${shadowColor}`;
                    if (hazard.status === "Resolved") {
                        markerDot.classList.remove("pulse-anim");
                    }
                }
            }
        } else {
            const isPulse = hazard.status !== "Resolved" ? "pulse-anim" : "";
            const hIcon = L.divIcon({
                className: `custom-hazard-marker-${id}`,
                html: `<div class="hazard-pulse-dot ${isPulse}" style="background-color: ${markerColor}; width: 12px; height: 12px; border-radius: 50%; border: 2px solid #FFF; box-shadow: 0 0 10px ${shadowColor};"></div>`,
                iconSize: [12, 12],
                iconAnchor: [6, 6]
            });

            const newMarker = L.marker([lat, lng], { icon: hIcon }).addTo(map);
            newMarker.bindPopup(tooltipContent);
            newMarker.on("click", () => {
                drawOptimizedRoute(lat, lng, hazard.city || hazard.location, id);
            });
            hazardMarkers[id] = newMarker;
        }
    });

    // Remove deleted hazard markers
    const incomingIds = new Set(hazards.map(h => h.id));
    Object.keys(hazardMarkers).forEach(existingId => {
        if (!incomingIds.has(parseInt(existingId))) {
            map.removeLayer(hazardMarkers[existingId]);
            delete hazardMarkers[existingId];
        }
    });

    // Sync 3D Digital Earth Globe pins
    if (typeof updateGlobeBeacons === "function") {
        updateGlobeBeacons(hazards);
    }
}

// ------------------ NEW DISASTER WARNING MODALS & SIRENS ------------------
function checkNewDisasterAlerts(hazards) {
    hazards.forEach(hazard => {
        if (!knownHazardIds.has(hazard.id)) {
            knownHazardIds.add(hazard.id);

            // Trigger alerts for new Pending reports
            if (hazard.status === "Pending" && !acknowledgedAlertIds.has(hazard.id)) {
                document.getElementById("modal-alert-id").innerText = hazard.id;
                document.getElementById("modal-alert-type").innerText = hazard.type;
                document.getElementById("modal-alert-loc").innerText = hazard.location;
                document.getElementById("modal-alert-gps").innerText = `${parseFloat(hazard.lat).toFixed(4)}, ${parseFloat(hazard.lng).toFixed(4)}`;
                document.getElementById("modal-alert-risk").innerText = `${hazard.risk}%`;
                document.getElementById("modal-alert-severity").innerText = hazard.severity;

                document.getElementById("alert-modal").classList.remove("hidden");

                const banner = document.getElementById("global-alert-banner");
                banner.querySelector(".alert-text").innerText = `CRITICAL HAZARD DETECTED: ${hazard.type.toUpperCase()} ACTIVE AT ${hazard.location.toUpperCase()} (ID: ${hazard.id})`;
                banner.classList.remove("hidden");

                playSiren();
            }
        }
    });
}

// Web Audio API siren generator
function playSiren() {
    try {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }

        if (sirenInterval) return;

        sirenInterval = setInterval(() => {
            if (!audioCtx) return;
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);

            osc.type = "sawtooth";
            const now = audioCtx.currentTime;

            osc.frequency.setValueAtTime(450, now);
            osc.frequency.linearRampToValueAtTime(850, now + 0.35);
            osc.frequency.linearRampToValueAtTime(450, now + 0.7);

            gain.gain.setValueAtTime(0.06, now);
            gain.gain.linearRampToValueAtTime(0.001, now + 0.7);

            osc.start(now);
            osc.stop(now + 0.7);
        }, 750);
    } catch (e) {
        console.error("Audio Context Init error:", e);
    }
}

function stopSiren() {
    if (sirenInterval) {
        clearInterval(sirenInterval);
        sirenInterval = null;
    }
}

// Acknowledge logic
function acknowledgeCurrentCrisis() {
    stopSiren();
    document.getElementById("alert-modal").classList.add("hidden");
    document.getElementById("global-alert-banner").classList.add("hidden");

    currentDisasters.forEach(h => {
        acknowledgedAlertIds.add(h.id);
    });
}

// ------------------ DISASTER DISPATCH FEED ------------------
function updateDisasterFeed(hazards) {
    const list = document.getElementById("active-feed-list");
    const activeHazards = hazards.filter(h => h.status !== "Resolved");

    if (activeHazards.length === 0) {
        list.innerHTML = `<div class="feed-empty">No active disasters requiring response.</div>`;
        return;
    }

    list.innerHTML = "";
    activeHazards.forEach(h => {
        const item = document.createElement("div");
        const sevClass = h.severity.toLowerCase();

        item.className = `feed-item ${sevClass === 'critical' ? 'critical' : ''} ${h.status === 'Resolved' ? 'resolved' : ''}`;

        let allocatedStr = "None";
        const keys = Object.keys(h.resourcesAllocated || {});
        if (keys.length > 0) {
            allocatedStr = keys.map(k => `${h.resourcesAllocated[k]} ${k.split(' ')[0]}`).join(", ");
        }

        const citySafe = (h.city || h.location).replace(/'/g, "\\'");

        item.innerHTML = `
            <div class="feed-desc">
                <div class="feed-title">
                    <span>DISASTER EVENT #${h.id}: ${h.type}</span>
                    <span class="badge ${sevClass}">${h.severity} (${h.risk}%)</span>
                </div>
                <div class="feed-meta">
                    <span><i class="fa-solid fa-city" style="color:var(--accent-cyan);"></i> <b>${h.city || h.location}</b></span>
                    <span><i class="fa-solid fa-users" style="color:var(--accent-amber);"></i> Pop: ${(h.affectedPopulation || 0).toLocaleString()} residents</span>
                    <span><i class="fa-solid fa-map-pin"></i> ${h.location} (${parseFloat(h.lat).toFixed(4)}, ${parseFloat(h.lng).toFixed(4)})</span>
                    <span><i class="fa-solid fa-truck"></i> Allocated: ${allocatedStr}</span>
                    <span><i class="fa-solid fa-calendar-day"></i> ${h.timestamp}</span>
                </div>
            </div>
            <button class="table-action-btn" onclick="quickActionCenterMap(${h.lat}, ${h.lng}, '${citySafe}', ${h.id})">
                <i class="fa-solid fa-crosshairs"></i> GOTO MAP
            </button>
        `;
        list.appendChild(item);
    });
}

// Zoom map shortcut
window.quickActionCenterMap = function (lat, lng, locationName, id) {
    document.getElementById("report-lat").value = lat.toFixed(6);
    document.getElementById("report-lng").value = lng.toFixed(6);

    document.getElementById("tab-btn-tactical").click();

    if (map) {
        map.setView([lat, lng], 6);
    }

    if (id) {
        setTimeout(() => {
            drawOptimizedRoute(lat, lng, locationName, id);
        }, 150);
    }
};

// ------------------ DISASTER DATABASE LOGS TABLE ------------------
function updateDatabaseTable(hazards) {
    const tbody = document.getElementById("records-table-body");

    const searchVal = document.getElementById("db-search").value.toLowerCase();
    const yearVal = document.getElementById("db-filter-year").value;
    const typeVal = document.getElementById("db-filter-type").value;
    const statVal = document.getElementById("db-filter-status").value;

    const filtered = hazards.filter(h => {
        const matchesSearch = h.location.toLowerCase().includes(searchVal) ||
            (h.city && h.city.toLowerCase().includes(searchVal)) ||
            h.type.toLowerCase().includes(searchVal) ||
            String(h.id).includes(searchVal);
        const matchesYear = yearVal === "All" || String(h.year) === yearVal;
        const matchesType = typeVal === "All" || h.type === typeVal;
        const matchesStat = statVal === "All" || h.status === statVal;
        return matchesSearch && matchesYear && matchesType && matchesStat;
    });

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="14" style="text-align:center; color:var(--text-dimmed);">No logs match the current search filters.</td></tr>`;
        return;
    }

    tbody.innerHTML = "";
    filtered.forEach(h => {
        let resourcesStr = "None";
        const keys = Object.keys(h.resourcesAllocated || {});
        if (keys.length > 0) {
            resourcesStr = keys.map(k => `${h.resourcesAllocated[k]} x ${k}`).join(", ");
        }

        const tr = document.createElement("tr");

        let sevColor = "var(--color-cyan)";
        if (h.severity === "Critical") sevColor = "var(--color-red)";
        else if (h.severity === "High") sevColor = "var(--color-orange)";
        else if (h.severity === "Medium") sevColor = "#A855F7";

        tr.innerHTML = `
            <td>#${h.id}</td>
            <td>${h.year}</td>
            <td>${h.timestamp}</td>
            <td>${h.location}</td>
            <td style="font-weight:600; color:#E0F2FE;"><i class="fa-solid fa-city" style="color:var(--accent-cyan); font-size:11px; margin-right:4px;"></i>${h.city || h.location}</td>
            <td class="font-orbitron" style="color:#FBBF24;">${(h.affectedPopulation || 0).toLocaleString()}</td>
            <td class="font-orbitron">${parseFloat(h.lat).toFixed(4)}</td>
            <td class="font-orbitron">${parseFloat(h.lng).toFixed(4)}</td>
            <td><i class="fa-solid fa-triangle-exclamation"></i> ${h.type}</td>
            <td class="font-orbitron" style="font-weight:700;">${h.risk}%</td>
            <td style="color:${sevColor}; font-weight:700;">${h.severity}</td>
            <td>
                <span class="status-cell ${h.status.toLowerCase().replace(/ /g, '-')}">
                    <span class="status-dot-cell"></span>
                    <span>${h.status}</span>
                </span>
            </td>
            <td>${resourcesStr}</td>
            <td>
                ${h.status !== 'Resolved' ? `<button class="table-action-btn" onclick="quickAllocateResource(${h.id})">DISPATCH RELIEF</button>` : `<span style="color:var(--color-green); font-size:10px;"><i class="fa-solid fa-circle-check"></i> RESOLVED</span>`}
            </td>
        `;
        tbody.appendChild(tr);
    });
}

window.quickAllocateResource = function (hazardId) {
    document.getElementById("allocate-hazard-id").value = hazardId;
    document.getElementById("tab-btn-tactical").click();

    const hazard = currentDisasters.find(d => d.id == hazardId);
    if (hazard) {
        setTimeout(() => {
            if (map) {
                map.setView([parseFloat(hazard.lat), parseFloat(hazard.lng)], 6);
            }
            drawOptimizedRoute(parseFloat(hazard.lat), parseFloat(hazard.lng), hazard.location, hazardId);
        }, 200);
    }
};

function initDatabaseFilters() {
    const filters = ["db-search", "db-filter-year", "db-filter-type", "db-filter-status"];
    filters.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener("input", () => {
                updateDatabaseTable(currentDisasters);
            });
        }
    });
}

// ------------------ DASHBOARD METRIC FILTER TOOLBAR (Module 5 & 8) ------------------
let currentDashboardFilter = {
    year: "All",
    type: "All",
    region: "All"
};

function initDashboardFilters() {
    const yearSelect = document.getElementById("dash-filter-year");
    const typeSelect = document.getElementById("dash-filter-type");
    const regionSelect = document.getElementById("dash-filter-region");
    const resetBtn = document.getElementById("dash-reset-filters");

    async function applyDashboardFilters() {
        const year = yearSelect ? yearSelect.value : "All";
        const type = typeSelect ? typeSelect.value : "All";
        const region = regionSelect ? regionSelect.value : "All";

        currentDashboardFilter = { year, type, region };

        try {
            const url = `${API_BASE}/dashboard/stats?year=${encodeURIComponent(year)}&type=${encodeURIComponent(type)}&region=${encodeURIComponent(region)}`;
            const res = await fetch(url);
            if (res.ok) {
                const stats = await res.json();
                updateDashboardWithFilterStats(stats);
                const statusTxt = document.getElementById("dash-backend-status-txt");
                if (statusTxt) statusTxt.innerText = "Java Backend: Synced (Port 8080)";
                return;
            }
        } catch (e) {
            console.warn("Could not query /api/dashboard/stats, applying client-side filter fallback", e);
            const statusTxt = document.getElementById("dash-backend-status-txt");
            if (statusTxt) statusTxt.innerText = "Offline Mode: Local Filter";
        }

        // Client-side fallback if backend request is unreachable
        const filtered = currentDisasters.filter(h => {
            const matchesYear = year === "All" || String(h.year) === year;
            const matchesType = type === "All" || (h.type && h.type.toLowerCase().includes(type.toLowerCase()));
            const matchesRegion = region === "All" || (h.location && h.location.toLowerCase().includes(region.toLowerCase()));
            return matchesYear && matchesType && matchesRegion;
        });

        let totalPop = 0;
        let totalDamage = 0;
        filtered.forEach(h => {
            totalPop += (h.affectedPopulation || 0);
            totalDamage += (h.damageCost || 0);
        });

        const countTxt = document.getElementById("dash-filter-count-txt");
        if (countTxt) {
            countTxt.innerText = `Showing ${filtered.length} Incidents`;
        }
        const popEl = document.getElementById("stat-civilians-affected");
        if (popEl) popEl.innerText = totalPop.toLocaleString();
        const damEl = document.getElementById("stat-economic-impact");
        if (damEl) damEl.innerText = `$${totalDamage.toFixed(1)}M`;
        const sectorsEl = document.getElementById("stat-affected-areas");
        if (sectorsEl) sectorsEl.innerText = filtered.length;

        updateDisasterFeed(filtered);
    }

    if (yearSelect) yearSelect.addEventListener("change", applyDashboardFilters);
    if (typeSelect) typeSelect.addEventListener("change", applyDashboardFilters);
    if (regionSelect) regionSelect.addEventListener("change", applyDashboardFilters);

    if (resetBtn) {
        resetBtn.addEventListener("click", () => {
            if (yearSelect) yearSelect.value = "All";
            if (typeSelect) typeSelect.value = "All";
            if (regionSelect) regionSelect.value = "All";
            applyDashboardFilters();
        });
    }
}

function updateDashboardWithFilterStats(stats) {
    if (!stats) return;

    // 1. Update filter counter badge
    const countTxt = document.getElementById("dash-filter-count-txt");
    if (countTxt) {
        countTxt.innerText = `Showing ${stats.filteredCount} / ${stats.totalHazardsInDb} Incidents`;
    }

    // 2. Update KPI cards
    const popEl = document.getElementById("stat-civilians-affected");
    if (popEl && stats.totalAffectedPopulation !== undefined) {
        popEl.innerText = stats.totalAffectedPopulation.toLocaleString();
    }
    const damEl = document.getElementById("stat-economic-impact");
    if (damEl && stats.totalDamageCostCr !== undefined) {
        damEl.innerText = `$${stats.totalDamageCostCr}M`;
    }
    const sectorsEl = document.getElementById("stat-affected-areas");
    if (sectorsEl && stats.filteredCount !== undefined) {
        sectorsEl.innerText = stats.filteredCount;
    }

    // 3. Update Disaster Feed with matching hazards if provided
    if (stats.matchingHazards && stats.matchingHazards.length > 0) {
        updateDisasterFeed(stats.matchingHazards);
    }
}


// ------------------ FORMS & ACTION HANDLERS ------------------
function initFormHandlers() {
    // 1. Log Manual Incident Form
    const reportForm = document.getElementById("report-form");
    reportForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const location = document.getElementById("report-region").value;
        const cityEl = document.getElementById("report-city");
        const city = cityEl && cityEl.value ? cityEl.value.trim() : location;
        const popEl = document.getElementById("report-population");
        const pop = popEl && parseInt(popEl.value) > 0 ? parseInt(popEl.value) : Math.floor(parseInt(document.getElementById("report-risk").value) * 100 + 15000);
        const type = document.getElementById("report-type").value;
        const lat = parseFloat(document.getElementById("report-lat").value);
        const lng = parseFloat(document.getElementById("report-lng").value);
        const risk = parseInt(document.getElementById("report-risk").value);

        if (isOfflineMode) {
            // Local simulation reporting when backend is offline
            const newId = Math.max(...FALLBACK_HAZARDS.map(h => h.id), 0) + 1;
            const now = new Date();
            const pad = (n) => String(n).padStart(2, '0');
            const timeStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;

            const newHazard = {
                id: newId,
                year: now.getFullYear(),
                location: location,
                city: city,
                lat: lat,
                lng: lng,
                type: type,
                risk: risk,
                severity: risk >= 85 ? "Critical" : (risk >= 70 ? "High" : (risk >= 40 ? "Medium" : "Low")),
                affectedPopulation: pop,
                damageCost: parseFloat((risk * 5.5 / 10.0).toFixed(1)),
                status: "Pending",
                timestamp: timeStr,
                resourcesAllocated: {}
            };

            FALLBACK_HAZARDS.push(newHazard);
            alert(`Incident successfully registered (OFFLINE PREVIEW). ID: #${newId} at ${city}. Broadcast alarm triggered.`);

            if (clickTargetMarker) {
                map.removeLayer(clickTargetMarker);
                clickTargetMarker = null;
            }
            loadOfflineState();
            return;
        }

        try {
            const res = await fetch(`${API_BASE}/hazards`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    location: location,
                    city: city,
                    type: type,
                    lat: String(lat),
                    lng: String(lng),
                    risk: String(risk),
                    affectedPopulation: String(pop)
                })
            });
            const data = await res.json();
            if (res.ok) {
                alert(`Incident successfully registered. ID: #${data.id}. Broadcast alarm triggered.`);

                if (clickTargetMarker) {
                    map.removeLayer(clickTargetMarker);
                    clickTargetMarker = null;
                }
                syncData();
            } else {
                alert("Logging failed: " + data.error);
            }
        } catch (err) {
            alert("Error sending disaster log: Connection offline.");
        }
    });

    // Severity level text output link for reporter form
    const repRisk = document.getElementById("report-risk");
    const repRiskVal = document.getElementById("val-report-risk");
    repRisk.addEventListener("input", () => {
        repRiskVal.innerText = repRisk.value + "%";
    });

    // 2. Resource Allocation Form
    const allocateForm = document.getElementById("allocate-form");
    allocateForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const hazardId = parseInt(document.getElementById("allocate-hazard-id").value);
        const resType = document.getElementById("allocate-resource-type").value;
        const qty = parseInt(document.getElementById("allocate-qty").value);

        if (isOfflineMode) {
            // Local simulation allocation
            if (localResourceInventory[resType] < qty) {
                alert("Insufficient stock in offline inventory ledger!");
                return;
            }

            const hazard = FALLBACK_HAZARDS.find(h => h.id === hazardId);
            if (hazard) {
                localResourceInventory[resType] -= qty;
                hazard.resourcesAllocated[resType] = (hazard.resourcesAllocated[resType] || 0) + qty;
                hazard.status = "Resources Dispatched";
                alert(`Successfully allocated ${qty} units of ${resType} to Disaster #${hazardId} (OFFLINE PREVIEW).`);
                allocateForm.reset();
                loadOfflineState();
            } else {
                alert("Disaster event not found!");
            }
            return;
        }

        try {
            const res = await fetch(`${API_BASE}/resources`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    hazardId: String(hazardId),
                    resourceType: resType,
                    quantity: String(qty)
                })
            });
            const data = await res.json();
            if (res.ok) {
                alert(`Dispatched ${qty} of ${resType} to Disaster #${hazardId}.`);
                allocateForm.reset();
                syncData();
            } else {
                alert("Dispatch failed: " + data.error);
            }
        } catch (err) {
            alert("Error dispatching aid resources: Connection offline.");
        }
    });

    // Helper: Local client-side mathematical prediction model (offline / resilience backup)
    function calculateLocalPrediction(location, type, temp, humidity, wind, soil) {
        const pool = (Array.isArray(currentDisasters) && currentDisasters.length > 0) ? currentDisasters : FALLBACK_HAZARDS;
        const locLower = (location || "").toLowerCase();
        const typeLower = (type || "").toLowerCase();

        const exactMatches = pool.filter(h => {
            const hLoc = (h.location || "").toLowerCase();
            const hCity = (h.city || "").toLowerCase();
            const hType = (h.type || "").toLowerCase();
            const typeMatch = hType === typeLower;
            const locMatch = hLoc.includes(locLower) || locLower.includes(hLoc) || hCity.includes(locLower) || locLower.includes(hCity);
            return typeMatch && locMatch;
        }).length;

        const typeMatches = pool.filter(h => (h.type || "").toLowerCase() === typeLower).length;
        const coeff = exactMatches / 10.0;

        let base = 30.0 + (coeff * 50.0) + (typeMatches * 1.5);
        if (type === "Wildfire") {
            base += (temp - 25.0) * 1.4 - (humidity - 40.0) * 0.7 + (wind - 15.0) * 0.4 - (soil - 30.0) * 0.4;
        } else if (type === "Flash Flood") {
            base += (humidity - 50.0) * 0.6 + (soil - 40.0) * 1.2 - (temp - 20.0) * 0.1;
        } else if (type === "Landslide") {
            base += (soil - 45.0) * 1.5 + (coeff * 20.0);
        } else if (type === "Hurricane") {
            base += (wind - 40.0) * 1.3 + (humidity - 60.0) * 0.8;
        } else {
            base += (wind - 20.0) * 0.5 + (humidity - 50.0) * 0.3;
        }

        const riskScore = Math.max(10, Math.min(98, Math.round(base)));
        const severity = riskScore >= 85 ? "Critical" : (riskScore >= 70 ? "High" : (riskScore >= 40 ? "Medium" : "Low"));
        const confidence = exactMatches >= 3 ? 94 : (exactMatches === 2 ? 88 : (exactMatches === 1 ? 80 : 72));

        const recommendations = [];
        if (type === "Wildfire") {
            recommendations.push("Enforce strict outdoor open fire regulations.");
            recommendations.push("Pre-stage flame retardant trucks at border checkpoints.");
            recommendations.push("Activate evacuation notification networks for adjacent neighborhoods.");
        } else if (type === "Flash Flood") {
            recommendations.push("Verify integrity of storm gutters and flood channels.");
            recommendations.push("Alert traffic channels to flag flooded road lanes.");
            recommendations.push("Pre-position rescue zodiacs in drainage zones.");
        } else if (type === "Landslide") {
            recommendations.push("Mount laser sensors on critical hillside geological strata.");
            recommendations.push("Enforce temporary speed limits on high-altitude roads.");
            recommendations.push("Clear catchment basins of tree debris and boulders.");
        } else if (type === "Hurricane") {
            recommendations.push("Instruct shoreline facilities to board and shutter windows.");
            recommendations.push("Set up outbound-only evacuation pathways going inland.");
            recommendations.push("Configure emergency generators at high-priority municipal sites.");
        } else {
            recommendations.push("Increase local visual sentinel monitoring schedules.");
            recommendations.push("Align response timelines with civilian rescue branches.");
        }

        return {
            location: location,
            disasterType: type,
            riskScore: riskScore,
            severity: severity,
            confidence: confidence,
            matchedHistoryCount: exactMatches,
            historicalFreqCoeff: coeff,
            recommendations: recommendations
        };
    }

    let lastCalculatedPrediction = null;

    // Helper: Safely renders prediction results into DOM without throwing null reference errors
    function renderPredictionResult(data) {
        if (!data) return;
        lastCalculatedPrediction = data;

        const score = typeof data.riskScore === "number" ? data.riskScore : (parseInt(data.riskScore, 10) || 50);
        const severity = data.severity || (score >= 85 ? "Critical" : (score >= 70 ? "High" : (score >= 40 ? "Medium" : "Low")));
        const confidence = data.confidence !== undefined ? data.confidence : 85;
        const matches = data.matchedHistoryCount !== undefined ? data.matchedHistoryCount : 0;
        const coeff = typeof data.historicalFreqCoeff === "number" ? data.historicalFreqCoeff : (parseFloat(data.historicalFreqCoeff) || 0.0);
        const location = data.location || "Tamil Nadu & Coromandel Coast";
        const disasterType = data.disasterType || data.type || "Flash Flood";

        const riskEl = document.getElementById("res-risk-val");
        if (riskEl) riskEl.innerText = `${score}%`;

        const confEl = document.getElementById("res-confidence-val");
        if (confEl) confEl.innerText = `${confidence}%`;

        const matchesEl = document.getElementById("res-matches-val");
        if (matchesEl) matchesEl.innerText = `${matches} matches`;

        const freqEl = document.getElementById("res-freq-val");
        if (freqEl) freqEl.innerText = `${coeff.toFixed(2)} events/year`;

        const locEl = document.getElementById("res-location-val");
        if (locEl) locEl.innerText = location;

        const sevBadge = document.getElementById("res-severity-val");
        if (sevBadge) {
            sevBadge.innerText = severity.toUpperCase();
            sevBadge.className = `badge badge-lg badge-${severity.toLowerCase()}`;
        }

        const circle = document.getElementById("gauge-fill-circle");
        if (circle) {
            const circumference = 314;
            const offset = circumference - (circumference * score / 100);
            circle.style.strokeDashoffset = offset;

            const sevLower = severity.toLowerCase();
            if (sevLower === "critical") circle.style.stroke = "var(--color-red)";
            else if (sevLower === "high") circle.style.stroke = "var(--color-orange)";
            else if (sevLower === "medium") circle.style.stroke = "var(--color-purple)";
            else circle.style.stroke = "var(--color-green)";
        }

        // Render 10-Year Kaggle Precedent Records
        const precedentsList = document.getElementById("pred-precedents-list");
        const precedentsSummary = document.getElementById("pred-matched-summary");
        if (precedentsList) {
            precedentsList.innerHTML = "";
            const pool = (Array.isArray(currentDisasters) && currentDisasters.length > 0) ? currentDisasters : FALLBACK_HAZARDS;
            const locLower = location.toLowerCase();
            const typeLower = disasterType.toLowerCase();

            let matchedRecords = pool.filter(h => {
                const hLoc = (h.location || "").toLowerCase();
                const hCity = (h.city || "").toLowerCase();
                const hType = (h.type || "").toLowerCase();
                return hType === typeLower && (hLoc.includes(locLower) || locLower.includes(hLoc) || hCity.includes(locLower) || locLower.includes(hCity));
            });

            if (matchedRecords.length === 0) {
                // Secondary fallback: match type only
                matchedRecords = pool.filter(h => (h.type || "").toLowerCase() === typeLower);
            }

            if (precedentsSummary) {
                precedentsSummary.innerText = `${matchedRecords.length} historical Kaggle record${matchedRecords.length === 1 ? '' : 's'} identified`;
            }

            const topRecords = matchedRecords.slice(0, 3);
            if (topRecords.length > 0) {
                topRecords.forEach(rec => {
                    const card = document.createElement("div");
                    card.className = "precedent-card";
                    const yr = rec.year || 2023;
                    const sev = rec.severity || "High";
                    const loc = rec.city || rec.location || location;
                    const pop = rec.affectedPopulation ? rec.affectedPopulation.toLocaleString() : "140,000";
                    const dmg = rec.damageCost ? `${rec.damageCost} Cr` : "32 Cr";
                    card.innerHTML = `
                        <div class="precedent-top">
                            <span class="precedent-year">${yr}</span>
                            <span class="badge badge-${sev.toLowerCase()}" style="font-size: 9px; padding: 1px 6px;">${sev.toUpperCase()}</span>
                        </div>
                        <div class="precedent-locality" title="${loc}">${loc}</div>
                        <div class="precedent-impact">
                            <span><i class="fa-solid fa-users" style="color:#38bdf8; margin-right:3px;"></i>${pop}</span>
                            <span><i class="fa-solid fa-indian-rupee-sign" style="color:#f59e0b; margin-right:2px;"></i>${dmg}</span>
                        </div>
                    `;
                    precedentsList.appendChild(card);
                });
            } else {
                precedentsList.innerHTML = `<div style="font-size:11px; color:#94a3b8; padding:8px 0;">No exact 10-year duplicate events found for this specific micro-corridor. Neural heuristic baseline applied.</div>`;
            }
        }

        // Actionable Mitigation Protocols
        const recsList = document.getElementById("res-recs-list");
        if (recsList) {
            recsList.innerHTML = "";
            const list = Array.isArray(data.recommendations) && data.recommendations.length > 0
                ? data.recommendations
                : ["Enforce strict regional hazard monitoring.", "Alert local disaster mitigation quick response teams."];
            list.forEach(rec => {
                const li = document.createElement("li");
                li.innerText = rec;
                recsList.appendChild(li);
            });
        }

        // Evacuation & Municipal Threat Exposure
        const expBadge = document.getElementById("pred-exposure-badge");
        const estPop = document.getElementById("pred-est-pop");
        const estBuffer = document.getElementById("pred-est-buffer");
        const estShelters = document.getElementById("pred-est-shelters");

        if (score >= 85) {
            if (expBadge) { expBadge.innerText = "CRITICAL THREAT EXPOSURE"; expBadge.className = "badge badge-critical"; }
            if (estPop) estPop.innerText = "52,000 citizens in flood margins";
            if (estBuffer) estBuffer.innerText = "~15.2 km² Inundation Zone";
            if (estShelters) estShelters.innerText = "18 Designated RCC Centers (Active)";
        } else if (score >= 70) {
            if (expBadge) { expBadge.innerText = "HIGH THREAT EXPOSURE"; expBadge.className = "badge badge-high"; }
            if (estPop) estPop.innerText = "24,500 citizens at risk";
            if (estBuffer) estBuffer.innerText = "~8.4 km² Zone";
            if (estShelters) estShelters.innerText = "12 Designated Shelters Ready";
        } else if (score >= 40) {
            if (expBadge) { expBadge.innerText = "MODERATE WATCH STATUS"; expBadge.className = "badge badge-medium"; }
            if (estPop) estPop.innerText = "8,200 citizens in catchment";
            if (estBuffer) estBuffer.innerText = "~3.6 km² Sector";
            if (estShelters) estShelters.innerText = "6 Primary Shelters Staged";
        } else {
            if (expBadge) { expBadge.innerText = "LOW RISK / NORMAL MONITORING"; expBadge.className = "badge badge-low"; }
            if (estPop) estPop.innerText = "< 2,000 citizens";
            if (estBuffer) estBuffer.innerText = "Baseline Drainage Margin";
            if (estShelters) estShelters.innerText = "Standard Municipal Readiness";
        }

        const resultPlaceholder = document.getElementById("pred-result-placeholder");
        const resultBody = document.getElementById("pred-result-body");
        if (resultPlaceholder) resultPlaceholder.classList.add("hidden");
        if (resultBody) resultBody.classList.remove("hidden");
    }

    // Helper: Reset prediction form and simulation output back to baseline
    function resetPredictionPlanner() {
        const locSelect = document.getElementById("pred-location");
        if (locSelect) locSelect.value = "Tamil Nadu & Coromandel Coast";

        const typeSelect = document.getElementById("pred-type");
        if (typeSelect) typeSelect.value = "Flash Flood";

        const defaults = {
            "pred-temp": { val: 28, label: "28°C" },
            "pred-humidity": { val: 55, label: "55%" },
            "pred-wind": { val: 22, label: "22 km/h" },
            "pred-soil": { val: 35, label: "35%" }
        };

        for (const id in defaults) {
            const slider = document.getElementById(id);
            const span = document.getElementById(`val-${id}`);
            if (slider) slider.value = defaults[id].val;
            if (span) span.innerText = defaults[id].label;
        }

        // Clear active class from preset pills
        document.querySelectorAll(".preset-risk-pill").forEach(p => p.classList.remove("active"));

        // Reset result pane
        const resultPlaceholder = document.getElementById("pred-result-placeholder");
        const resultBody = document.getElementById("pred-result-body");
        if (resultPlaceholder) {
            resultPlaceholder.innerHTML = `<i class="fa-solid fa-brain" style="color:var(--color-cyan); font-size:38px; margin-bottom:12px;"></i><p>Simulation parameters reset to baseline. Adjust parameters or select a threat preset, then click Calculate.</p>`;
            resultPlaceholder.classList.remove("hidden");
        }
        if (resultBody) {
            resultBody.classList.add("hidden");
        }

        // Reset gauge
        const circle = document.getElementById("gauge-fill-circle");
        if (circle) circle.style.strokeDashoffset = 314;
        const riskEl = document.getElementById("res-risk-val");
        if (riskEl) riskEl.innerText = "0%";

        lastCalculatedPrediction = null;

        // Button feedback
        const resetBtn = document.getElementById("btn-pred-reset");
        if (resetBtn) {
            const origHtml = resetBtn.innerHTML;
            resetBtn.innerHTML = `<i class="fa-solid fa-check" style="color:#10b981;"></i> Reset Complete`;
            setTimeout(() => { resetBtn.innerHTML = origHtml; }, 1400);
        }
    }

    // 3. AI Prediction Form
    const predictionForm = document.getElementById("prediction-form");
    if (predictionForm) {
        predictionForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const location = document.getElementById("pred-location") ? document.getElementById("pred-location").value : "Tamil Nadu & Coromandel Coast";
            const type = document.getElementById("pred-type") ? document.getElementById("pred-type").value : "Flash Flood";
            const temp = parseFloat(document.getElementById("pred-temp")?.value || 28);
            const humidity = parseFloat(document.getElementById("pred-humidity")?.value || 55);
            const wind = parseFloat(document.getElementById("pred-wind")?.value || 22);
            const soil = parseFloat(document.getElementById("pred-soil")?.value || 35);

            const resultPlaceholder = document.getElementById("pred-result-placeholder");
            const resultBody = document.getElementById("pred-result-body");

            if (resultPlaceholder) {
                resultPlaceholder.innerHTML = `<i class="fa-solid fa-spinner fa-spin neural-icon" style="color:var(--color-cyan);"></i><p>Scanning 10-Year historical Kaggle database matrices...</p>`;
                resultPlaceholder.classList.remove("hidden");
            }
            if (resultBody) {
                resultBody.classList.add("hidden");
            }

            if (isOfflineMode) {
                setTimeout(() => {
                    const localData = calculateLocalPrediction(location, type, temp, humidity, wind, soil);
                    renderPredictionResult(localData);
                }, 600);
                return;
            }

            try {
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 3500);

                const res = await fetch(`${API_BASE}/predict`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    signal: controller.signal,
                    body: JSON.stringify({
                        location: location,
                        disasterType: type,
                        type: type,
                        temp: String(temp),
                        humidity: String(humidity),
                        windSpeed: String(wind),
                        soilMoisture: String(soil),
                        historyRate: "5"
                    })
                });
                clearTimeout(timeoutId);

                if (res.ok) {
                    const data = await res.json();
                    renderPredictionResult(data);
                } else {
                    console.warn("Backend /predict non-200 response, engaging client-side AI mathematical engine");
                    const localData = calculateLocalPrediction(location, type, temp, humidity, wind, soil);
                    renderPredictionResult(localData);
                }
            } catch (err) {
                console.warn("Prediction API fetch unavailable, seamlessly activating local Kaggle prediction model:", err);
                setTimeout(() => {
                    const localData = calculateLocalPrediction(location, type, temp, humidity, wind, soil);
                    renderPredictionResult(localData);
                }, 400);
            }
        });
    }

    // Reset Buttons Listeners
    const btnPredReset = document.getElementById("btn-pred-reset");
    if (btnPredReset) {
        btnPredReset.addEventListener("click", resetPredictionPlanner);
    }
    const btnResetView = document.getElementById("btn-reset-prediction-view");
    if (btnResetView) {
        btnResetView.addEventListener("click", resetPredictionPlanner);
    }

    // Rapid Threat Presets Configurations
    const threatPresetsConfig = {
        "chennai-flood": {
            location: "Tamil Nadu & Coromandel Coast",
            type: "Flash Flood",
            temp: 26, humidity: 92, wind: 65, soil: 95
        },
        "coromandel-cyclone": {
            location: "Tamil Nadu & Coromandel Coast",
            type: "Hurricane",
            temp: 28, humidity: 95, wind: 135, soil: 85
        },
        "wayanad-landslide": {
            location: "Kerala & Western Ghats",
            type: "Landslide",
            temp: 22, humidity: 96, wind: 35, soil: 98
        },
        "nilgiris-wildfire": {
            location: "Tamil Nadu & Coromandel Coast",
            type: "Wildfire",
            temp: 39, humidity: 16, wind: 42, soil: 8
        },
        "benign-normal": {
            location: "Tamil Nadu & Coromandel Coast",
            type: "Flash Flood",
            temp: 25, humidity: 42, wind: 12, soil: 28
        }
    };

    document.querySelectorAll(".preset-risk-pill").forEach(btn => {
        btn.addEventListener("click", () => {
            const presetKey = btn.getAttribute("data-preset");
            const config = threatPresetsConfig[presetKey];
            if (!config) return;

            document.querySelectorAll(".preset-risk-pill").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");

            const locSelect = document.getElementById("pred-location");
            if (locSelect) locSelect.value = config.location;

            const typeSelect = document.getElementById("pred-type");
            if (typeSelect) typeSelect.value = config.type;

            const sliderMap = [
                { id: "pred-temp", val: config.temp, suffix: "°C" },
                { id: "pred-humidity", val: config.humidity, suffix: "%" },
                { id: "pred-wind", val: config.wind, suffix: " km/h" },
                { id: "pred-soil", val: config.soil, suffix: "%" }
            ];

            sliderMap.forEach(s => {
                const slider = document.getElementById(s.id);
                const span = document.getElementById(`val-${s.id}`);
                if (slider) slider.value = s.val;
                if (span) span.innerText = s.val + s.suffix;
            });

            // Automatically evaluate scenario
            if (predictionForm) {
                predictionForm.dispatchEvent(new Event("submit"));
            }
        });
    });

    // Wire Dispatch 30h Life-Safety Warning
    const btnToEarlyWarning = document.getElementById("btn-pred-to-earlywarning");
    if (btnToEarlyWarning) {
        btnToEarlyWarning.addEventListener("click", () => {
            const ewTabBtn = document.getElementById("tab-btn-earlywarning");
            if (ewTabBtn) ewTabBtn.click();
            
            const targetRegion = lastCalculatedPrediction ? (lastCalculatedPrediction.location || "") : "";
            let cardId = "card-alert-chennai";
            if (targetRegion.toLowerCase().includes("kerala") || targetRegion.toLowerCase().includes("wayanad")) {
                cardId = "card-alert-wayanad";
            } else if (targetRegion.toLowerCase().includes("odisha") || targetRegion.toLowerCase().includes("bengal") || targetRegion.toLowerCase().includes("puri")) {
                cardId = "card-alert-puri";
            }
            const cardEl = document.getElementById(cardId);
            if (cardEl) {
                cardEl.scrollIntoView({ behavior: "smooth", block: "center" });
                cardEl.style.boxShadow = "0 0 25px rgba(239, 68, 68, 0.6)";
                setTimeout(() => { cardEl.style.boxShadow = ""; }, 3000);
            }
        });
    }

    // Wire Copy Assessment Brief
    const btnCopyReport = document.getElementById("btn-pred-copy-report");
    if (btnCopyReport) {
        btnCopyReport.addEventListener("click", () => {
            if (!lastCalculatedPrediction) return;
            const p = lastCalculatedPrediction;
            const now = new Date();
            const pad = n => String(n).padStart(2, '0');
            const dateStr = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())} IST`;

            const report = `=====================================================
AEGIS TACTICAL DISASTER PREDICTION BRIEFING
Generated: ${dateStr}
=====================================================
Target Assessment Area : ${p.location}
Threat Classification  : ${p.disasterType || p.type}
Risk Severity Level    : ${(p.severity || "HIGH").toUpperCase()} (${p.riskScore}%)
Model Confidence       : ${p.confidence}%
10-Year Kaggle Matches : ${p.matchedHistoryCount || 0} occurrences
Recurrence Frequency   : ${(p.historicalFreqCoeff || 0).toFixed(2)} events/year

ACTIONABLE MITIGATION PROTOCOLS:
${(p.recommendations || []).map((r, i) => `  ${i+1}. ${r}`).join('\n')}

ESTIMATED THREAT EXPOSURE:
- Est. Vulnerable Population: ~48,500 citizens in drainage margin
- Buffer Inundation Footprint: ~12.4 km² Zone
- Shelter Readiness: Designated RCC Emergency Hubs Activated
=====================================================`;

            navigator.clipboard.writeText(report).then(() => {
                const orig = btnCopyReport.innerHTML;
                btnCopyReport.innerHTML = `<i class="fa-solid fa-check" style="color:#10b981;"></i> Brief Copied!`;
                setTimeout(() => { btnCopyReport.innerHTML = orig; }, 2000);
            }).catch(() => {
                alert("Brief copied to system buffer.");
            });
        });
    }

    // Environmental prediction slider value sync
    const sliders = ["pred-temp", "pred-humidity", "pred-wind", "pred-soil"];
    const suffixes = ["°C", "%", " km/h", "%"];
    sliders.forEach((id, idx) => {
        const slider = document.getElementById(id);
        const valSpan = document.getElementById(`val-${id}`);
        slider.addEventListener("input", () => {
            valSpan.innerText = slider.value + suffixes[idx];
        });
    });

    // Alert dialog button listeners
    document.getElementById("modal-ack-btn").addEventListener("click", acknowledgeCurrentCrisis);
    document.getElementById("banner-ack-btn").addEventListener("click", acknowledgeCurrentCrisis);
}

// ------------------ DISASTER SELECT DROPDOWN FOR RESOURCES ------------------
function updateResourceHazardSelect(hazards) {
    const select = document.getElementById("allocate-hazard-id");
    const activeHazards = hazards.filter(h => h.status !== "Resolved");

    const currVal = select.value;
    select.innerHTML = `<option value="">Select Disaster Event...</option>`;

    activeHazards.forEach(h => {
        const opt = document.createElement("option");
        opt.value = h.id;
        opt.innerText = `Disaster ID #${h.id} - ${h.type} (${h.location})`;
        select.appendChild(opt);
    });

    if (currVal && activeHazards.some(h => h.id == currVal)) {
        select.value = currVal;
    }
}

// ------------------ ANALYTICS CHARTING (CHART.JS - SQUARE TILES & BARS) ------------------
function initCharts() {
    Chart.defaults.color = "#94A3B8";
    Chart.defaults.borderColor = "rgba(255, 255, 255, 0.05)";
    Chart.defaults.font.family = "'Outfit', sans-serif";

    // 1. Disaster Trend Chart (Square Bar Columns 2016-2026)
    const canvasTrend = document.getElementById("chart-trend");
    if (canvasTrend) {
        const ctxTrend = canvasTrend.getContext("2d");
        trendChart = new Chart(ctxTrend, {
            type: 'bar',
            data: {
                labels: ['2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025', '2026'],
                datasets: [{
                    label: 'Logged Disasters',
                    data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                    backgroundColor: 'rgba(56, 189, 248, 0.55)',
                    borderColor: '#38BDF8',
                    borderWidth: 1.5,
                    borderRadius: 0 // Crisp square bars!
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        cornerRadius: 2,
                        padding: 10
                    }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { size: 10 } } },
                    y: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 10 } } }
                }
            }
        });
    }

    // 2. Incident Classification Distribution Chart (Square Bar Default / Donut Toggle)
    initTypeChartMode(currentTypeChartMode, [0, 0, 0, 0, 0]);

    // 3. Disaster Distribution by Regional Sector Chart (Square Horizontal Bars)
    const canvasRegions = document.getElementById("chart-regions");
    if (canvasRegions) {
        const ctxRegions = canvasRegions.getContext("2d");
        regionChart = new Chart(ctxRegions, {
            type: 'bar',
            data: {
                labels: [
                    'Tamil Nadu', 'Kerala', 'Odisha', 'Assam',
                    'Uttarakhand', 'Himachal', 'Gujarat', 'Central Plains'
                ],
                datasets: [{
                    label: 'Logged Disasters',
                    data: [0, 0, 0, 0, 0, 0, 0, 0],
                    backgroundColor: 'rgba(245, 158, 11, 0.55)',
                    borderColor: '#F59E0B',
                    borderWidth: 1.5,
                    borderRadius: 0 // Crisp square bars!
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        cornerRadius: 2,
                        callbacks: {
                            title: function(items) {
                                const fullNames = [
                                    'Tamil Nadu & Coromandel Coast', 'Kerala & Western Ghats', 'Odisha & Bengal Coast',
                                    'Assam & North-East', 'Uttarakhand & Himalayas', 'Himachal & J&K Ranges',
                                    'Gujarat & Western Coast', 'Indo-Gangetic & Central Plains'
                                ];
                                const idx = items[0].dataIndex;
                                return fullNames[idx] || items[0].label;
                            }
                        }
                    }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { size: 9 }, maxRotation: 45, minRotation: 45 } },
                    y: { beginAtZero: true, ticks: { stepSize: 2, font: { size: 10 } } }
                }
            }
        });
    }

    // 4. Hazard Severity Classification Matrix Chart (Square Bars)
    const canvasSeverity = document.getElementById("chart-severity");
    if (canvasSeverity) {
        const ctxSeverity = canvasSeverity.getContext("2d");
        severityChart = new Chart(ctxSeverity, {
            type: 'bar',
            data: {
                labels: ['Critical', 'High', 'Medium', 'Low'],
                datasets: [{
                    label: 'Severity Count',
                    data: [0, 0, 0, 0],
                    backgroundColor: [
                        'rgba(239, 68, 68, 0.65)',
                        'rgba(245, 158, 11, 0.65)',
                        'rgba(56, 189, 248, 0.65)',
                        'rgba(16, 185, 129, 0.65)'
                    ],
                    borderColor: [
                        '#EF4444',
                        '#F59E0B',
                        '#38BDF8',
                        '#10B981'
                    ],
                    borderWidth: 1.5,
                    borderRadius: 0 // Crisp square bars!
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { cornerRadius: 2 }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { size: 10 } } },
                    y: { beginAtZero: true, ticks: { stepSize: 2, font: { size: 10 } } }
                }
            }
        });
    }

    // Wire Chart 2 Type Toggle (Square Bar vs Donut)
    const btnTypeBar = document.getElementById("btn-chart-type-bar");
    const btnTypeDonut = document.getElementById("btn-chart-type-donut");
    if (btnTypeBar && btnTypeDonut) {
        btnTypeBar.addEventListener("click", () => {
            if (currentTypeChartMode === "bar") return;
            currentTypeChartMode = "bar";
            btnTypeBar.classList.add("active");
            btnTypeDonut.classList.remove("active");
            if (cachedHazardsForCharts && cachedHazardsForCharts.length > 0) {
                updateChartsData(cachedHazardsForCharts);
            }
        });
        btnTypeDonut.addEventListener("click", () => {
            if (currentTypeChartMode === "donut") return;
            currentTypeChartMode = "donut";
            btnTypeDonut.classList.add("active");
            btnTypeBar.classList.remove("active");
            if (cachedHazardsForCharts && cachedHazardsForCharts.length > 0) {
                updateChartsData(cachedHazardsForCharts);
            }
        });
    }

    // Wire Layout Mode Buttons (2x2 Square Grid vs 3-Column Square)
    const layoutContainer = document.getElementById("analytics-layout-container");
    const btn2x2 = document.getElementById("layout-btn-2x2");
    const btn3col = document.getElementById("layout-btn-3col");
    if (btn2x2 && btn3col && layoutContainer) {
        btn2x2.addEventListener("click", () => {
            layoutContainer.className = "analytics-layout square-grid-2x2";
            btn2x2.classList.add("active");
            btn3col.classList.remove("active");
            resizeAllCharts();
        });
        btn3col.addEventListener("click", () => {
            layoutContainer.className = "analytics-layout square-grid-3col";
            btn3col.classList.add("active");
            btn2x2.classList.remove("active");
            resizeAllCharts();
        });
    }
}

function resizeAllCharts() {
    setTimeout(() => {
        if (trendChart) trendChart.resize();
        if (typeChart) typeChart.resize();
        if (regionChart) regionChart.resize();
        if (severityChart) severityChart.resize();
    }, 100);
}

function initTypeChartMode(mode, dataCounts) {
    const canvas = document.getElementById("chart-types");
    if (!canvas) return;
    if (typeChart) {
        typeChart.destroy();
        typeChart = null;
    }
    const ctxTypes = canvas.getContext("2d");

    if (mode === "bar") {
        // Square Bar Chart Matrix
        typeChart = new Chart(ctxTypes, {
            type: 'bar',
            data: {
                labels: ['Wildfire', 'Flash Flood', 'Landslide', 'Hurricane', 'Collapse'],
                datasets: [{
                    label: 'Logged Incidents',
                    data: dataCounts || [0, 0, 0, 0, 0],
                    backgroundColor: [
                        'rgba(239, 68, 68, 0.65)',
                        'rgba(56, 189, 248, 0.65)',
                        'rgba(245, 158, 11, 0.65)',
                        'rgba(168, 85, 247, 0.65)',
                        'rgba(251, 191, 36, 0.65)'
                    ],
                    borderColor: [
                        '#EF4444',
                        '#38BDF8',
                        '#F59E0B',
                        '#A855F7',
                        '#FBBF24'
                    ],
                    borderWidth: 1.5,
                    borderRadius: 0 // Crisp square bars!
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { cornerRadius: 2 }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { size: 10 } } },
                    y: { beginAtZero: true, ticks: { stepSize: 2, font: { size: 10 } } }
                }
            }
        });
    } else {
        // Donut Chart View
        typeChart = new Chart(ctxTypes, {
            type: 'doughnut',
            data: {
                labels: ['Wildfire', 'Flash Flood', 'Landslide', 'Hurricane', 'Structural Collapse'],
                datasets: [{
                    data: dataCounts || [0, 0, 0, 0, 0],
                    backgroundColor: [
                        '#EF4444',
                        '#38BDF8',
                        '#F59E0B',
                        '#A855F7',
                        '#FBBF24'
                    ],
                    borderWidth: 1.5,
                    borderColor: '#0B0F19',
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: { boxWidth: 10, padding: 12, font: { size: 10 } }
                    }
                },
                cutout: '62%'
            }
        });
    }
}

function updateChartsData(hazards) {
    if (!Array.isArray(hazards) || hazards.length === 0) return;
    cachedHazardsForCharts = hazards;

    // 1. Update Type Distribution Chart
    const typesCount = { "Wildfire": 0, "Flash Flood": 0, "Landslide": 0, "Hurricane": 0, "Structural Collapse": 0 };
    hazards.forEach(h => {
        let typeKey = h.type;
        if (typeKey.includes("Collapse")) typeKey = "Structural Collapse";

        if (typesCount.hasOwnProperty(typeKey)) {
            typesCount[typeKey]++;
        } else {
            typesCount[typeKey] = 1;
        }
    });

    const countsArray = [
        typesCount["Wildfire"] || 0,
        typesCount["Flash Flood"] || 0,
        typesCount["Landslide"] || 0,
        typesCount["Hurricane"] || 0,
        typesCount["Structural Collapse"] || 0
    ];

    if (!typeChart) {
        initTypeChartMode(currentTypeChartMode, countsArray);
    } else {
        typeChart.data.datasets[0].data = countsArray;
        typeChart.update();
    }

    // 2. Update 10-Year Annual Trend Chart (Counts per Year 2016-2026)
    if (trendChart) {
        const yearsCount = {
            "2016": 0, "2017": 0, "2018": 0, "2019": 0, "2020": 0,
            "2021": 0, "2022": 0, "2023": 0, "2024": 0, "2025": 0, "2026": 0
        };

        hazards.forEach(h => {
            const yearStr = String(h.year);
            if (yearsCount.hasOwnProperty(yearStr)) {
                yearsCount[yearStr]++;
            }
        });

        const trendData = [
            yearsCount["2016"], yearsCount["2017"], yearsCount["2018"], yearsCount["2019"], yearsCount["2020"],
            yearsCount["2021"], yearsCount["2022"], yearsCount["2023"], yearsCount["2024"], yearsCount["2025"],
            yearsCount["2026"]
        ];

        trendChart.data.datasets[0].data = trendData;
        trendChart.update();
    }

    // 3. Update Regional Distribution Chart
    if (regionChart) {
        const regionsCount = {
            "Tamil Nadu & Coromandel Coast": 0,
            "Kerala & Western Ghats": 0,
            "Odisha & Bengal Coast": 0,
            "Assam & North-East": 0,
            "Uttarakhand & Himalayas": 0,
            "Himachal & J&K Ranges": 0,
            "Gujarat & Western Coast": 0,
            "Indo-Gangetic & Central Plains": 0
        };

        hazards.forEach(h => {
            if (regionsCount.hasOwnProperty(h.location)) {
                regionsCount[h.location]++;
            }
        });

        const regionsData = [
            regionsCount["Tamil Nadu & Coromandel Coast"] || 0,
            regionsCount["Kerala & Western Ghats"] || 0,
            regionsCount["Odisha & Bengal Coast"] || 0,
            regionsCount["Assam & North-East"] || 0,
            regionsCount["Uttarakhand & Himalayas"] || 0,
            regionsCount["Himachal & J&K Ranges"] || 0,
            regionsCount["Gujarat & Western Coast"] || 0,
            regionsCount["Indo-Gangetic & Central Plains"] || 0
        ];

        regionChart.data.datasets[0].data = regionsData;
        regionChart.update();
    }

    // 4. Update Severity Distribution Matrix Chart
    if (severityChart) {
        const severityCount = { "Critical": 0, "High": 0, "Medium": 0, "Low": 0 };
        hazards.forEach(h => {
            const sev = h.severity || "Medium";
            if (severityCount.hasOwnProperty(sev)) {
                severityCount[sev]++;
            } else {
                severityCount["Medium"]++;
            }
        });

        severityChart.data.datasets[0].data = [
            severityCount["Critical"] || 0,
            severityCount["High"] || 0,
            severityCount["Medium"] || 0,
            severityCount["Low"] || 0
        ];
        severityChart.update();
    }
}

// ==========================================================================
// ADIS INTELLIGENCE ENGINE IMPLEMENTATION
// ==========================================================================

function initAdisComponents() {
    setupWeatherLayers();
    setupSatelliteCvScanner();
    setupNlpSocialIntake();
    setupEsp32HardwareConsole();
    initHydrologicalFloodEngine();
    initLiveWeatherFeed();
}

function drawOptimizedRoute(targetLat, targetLng, locationName, id) {
    if (!map) return;
    if (activeRoutePolyline) {
        map.removeLayer(activeRoutePolyline);
        activeRoutePolyline = null;
    }

    const start = [28.6139, 77.2090]; // National Disaster Management Command (New Delhi)
    const end = [targetLat, targetLng];

    const latDiff = end[0] - start[0];
    const lngDiff = end[1] - start[1];

    // Slightly bend the path to make it look "optimized" around terrain
    const mid1 = [
        start[0] + latDiff * 0.33 + (Math.sin(targetLat) * 0.8),
        start[1] + lngDiff * 0.25 - (Math.cos(targetLng) * 0.8)
    ];
    const mid2 = [
        start[0] + latDiff * 0.66 - (Math.sin(targetLng) * 0.8),
        start[1] + lngDiff * 0.75 + (Math.cos(targetLat) * 0.8)
    ];

    const pathPoints = [start, mid1, mid2, end];
    activeRoutePolyline = L.polyline(pathPoints, {
        color: '#38BDF8',
        weight: 4,
        opacity: 0.8,
        className: 'route-path-pulse'
    }).addTo(map);

    // Compute metrics
    const distanceDeg = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff);
    const distanceKm = Math.round(distanceDeg * 105 * 10) / 10;
    const speedKmh = 85;
    const totalMinutes = Math.round((distanceKm / speedKmh) * 60);
    const hours = Math.floor(totalMinutes / 60);
    const mins = totalMinutes % 60;

    // Show details
    const ph = document.getElementById("route-placeholder");
    if (ph) ph.classList.add("hidden");

    const content = document.getElementById("route-info-content");
    if (content) content.classList.remove("hidden");

    document.getElementById("route-id-val").innerText = `RT-${1000 + parseInt(id)}`;
    document.getElementById("route-distance-val").innerText = `${distanceKm} km`;
    document.getElementById("route-eta-val").innerText = `${hours}h ${mins}m`;

    const avoidedList = [
        "Slight deviation past high elevation ridge.",
        "Rerouted to bypass dense urban storm zone.",
        "Calculated detour around bridge crossing hazard.",
        "Safest passage identified along state highway grid."
    ];
    const avoidedStr = avoidedList[id % avoidedList.length];
    document.getElementById("route-avoided-val").innerText = avoidedStr;

    const statusVal = document.getElementById("route-status-val");
    statusVal.innerText = "OPTIMIZED SAFE PATH ACTIVE";
    statusVal.style.background = "rgba(16, 185, 129, 0.08)";
    statusVal.style.borderColor = "var(--color-green)";
    statusVal.style.color = "var(--color-green)";
}

function setupWeatherLayers() {
    const rainBtn = document.getElementById("weather-rain-btn");
    const heatBtn = document.getElementById("weather-heat-btn");
    const windBtn = document.getElementById("weather-wind-btn");

    if (!rainBtn || !heatBtn || !windBtn) return;

    // Initialize mock layer objects covering entire India including Tamil Nadu
    const rainGroup = L.layerGroup([
        L.circle([13.0827, 80.2707], { radius: 180000, color: 'transparent', fillColor: '#38BDF8', fillOpacity: 0.25 }), // Tamil Nadu Northeast Monsoon Rain
        L.circle([26.1445, 91.7362], { radius: 200000, color: 'transparent', fillColor: '#38BDF8', fillOpacity: 0.25 }), // Assam Monsoon Rain
        L.circle([9.9312, 76.2673], { radius: 160000, color: 'transparent', fillColor: '#38BDF8', fillOpacity: 0.25 })   // Kerala Southwest Monsoon
    ]);

    const heatGroup = L.layerGroup([
        L.circle([26.9124, 75.7873], { radius: 280000, color: 'transparent', fillColor: '#EF4444', fillOpacity: 0.15 }), // Rajasthan Thar Heat Wave
        L.circle([16.5062, 80.6480], { radius: 250000, color: 'transparent', fillColor: '#EF4444', fillOpacity: 0.15 }), // Andhra & Rayalaseema Heat Wave
        L.circle([10.7905, 78.7047], { radius: 200000, color: 'transparent', fillColor: '#EF4444', fillOpacity: 0.15 })  // Central Tamil Nadu Summer Heat
    ]);

    const windGroup = L.layerGroup([
        L.polyline([[10.5, 84.0], [12.0, 82.5], [13.2, 80.8], [14.0, 80.2]], { color: '#FFF', weight: 2, opacity: 0.35, dashArray: '8, 8' }), // Bay of Bengal to Tamil Nadu Cyclone Track
        L.polyline([[15.0, 88.0], [18.0, 86.5], [20.5, 86.0], [22.0, 87.5]], { color: '#FFF', weight: 2, opacity: 0.35, dashArray: '8, 8' }), // Odisha / Bengal Super Cyclone Path
        L.polyline([[14.0, 69.0], [18.0, 70.5], [22.0, 69.0]], { color: '#FFF', weight: 2, opacity: 0.35, dashArray: '8, 8' })  // Arabian Sea Cyclone Vector
    ]);

    // Active by default
    if (map) {
        rainGroup.addTo(map);
        weatherLayers.rain = rainGroup;
    }

    rainBtn.addEventListener("click", () => {
        if (rainBtn.classList.contains("active")) {
            rainBtn.classList.remove("active");
            if (map) map.removeLayer(rainGroup);
            weatherLayers.rain = null;
        } else {
            rainBtn.classList.add("active");
            if (map) rainGroup.addTo(map);
            weatherLayers.rain = rainGroup;
        }
    });

    heatBtn.addEventListener("click", () => {
        if (heatBtn.classList.contains("active")) {
            heatBtn.classList.remove("active");
            if (map) map.removeLayer(heatGroup);
            weatherLayers.heat = null;
        } else {
            heatBtn.classList.add("active");
            if (map) heatGroup.addTo(map);
            weatherLayers.heat = heatGroup;
        }
    });

    windBtn.addEventListener("click", () => {
        if (windBtn.classList.contains("active")) {
            windBtn.classList.remove("active");
            if (map) map.removeLayer(windGroup);
            weatherLayers.wind = null;
        } else {
            windBtn.classList.add("active");
            if (map) windGroup.addTo(map);
            weatherLayers.wind = windGroup;
        }
    });
}

const SATELLITE_SECTORS = [
    {
        name: "Chennai Delta (Flood)",
        region: "Tamil Nadu & Coromandel Coast",
        city: "Chennai (Velachery, Pallikaranai & Tambaram Low-Lying Wards)",
        coords: "12.9792° N, 80.2185° E",
        mission: "SENTINEL-2A · ORBIT 786KM",
        res: "RES: 10M/PX",
        hazardType: "Flash Flood & Severe Inundation",
        confidence: "96.4%",
        area: "4.8 km² Inundated",
        depth: "1.2m - 1.8m Inflow",
        lat: 12.9792,
        lng: 80.2185,
        risk: 92,
        population: 420000,
        box: { xRatio: 0.38, yRatio: 0.30, wRatio: 0.32, hRatio: 0.38 },
        terrain: "coastal_delta"
    },
    {
        name: "Wayanad Hills (Landslide)",
        region: "Kerala & Western Ghats",
        city: "Wayanad (Meppadi & Chooralmala Hill Settlement)",
        coords: "11.5284° N, 76.1664° E",
        mission: "RADARSAT-2 SAR · ORBIT 798KM",
        res: "RES: 8M/PX",
        hazardType: "Slope Creep & Debris Flow",
        confidence: "97.1%",
        area: "2.3 km² Liquefied",
        depth: "Pore Pressure > 41 kPa",
        lat: 11.5284,
        lng: 76.1664,
        risk: 95,
        population: 65000,
        box: { xRatio: 0.34, yRatio: 0.28, wRatio: 0.34, hRatio: 0.38 },
        terrain: "mountain_slope"
    },
    {
        name: "Nilgiris Ghats (Landslide)",
        region: "Tamil Nadu & Western Ghats",
        city: "Nilgiris (Ooty, Coonoor & Kotagiri Escarpments)",
        coords: "11.4102° N, 76.6950° E",
        mission: "CARTOSAT-3 · ORBIT 505KM",
        res: "RES: 0.28M/PX",
        hazardType: "Landslide Scar & Mudflow Corridor",
        confidence: "91.8%",
        area: "1.7 km² Escarpment",
        depth: "Creep: 1.8mm/hr",
        lat: 11.4102,
        lng: 76.6950,
        risk: 84,
        population: 140000,
        box: { xRatio: 0.36, yRatio: 0.30, wRatio: 0.32, hRatio: 0.36 },
        terrain: "mountain_ridge"
    },
    {
        name: "Madurai Basin (Flood)",
        region: "Tamil Nadu & South Basin",
        city: "Madurai (Goripalayam, Sellur & Vaigai Riverside)",
        coords: "9.9252° N, 78.1198° E",
        mission: "RISAT-1A SAR · ORBIT 536KM",
        res: "RES: 3M/PX",
        hazardType: "Vaigai Riverine Flash Inundation",
        confidence: "94.2%",
        area: "3.6 km² Overflow",
        depth: "Discharge: 16,800 cusecs",
        lat: 9.9252,
        lng: 78.1198,
        risk: 87,
        population: 450000,
        box: { xRatio: 0.38, yRatio: 0.34, wRatio: 0.32, hRatio: 0.34 },
        terrain: "river_basin"
    }
];

let activeSatelliteSectorIdx = 0;
let activeSpectrumMode = "rgb";
let cvIsThreatDetected = false;

function setupSatelliteCvScanner() {
    const canvas = document.getElementById("satellite-cv-canvas");
    const startBtn = document.getElementById("cv-start-scan-btn");
    const logBtn = document.getElementById("cv-log-hazard-btn");
    const tip = document.getElementById("cv-scan-tip");
    const alertBanner = document.getElementById("cv-scan-alert");
    const alertMsg = document.getElementById("cv-scan-alert-msg");
    const hudCoords = document.getElementById("cv-hud-coords");
    const satMission = document.getElementById("cv-sat-mission");
    const satRes = document.getElementById("cv-sat-res");

    if (!canvas || !startBtn || !logBtn) return;

    const ctx = canvas.getContext("2d");
    let isScanning = false;
    let scanProgress = 0;
    let animId = null;

    function resizeCanvas() {
        const rect = canvas.getBoundingClientRect();
        canvas.width = rect.width || canvas.offsetWidth || 800;
        canvas.height = rect.height || canvas.offsetHeight || 420;
        renderScene();
    }
    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // High-Fidelity Procedural Satellite Scene Renderer
    function renderScene(progress = 0) {
        const w = canvas.width;
        const h = canvas.height;
        const sector = SATELLITE_SECTORS[activeSatelliteSectorIdx];

        ctx.clearRect(0, 0, w, h);

        // 1. Base Terrain Shading by Sector & Spectrum Band
        if (sector.terrain === "coastal_delta") {
            // Chennai Delta Basin (Coast on East, River delta on West)
            let landGrad, seaGrad, floodColor, riverColor;
            if (activeSpectrumMode === "nir") {
                // False Color Infrared: Vegetation = Rust/Orange, Water = Vibrant Electric Cyan
                landGrad = ctx.createLinearGradient(0, 0, w * 0.7, h);
                landGrad.addColorStop(0, "#9a3412");
                landGrad.addColorStop(0.6, "#c2410c");
                landGrad.addColorStop(1, "#7c2d12");
                seaGrad = "#0891b2";
                floodColor = "rgba(6, 182, 212, 0.75)";
                riverColor = "#22d3ee";
            } else if (activeSpectrumMode === "sar") {
                // Synthetic Aperture Radar: Grayscale backscatter, water is deep black absorption
                landGrad = ctx.createLinearGradient(0, 0, w, h);
                landGrad.addColorStop(0, "#334155");
                landGrad.addColorStop(0.5, "#475569");
                landGrad.addColorStop(1, "#1e293b");
                seaGrad = "#020617";
                floodColor = "rgba(15, 23, 42, 0.85)";
                riverColor = "#0f172a";
            } else if (activeSpectrumMode === "thermal") {
                // Thermal IR Heatmap
                landGrad = ctx.createLinearGradient(0, 0, w, h);
                landGrad.addColorStop(0, "#4c1d95");
                landGrad.addColorStop(0.4, "#9333ea");
                landGrad.addColorStop(0.8, "#c026d3");
                landGrad.addColorStop(1, "#dc2626");
                seaGrad = "#1e1b4b";
                floodColor = "rgba(239, 68, 68, 0.7)";
                riverColor = "#f59e0b";
            } else {
                // Natural RGB Optical: Deep lush vegetation, coastal sand, blue sea
                landGrad = ctx.createLinearGradient(0, 0, w * 0.75, h);
                landGrad.addColorStop(0, "#14532d");
                landGrad.addColorStop(0.4, "#166534");
                landGrad.addColorStop(0.75, "#1e293b"); // Urban matrix
                landGrad.addColorStop(1, "#a16207"); // Coastal beach sand
                seaGrad = "#0c4a6e";
                floodColor = "rgba(14, 165, 233, 0.65)";
                riverColor = "#38bdf8";
            }

            // Draw Land
            ctx.fillStyle = landGrad;
            ctx.fillRect(0, 0, w, h);

            // Draw Coastline & Bay of Bengal Sea (East Side)
            ctx.fillStyle = seaGrad;
            ctx.beginPath();
            ctx.moveTo(w * 0.78, 0);
            ctx.bezierCurveTo(w * 0.74, h * 0.35, w * 0.80, h * 0.65, w * 0.76, h);
            ctx.lineTo(w, h);
            ctx.lineTo(w, 0);
            ctx.closePath();
            ctx.fill();

            // Coastal Surf Shimmer
            ctx.strokeStyle = "rgba(255, 255, 255, 0.25)";
            ctx.lineWidth = 2;
            ctx.stroke();

            // Meandering Adyar & Cooum River Channels
            ctx.strokeStyle = riverColor;
            ctx.lineWidth = 5;
            ctx.lineCap = "round";
            ctx.beginPath();
            ctx.moveTo(0, h * 0.42);
            ctx.bezierCurveTo(w * 0.25, h * 0.40, w * 0.45, h * 0.52, w * 0.75, h * 0.46);
            ctx.stroke();

            // Buckingham Canal Corridor
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(w * 0.68, 0);
            ctx.bezierCurveTo(w * 0.66, h * 0.45, w * 0.70, h * 0.75, w * 0.69, h);
            ctx.stroke();

            // Urban Road Network Grid (Velachery / Tambaram matrix)
            ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
            ctx.lineWidth = 1;
            for (let rx = w * 0.15; rx < w * 0.65; rx += 35) {
                ctx.beginPath(); ctx.moveTo(rx, h * 0.15); ctx.lineTo(rx, h * 0.85); ctx.stroke();
            }
            for (let ry = h * 0.2; ry < h * 0.85; ry += 30) {
                ctx.beginPath(); ctx.moveTo(w * 0.15, ry); ctx.lineTo(w * 0.65, ry); ctx.stroke();
            }

            // Inundation Zone (Pallikaranai & Velachery Basin)
            ctx.fillStyle = floodColor;
            ctx.beginPath();
            ctx.ellipse(w * 0.52, h * 0.50, w * 0.18, h * 0.22, -0.15, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "rgba(56, 189, 248, 0.8)";
            ctx.lineWidth = 1.5;
            ctx.stroke();

        } else if (sector.terrain === "mountain_slope" || sector.terrain === "mountain_ridge") {
            // Western Ghats / Nilgiris (Topographical Ridges, Gorges & Slope Creep)
            let baseGrad, contourColor, creepColor;
            if (activeSpectrumMode === "nir") {
                baseGrad = ctx.createLinearGradient(0, 0, w, h);
                baseGrad.addColorStop(0, "#7c2d12");
                baseGrad.addColorStop(0.5, "#9a3412");
                baseGrad.addColorStop(1, "#451a03");
                contourColor = "rgba(251, 146, 60, 0.35)";
                creepColor = "rgba(239, 68, 68, 0.8)";
            } else if (activeSpectrumMode === "sar") {
                baseGrad = ctx.createLinearGradient(0, 0, w, h);
                baseGrad.addColorStop(0, "#1e293b");
                baseGrad.addColorStop(0.5, "#475569");
                baseGrad.addColorStop(1, "#0f172a");
                contourColor = "rgba(148, 163, 184, 0.25)";
                creepColor = "rgba(244, 63, 94, 0.85)";
            } else if (activeSpectrumMode === "thermal") {
                baseGrad = ctx.createLinearGradient(0, 0, w, h);
                baseGrad.addColorStop(0, "#312e81");
                baseGrad.addColorStop(0.5, "#7e22ce");
                baseGrad.addColorStop(1, "#b91c1c");
                contourColor = "rgba(245, 158, 11, 0.4)";
                creepColor = "rgba(254, 240, 138, 0.9)";
            } else {
                baseGrad = ctx.createLinearGradient(0, 0, w, h);
                baseGrad.addColorStop(0, "#064e3b");
                baseGrad.addColorStop(0.5, "#065f46");
                baseGrad.addColorStop(1, "#022c22");
                contourColor = "rgba(52, 211, 153, 0.3)";
                creepColor = "rgba(239, 68, 68, 0.85)";
            }

            ctx.fillStyle = baseGrad;
            ctx.fillRect(0, 0, w, h);

            // Mountain Ridge Contours
            ctx.strokeStyle = contourColor;
            ctx.lineWidth = 1.5;
            for (let r = 50; r < Math.min(w, h) * 0.9; r += 35) {
                ctx.beginPath();
                ctx.ellipse(w * 0.48, h * 0.46, r * 1.3, r * 0.7, 0.25, 0, Math.PI * 2);
                ctx.stroke();
            }

            // Mountain Valley Gorge River
            ctx.strokeStyle = activeSpectrumMode === "sar" ? "#020617" : "#38bdf8";
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.moveTo(w * 0.1, 0);
            ctx.bezierCurveTo(w * 0.35, h * 0.4, w * 0.55, h * 0.5, w * 0.9, h);
            ctx.stroke();

            // Landslide Scar & Debris Creep Polygon
            ctx.fillStyle = creepColor;
            ctx.beginPath();
            ctx.moveTo(w * 0.42, h * 0.28);
            ctx.lineTo(w * 0.58, h * 0.30);
            ctx.lineTo(w * 0.62, h * 0.58);
            ctx.lineTo(w * 0.40, h * 0.54);
            ctx.closePath();
            ctx.fill();

            // Shear strain vector lines
            ctx.strokeStyle = "#fef08a";
            ctx.lineWidth = 2;
            ctx.setLineDash([4, 4]);
            ctx.beginPath();
            ctx.moveTo(w * 0.45, h * 0.32); ctx.lineTo(w * 0.48, h * 0.52);
            ctx.moveTo(w * 0.52, h * 0.33); ctx.lineTo(w * 0.55, h * 0.53);
            ctx.stroke();
            ctx.setLineDash([]);

        } else {
            // Madurai River Basin (Alluvial Plain & Vaigai River Meander)
            let baseGrad = ctx.createLinearGradient(0, 0, w, h);
            baseGrad.addColorStop(0, "#1c1917");
            baseGrad.addColorStop(0.5, "#292524");
            baseGrad.addColorStop(1, "#0c0a09");
            ctx.fillStyle = baseGrad;
            ctx.fillRect(0, 0, w, h);

            // Vaigai River Ribbon
            ctx.strokeStyle = activeSpectrumMode === "nir" ? "#22d3ee" : "#0284c7";
            ctx.lineWidth = 8;
            ctx.beginPath();
            ctx.moveTo(0, h * 0.35);
            ctx.bezierCurveTo(w * 0.3, h * 0.55, w * 0.65, h * 0.25, w, h * 0.45);
            ctx.stroke();

            // Runoff Inundation Flood Overflow Area
            ctx.fillStyle = activeSpectrumMode === "nir" ? "rgba(6, 182, 212, 0.6)" : "rgba(56, 189, 248, 0.5)";
            ctx.beginPath();
            ctx.ellipse(w * 0.50, h * 0.48, w * 0.22, h * 0.16, 0.1, 0, Math.PI * 2);
            ctx.fill();
        }

        // 2. HUD Coordinate Grid Overlay
        ctx.strokeStyle = "rgba(56, 189, 248, 0.12)";
        ctx.lineWidth = 1;
        const gridStep = 45;
        for (let x = 0; x < w; x += gridStep) {
            ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
        }
        for (let y = 0; y < h; y += gridStep) {
            ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
        }

        // 3. Central HUD Targeting Reticle & Crosshairs
        const cx = w / 2;
        const cy = h / 2;
        ctx.strokeStyle = "rgba(56, 189, 248, 0.45)";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(cx, cy, 65, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = "rgba(56, 189, 248, 0.65)";
        ctx.beginPath();
        ctx.moveTo(cx - 80, cy); ctx.lineTo(cx - 20, cy);
        ctx.moveTo(cx + 20, cy); ctx.lineTo(cx + 80, cy);
        ctx.moveTo(cx, cy - 80); ctx.lineTo(cx, cy - 20);
        ctx.moveTo(cx, cy + 20); ctx.lineTo(cx, cy + 80);
        ctx.stroke();

        // Corner Framing Brackets
        const bracketLen = 22;
        ctx.strokeStyle = "#38bdf8";
        ctx.lineWidth = 2;
        // Top-left
        ctx.beginPath(); ctx.moveTo(25, 25 + bracketLen); ctx.lineTo(25, 25); ctx.lineTo(25 + bracketLen, 25); ctx.stroke();
        // Top-right
        ctx.beginPath(); ctx.moveTo(w - 25 - bracketLen, 25); ctx.lineTo(w - 25, 25); ctx.lineTo(w - 25, 25 + bracketLen); ctx.stroke();
        // Bottom-left
        ctx.beginPath(); ctx.moveTo(25, h - 25 - bracketLen); ctx.lineTo(25, h - 25); ctx.lineTo(25 + bracketLen, h - 25); ctx.stroke();
        // Bottom-right
        ctx.beginPath(); ctx.moveTo(w - 25 - bracketLen, h - 25); ctx.lineTo(w - 25, h - 25); ctx.lineTo(w - 25, h - 25 - bracketLen); ctx.stroke();

        // 4. Scanning Sequence Overlay (When Triggered)
        if (isScanning && progress > 0) {
            const sweepY = progress * h;

            // Dual Laser Beam
            ctx.strokeStyle = "#38bdf8";
            ctx.lineWidth = 2.5;
            ctx.shadowColor = "#38bdf8";
            ctx.shadowBlur = 12;
            ctx.beginPath();
            ctx.moveTo(0, sweepY);
            ctx.lineTo(w, sweepY);
            ctx.stroke();
            ctx.shadowBlur = 0;

            // Secondary Amber Scan Line
            ctx.strokeStyle = "#f59e0b";
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(0, sweepY - 4);
            ctx.lineTo(w, sweepY - 4);
            ctx.stroke();

            // Optical Scanning Trail
            const trailH = Math.min(80, sweepY);
            const scanGrad = ctx.createLinearGradient(0, sweepY - trailH, 0, sweepY);
            scanGrad.addColorStop(0, "rgba(56, 189, 248, 0)");
            scanGrad.addColorStop(1, "rgba(56, 189, 248, 0.28)");
            ctx.fillStyle = scanGrad;
            ctx.fillRect(0, sweepY - trailH, w, trailH);

            // ResNet-50 Feature Map Tensor Matrix
            ctx.fillStyle = "rgba(56, 189, 248, 0.85)";
            ctx.font = "10px 'Orbitron', monospace";
            ctx.fillText(`RESNET-50 CONV-LAYER 4 FEATURE ENCODING... [${Math.round(progress * 100)}%]`, 35, sweepY > 50 ? sweepY - 15 : sweepY + 25);
            ctx.fillText(`SPECTRUM BAND: [${activeSpectrumMode.toUpperCase()}] · FILTER: KERNEL 7x7`, 35, sweepY > 50 ? sweepY - 30 : sweepY + 40);

            // Random tensor sparkles
            for (let i = 0; i < 6; i++) {
                const rx = ((progress * 1234 + i * 187) % w);
                const ry = sweepY - (Math.random() * 40);
                ctx.fillStyle = i % 2 === 0 ? "#38bdf8" : "#f59e0b";
                ctx.fillRect(rx, ry, 3, 3);
            }
        }

        // 5. Threat Detection Bounding Box (When Completed)
        if (cvIsThreatDetected) {
            const bx = w * sector.box.xRatio;
            const by = h * sector.box.yRatio;
            const bw = w * sector.box.wRatio;
            const bh = h * sector.box.hRatio;

            // Animated Red Bounding Box
            ctx.strokeStyle = "#ef4444";
            ctx.lineWidth = 2.5;
            ctx.shadowColor = "#ef4444";
            ctx.shadowBlur = 14;
            ctx.strokeRect(bx, by, bw, bh);
            ctx.shadowBlur = 0;

            // Corner Accents on Bounding Box
            const cLen = 14;
            ctx.lineWidth = 4;
            // Top-left
            ctx.beginPath(); ctx.moveTo(bx - 3, by + cLen); ctx.lineTo(bx - 3, by - 3); ctx.lineTo(bx + cLen, by - 3); ctx.stroke();
            // Top-right
            ctx.beginPath(); ctx.moveTo(bx + bw + 3 - cLen, by - 3); ctx.lineTo(bx + bw + 3, by - 3); ctx.lineTo(bx + bw + 3, by + cLen); ctx.stroke();
            // Bottom-left
            ctx.beginPath(); ctx.moveTo(bx - 3, by + bh - cLen); ctx.lineTo(bx - 3, by + bh + 3); ctx.lineTo(bx + cLen, by + bh + 3); ctx.stroke();
            // Bottom-right
            ctx.beginPath(); ctx.moveTo(bx + bw + 3 - cLen, by + bh + 3); ctx.lineTo(bx + bw + 3, by + bh + 3); ctx.lineTo(bx + bw + 3, by + bh + 3 - cLen); ctx.stroke();

            // Label Banner atop Bounding Box
            ctx.fillStyle = "rgba(239, 68, 68, 0.95)";
            ctx.fillRect(bx - 3, by - 26, Math.max(bw + 6, 210), 22);

            ctx.fillStyle = "#ffffff";
            ctx.font = "bold 10px 'Orbitron', monospace";
            ctx.fillText(`[!] DETECTED: ${sector.hazardType.toUpperCase()}`, bx + 4, by - 11);

            // Bottom Metric Tag
            ctx.fillStyle = "rgba(15, 23, 42, 0.9)";
            ctx.fillRect(bx - 3, by + bh + 4, Math.max(bw + 6, 210), 20);
            ctx.strokeStyle = "#ef4444";
            ctx.lineWidth = 1;
            ctx.strokeRect(bx - 3, by + bh + 4, Math.max(bw + 6, 210), 20);

            ctx.fillStyle = "#38bdf8";
            ctx.font = "10px 'Orbitron', monospace";
            ctx.fillText(`CONF: ${sector.confidence} | EXTENT: ${sector.area}`, bx + 4, by + bh + 18);
        }
    }

    // Update UI elements for active sector
    function updateSectorUI() {
        const sector = SATELLITE_SECTORS[activeSatelliteSectorIdx];
        if (hudCoords) hudCoords.innerText = sector.coords;
        if (satMission) satMission.innerText = sector.mission;
        if (satRes) satRes.innerText = sector.res;

        const secVal = document.getElementById("cv-sector-val");
        if (secVal) secVal.innerText = sector.city || sector.region;

        const typeVal = document.getElementById("cv-type-val");
        const confVal = document.getElementById("cv-confidence-val");
        if (typeVal) typeVal.innerText = cvIsThreatDetected ? sector.hazardType : "-";
        if (confVal) confVal.innerText = cvIsThreatDetected ? sector.confidence : "0.0%";

        renderScene();
    }

    // 1. Sector Switch Pills Listener
    const sectorPills = document.querySelectorAll(".cv-sector-pill");
    sectorPills.forEach(pill => {
        pill.addEventListener("click", () => {
            sectorPills.forEach(p => p.classList.remove("active"));
            pill.classList.add("active");
            activeSatelliteSectorIdx = parseInt(pill.getAttribute("data-sector-idx")) || 0;
            cvIsThreatDetected = false;
            if (alertBanner) alertBanner.classList.add("hidden");
            if (logBtn) logBtn.classList.add("hidden");
            if (tip) tip.classList.remove("hidden");
            updateSectorUI();
        });
    });

    // 2. Spectrum Mode Buttons Listener
    const spectrumBtns = document.querySelectorAll(".cv-spectrum-btn");
    spectrumBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            spectrumBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            activeSpectrumMode = btn.getAttribute("data-spectrum") || "rgb";
            renderScene();
        });
    });

    // 3. Initiate Visual Scan Button Click
    startBtn.addEventListener("click", () => {
        if (isScanning) return;
        isScanning = true;
        scanProgress = 0;
        cvIsThreatDetected = false;

        if (tip) tip.classList.add("hidden");
        if (alertBanner) alertBanner.classList.add("hidden");
        if (logBtn) logBtn.classList.add("hidden");
        startBtn.classList.add("btn-secondary");
        startBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> RUNNING RESNET-50 NEURAL SCAN...`;

        const sector = SATELLITE_SECTORS[activeSatelliteSectorIdx];
        const secVal = document.getElementById("cv-sector-val");
        const typeVal = document.getElementById("cv-type-val");
        const confVal = document.getElementById("cv-confidence-val");
        if (secVal) secVal.innerText = sector.city || sector.region;
        if (typeVal) typeVal.innerText = "SCANNING...";
        if (confVal) confVal.innerText = "--%";

        function tick() {
            if (!isScanning) return;
            scanProgress += 0.015;

            renderScene(scanProgress);

            if (scanProgress < 1.0) {
                animId = requestAnimationFrame(tick);
            } else {
                // Completed scan!
                isScanning = false;
                cvIsThreatDetected = true;
                startBtn.classList.remove("btn-secondary");
                startBtn.innerHTML = `<i class="fa-solid fa-satellite-dish"></i> INITIATE VISUAL SCAN`;

                renderScene(1.0);

                if (typeVal) typeVal.innerText = sector.hazardType;
                if (confVal) confVal.innerText = sector.confidence;

                if (alertBanner) {
                    alertBanner.classList.remove("hidden");
                    if (alertMsg) alertMsg.innerText = `CRITICAL THREAT: ${sector.hazardType.toUpperCase()} (${sector.confidence})`;
                }
                if (logBtn) logBtn.classList.remove("hidden");
            }
        }
        tick();
    });

    // 4. Log Detected Hazard Button Click
    logBtn.addEventListener("click", () => {
        const sector = SATELLITE_SECTORS[activeSatelliteSectorIdx];

        const regField = document.getElementById("report-region");
        if (regField) regField.value = sector.region;
        const cityField = document.getElementById("report-city");
        if (cityField) cityField.value = sector.city;
        const popField = document.getElementById("report-population");
        if (popField) popField.value = sector.population || 420000;

        const typeField = document.getElementById("report-type");
        if (typeField) typeField.value = sector.hazardType.includes("Flood") ? "Flash Flood" : "Landslide";

        const latField = document.getElementById("report-lat");
        if (latField) latField.value = sector.lat;
        const lngField = document.getElementById("report-lng");
        if (lngField) lngField.value = sector.lng;

        const riskField = document.getElementById("report-risk");
        if (riskField) riskField.value = sector.risk;
        const valRisk = document.getElementById("val-report-risk");
        if (valRisk) valRisk.innerText = sector.risk + "%";

        // Switch to Tactical map tab
        const tacticalTab = document.getElementById("tab-btn-tactical");
        if (tacticalTab) tacticalTab.click();

        if (map) {
            setTimeout(() => {
                map.invalidateSize();
                map.flyTo([sector.lat, sector.lng], 13);
            }, 150);
        }

        alert(`Satellite Threat Verified & Synced: ${sector.hazardType} at ${sector.city}. Navigating to Tactical Incident Command.`);
    });

    // Initial render
    updateSectorUI();
}

const MOCK_SOCIAL_POSTS = [
    { author: "@chennai_traffic", text: "Severe waterlogging across Velachery and Tambaram residential wards in Tamil Nadu! Water entering houses. NDRF boats on standby.", location: "Tamil Nadu & Coromandel Coast", city: "Chennai (Velachery & Tambaram Wards)", type: "Flash Flood", lat: 12.9792, lng: 80.2185, risk: 92, severity: "Critical", population: 420000 },
    { author: "@coimbatore_news", text: "Heavy cloudburst in Gandhipuram and RS Puram living areas in Coimbatore. Underpasses flooded, residents moving to upper floors.", location: "Tamil Nadu & Coromandel Coast", city: "Coimbatore (Gandhipuram & RS Puram)", type: "Flash Flood", lat: 11.0168, lng: 76.9558, risk: 81, severity: "High", population: 510000 },
    { author: "@madurai_alerts", text: "Vaigai river overflowing into Goripalayam and Sellur residential streets in Madurai. Alert sounded for riverside residents!", location: "Tamil Nadu & Coromandel Coast", city: "Madurai (Goripalayam & Vaigai Riverside)", type: "Flash Flood", lat: 9.9252, lng: 78.1198, risk: 88, severity: "Critical", population: 450000 },
    { author: "@nilgiris_alert", text: "Major landslide and treefall along Coonoor-Ooty hillside settlements in Nilgiris. Residents evacuated to relief centres.", location: "Tamil Nadu & Coromandel Coast", city: "Nilgiris (Ooty & Coonoor Hill Settlements)", type: "Landslide", lat: 11.4102, lng: 76.6950, risk: 84, severity: "High", population: 140000 },
    { author: "@cuddalore_voice", text: "Massive coastal storm surge hitting Silver Beach coastal villages in Cuddalore. Fishermen families shifted to cyclone shelters.", location: "Tamil Nadu & Coromandel Coast", city: "Cuddalore (Silver Beach Coastal Habitation)", type: "Hurricane", lat: 11.7480, lng: 79.7714, risk: 88, severity: "High", population: 180000 },
    { author: "@kerala_watch", text: "Torrential downpour triggers flash flood alert across Ernakulam & Marine Drive coastal suburbs in Kochi. Relief sirens active.", location: "Kerala & Western Ghats", city: "Kochi (Ernakulam & Marine Drive Suburbs)", type: "Flash Flood", lat: 9.9312, lng: 76.2673, risk: 94, severity: "Critical", population: 610000 },
    { author: "@wayanad_live", text: "Urgent landslide warning in Meppadi & Chooralmala settlements in Wayanad. Army and rescue teams mobilized.", location: "Kerala & Western Ghats", city: "Wayanad (Meppadi & Chooralmala Hill Settlement)", type: "Landslide", lat: 11.5284, lng: 76.1664, risk: 97, severity: "Critical", population: 65000 },
    { author: "@assam_updates", text: "Brahmaputra river breaches embankments at Majuli island tribal villages. 50,000 residents awaiting rescue boats.", location: "Assam & North-East", city: "Majuli (River Island Tribal Village Settlements)", type: "Flash Flood", lat: 26.9500, lng: 94.2167, risk: 93, severity: "Critical", population: 170000 },
    { author: "@kolkata_pulse", text: "Cyclone storm surge warnings in Sundarbans Gosaba coastal settlements and water inundation in Howrah residential areas.", location: "Odisha & Bengal Coast", city: "Kolkata & Sundarbans (Howrah & Gosaba Settlements)", type: "Hurricane", lat: 22.1643, lng: 88.8070, risk: 90, severity: "Critical", population: 450000 },
    { author: "@delhi_yamuna", text: "Yamuna river water level crosses 208.6m, flooding Yamuna Bazar and Civil Lines residential colonies in Delhi NCR.", location: "Indo-Gangetic & Central Plains", city: "Delhi NCR (Yamuna Floodplain & Bazar Colonies)", type: "Flash Flood", lat: 28.6139, lng: 77.2090, risk: 89, severity: "Critical", population: 410000 }
];

function setupNlpSocialIntake() {
    const list = document.getElementById("nlp-stream-list");
    const deployBtn = document.getElementById("nlp-deploy-btn");

    if (!list || !deployBtn) return;

    let index = 0;
    list.innerHTML = ""; // Clear loader

    function addTweet() {
        const post = MOCK_SOCIAL_POSTS[index];
        const div = document.createElement("div");
        div.className = "tweet-item";
        div.innerHTML = `
            <div class="tweet-header">
                <span class="tweet-author">${post.author}</span>
                <span>Just Now</span>
            </div>
            <div class="tweet-body">${post.text}</div>
        `;

        div.addEventListener("click", () => {
            // Unhighlight all others
            document.querySelectorAll(".tweet-item").forEach(el => el.classList.remove("active"));
            div.classList.add("active");

            // Save active post
            selectedNlpPost = post;

            // Run mock NLP highlighting: parse text by wrapping keywords
            let parsedText = post.text
                .replace(post.location, `<span class="nlp-location-highlight">${post.location}</span>`)
                .replace(post.type, `<span class="nlp-entity-highlight">${post.type}</span>`);

            div.querySelector(".tweet-body").innerHTML = parsedText;

            // Fill NLP output
            document.getElementById("nlp-entity-loc").innerText = post.city ? post.city : post.location;
            document.getElementById("nlp-entity-type").innerText = post.type;

            const badge = document.getElementById("nlp-entity-severity");
            badge.innerText = post.severity.toUpperCase();
            badge.className = `badge ${post.severity.toLowerCase()}`;

            document.getElementById("nlp-entity-confidence").innerText = "94.2%";

            deployBtn.classList.remove("hidden");
        });

        // Add to top of stream list
        list.insertBefore(div, list.firstChild);

        // Keep maximum 5 tweets in the list
        if (list.children.length > 5) {
            list.removeChild(list.lastChild);
        }

        index = (index + 1) % MOCK_SOCIAL_POSTS.length;
    }

    // Initial seed
    addTweet();
    addTweet();

    // Stream interval
    nlpStreamInterval = setInterval(addTweet, 7000);

    deployBtn.addEventListener("click", () => {
        if (!selectedNlpPost) return;

        // Fill form
        document.getElementById("report-region").value = selectedNlpPost.location;
        const cityField = document.getElementById("report-city");
        if (cityField) cityField.value = selectedNlpPost.city || selectedNlpPost.location;
        const popField = document.getElementById("report-population");
        if (popField) popField.value = selectedNlpPost.population || 30000;

        document.getElementById("report-type").value = selectedNlpPost.type;
        document.getElementById("report-lat").value = selectedNlpPost.lat;
        document.getElementById("report-lng").value = selectedNlpPost.lng;
        document.getElementById("report-risk").value = selectedNlpPost.risk;
        document.getElementById("val-report-risk").innerText = selectedNlpPost.risk + "%";

        // Tab click
        document.getElementById("tab-btn-tactical").click();

        // Target marker
        if (clickTargetMarker) {
            map.removeLayer(clickTargetMarker);
        }
        const targetIcon = L.divIcon({
            className: 'custom-target-icon',
            html: '<div style="border: 2px solid #EF4444; width: 20px; height: 20px; border-radius: 50%; box-shadow: 0 0 8px rgba(239,68,68,0.7); position: relative;"><div style="position: absolute; width: 2px; height: 24px; background: #EF4444; left: 7px; top: -4px;"></div><div style="position: absolute; width: 24px; height: 2px; background: #EF4444; left: -4px; top: 7px;"></div></div>',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });
        clickTargetMarker = L.marker([selectedNlpPost.lat, selectedNlpPost.lng], { icon: targetIcon }).addTo(map);
        map.setView([selectedNlpPost.lat, selectedNlpPost.lng], 6);

        alert(`NLP incident entities loaded for ${selectedNlpPost.city || selectedNlpPost.location}. Click "Log Incident" to broadcast system alerts.`);
    });
}

// ==========================================================================
// ESP32 MICRO-STATION HARDWARE EARLY-WARNING GATEWAY CONTROLLER (MODULE 7)
// ==========================================================================
let esp32AudioCtx = null;
let esp32IsCritical = false;
let esp32IsMuted = false;

function playEsp32PiezoTone() {
    if (esp32IsMuted || !esp32IsCritical) return;
    try {
        if (!esp32AudioCtx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) esp32AudioCtx = new AudioContext();
        }
        if (esp32AudioCtx && esp32AudioCtx.state === "suspended") {
            esp32AudioCtx.resume();
        }
        if (!esp32AudioCtx) return;

        // 2.4 kHz piezo resonance
        const osc = esp32AudioCtx.createOscillator();
        const gain = esp32AudioCtx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(2400, esp32AudioCtx.currentTime);

        // 250ms short piercing beep envelope
        gain.gain.setValueAtTime(0.12, esp32AudioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, esp32AudioCtx.currentTime + 0.25);

        osc.connect(gain);
        gain.connect(esp32AudioCtx.destination);
        osc.start();
        osc.stop(esp32AudioCtx.currentTime + 0.25);

        // Visual wave pulse animation
        const indicator = document.getElementById("esp32-piezo-indicator");
        if (indicator) {
            indicator.classList.add("buzzing");
            setTimeout(() => {
                if (!esp32IsCritical || esp32IsMuted) {
                    indicator.classList.remove("buzzing");
                }
            }, 300);
        }
    } catch (e) {
        console.warn("[ESP32 WebAudio] tone synthesis notice:", e);
    }
}

let esp32HistoryChart = null;
let esp32MapMarker = null;

function setupEsp32HardwareConsole() {
    const redBulb = document.getElementById("esp32-red-bulb");
    const greenBulb = document.getElementById("esp32-green-bulb");
    const piezoIndicator = document.getElementById("esp32-piezo-indicator");
    const piezoIcon = document.getElementById("esp32-piezo-icon");
    const piezoStatusTxt = document.getElementById("esp32-piezo-status-txt");
    const btnMute = document.getElementById("btn-esp32-mute");
    const btnMuteTxt = document.getElementById("btn-esp32-mute-txt");

    const waterVal = document.getElementById("esp32-water-val");
    const waterBar = document.getElementById("esp32-water-bar");
    const rainVal = document.getElementById("esp32-rain-val");
    const rainBar = document.getElementById("esp32-rain-bar");
    const soilVal = document.getElementById("esp32-soil-val");
    const soilBar = document.getElementById("esp32-soil-bar");
    const tempVal = document.getElementById("esp32-temp-val");
    const tempBar = document.getElementById("esp32-temp-bar");
    const humidityVal = document.getElementById("esp32-humidity-val");
    const humidityBar = document.getElementById("esp32-humidity-bar");
    const riskBadge = document.getElementById("esp32-risk-badge");
    const riskScoreVal = document.getElementById("esp32-risk-score-val");
    const riskScoreBar = document.getElementById("esp32-risk-score-bar");
    const predictionTxt = document.getElementById("esp32-prediction-txt");

    // Block Diagram Live Indicators
    const diagSensorsVal = document.getElementById("diag-sensors-val");
    const diagEsp32Status = document.getElementById("diag-esp32-status");
    const diagTxStatus = document.getElementById("diag-tx-status");
    const diagRiskVal = document.getElementById("diag-risk-val");
    const diagAlertUnitVal = document.getElementById("diag-alert-unit-val");
    const diagHistoryVal = document.getElementById("diag-history-val");
    const diagDashboardVal = document.getElementById("diag-dashboard-val");
    const statusPathCurrentTxt = document.getElementById("status-path-current-txt");

    // Status Path Buttons
    const btnPathNormal = document.getElementById("btn-path-normal");
    const btnPathWarning = document.getElementById("btn-path-warning");
    const btnPathCritical = document.getElementById("btn-path-critical");

    // Navigation Buttons
    const btnGotoIncidentMap = document.getElementById("btn-goto-incident-map");
    const btnGotoEarlyWarning = document.getElementById("btn-goto-early-warning");

    // Telemetry History Chart Initialization
    function initEsp32HistoryChart() {
        const ctx = document.getElementById("chart-esp32-history");
        if (!ctx || typeof Chart === "undefined") return;
        if (esp32HistoryChart) return;

        esp32HistoryChart = new Chart(ctx, {
            type: "line",
            data: {
                labels: [],
                datasets: [
                    {
                        label: "Water Level (cm)",
                        data: [],
                        borderColor: "#38bdf8",
                        backgroundColor: "rgba(56, 189, 248, 0.15)",
                        borderWidth: 2,
                        tension: 0.3,
                        pointRadius: 2,
                        fill: false
                    },
                    {
                        label: "Rain Rate (mm/h)",
                        data: [],
                        borderColor: "#60a5fa",
                        backgroundColor: "rgba(96, 165, 250, 0.15)",
                        borderWidth: 2,
                        tension: 0.3,
                        pointRadius: 2,
                        fill: false
                    },
                    {
                        label: "Soil Saturation (%)",
                        data: [],
                        borderColor: "#f59e0b",
                        backgroundColor: "rgba(245, 158, 11, 0.15)",
                        borderWidth: 2,
                        tension: 0.3,
                        pointRadius: 2,
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 400 },
                plugins: {
                    legend: {
                        position: "top",
                        labels: {
                            boxWidth: 10,
                            font: { size: 9 },
                            color: "#94a3b8"
                        }
                    },
                    tooltip: {
                        mode: "index",
                        intersect: false
                    }
                },
                scales: {
                    x: {
                        grid: { color: "rgba(255, 255, 255, 0.05)" },
                        ticks: { font: { size: 9 }, color: "#64748b", maxTicksLimit: 7 }
                    },
                    y: {
                        grid: { color: "rgba(255, 255, 255, 0.05)" },
                        ticks: { font: { size: 9 }, color: "#64748b" },
                        suggestedMin: 0,
                        suggestedMax: 180
                    }
                }
            }
        });
    }

    async function fetchEsp32History() {
        try {
            const res = await fetch(`${API_BASE}/esp32/history`);
            if (res.ok) {
                const data = await res.json();
                const list = data.history || [];
                if (diagHistoryVal) {
                    diagHistoryVal.innerText = `/api/esp32/history (${list.length} records)`;
                }
                if (esp32HistoryChart && list.length > 0) {
                    const recent = list.slice(-15);
                    esp32HistoryChart.data.labels = recent.map(r => r.timeFormatted || r.timeStr || (r.timestamp ? new Date(r.timestamp).toLocaleTimeString() : ""));
                    esp32HistoryChart.data.datasets[0].data = recent.map(r => (r.waterLevelCm !== undefined ? r.waterLevelCm : r.waterLevel));
                    esp32HistoryChart.data.datasets[1].data = recent.map(r => (r.rainfallRateMmHr !== undefined ? r.rainfallRateMmHr : r.rain));
                    esp32HistoryChart.data.datasets[2].data = recent.map(r => (r.soilMoisturePct !== undefined ? r.soilMoisturePct : r.soilMoisture));
                    esp32HistoryChart.update();
                }
            }
        } catch (err) {
            console.warn("Telemetry history fetch failed:", err);
        }
    }

    function updateMapStationMarker(statusPath, water, rain, riskScore, riskLevel) {
        if (!map || typeof L === "undefined") return;
        const lat = 12.9792;
        const lng = 80.2185;

        const isCrit = statusPath === "Critical";
        const isWarn = statusPath === "Warning";
        const markerColor = isCrit ? "#ef4444" : (isWarn ? "#f59e0b" : "#10b981");

        const iconHtml = `
            <div style="position:relative; width:28px; height:28px; display:flex; align-items:center; justify-content:center;">
                <div style="position:absolute; width:100%; height:100%; border-radius:50%; background:${markerColor}; opacity:0.35; animation:pulseBeacon 1.5s infinite;"></div>
                <div style="width:14px; height:14px; border-radius:50%; background:${markerColor}; border:2px solid #fff; box-shadow:0 0 10px ${markerColor};"></div>
            </div>
        `;
        const customIcon = L.divIcon({
            html: iconHtml,
            className: "esp32-station-marker",
            iconSize: [28, 28],
            iconAnchor: [14, 14]
        });

        const popupContent = `
            <div style="font-family:sans-serif; font-size:12px; color:#0f172a; min-width:180px;">
                <strong style="color:#0284c7; font-size:13px;"><i class="fa-solid fa-microchip"></i> ESP32-S3 IoT Gateway</strong><br>
                <span style="font-size:10px; color:#64748b;">Station ID: ESP32-AEGIS-IN-01 (Pallikaranai)</span>
                <hr style="margin:4px 0; border:none; border-top:1px solid #e2e8f0;">
                <div>Status Path: <b style="color:${markerColor};">${statusPath}</b></div>
                <div>Water Stage: <b>${water.toFixed(1)} cm</b> (Crit ≥ 150cm)</div>
                <div>Rain Rate: <b>${rain.toFixed(1)} mm/h</b></div>
                <div>Java Risk Score: <b>${riskScore.toFixed(1)}/100 (${riskLevel})</b></div>
            </div>
        `;

        if (!esp32MapMarker) {
            esp32MapMarker = L.marker([lat, lng], { icon: customIcon }).addTo(map);
            esp32MapMarker.bindPopup(popupContent);
        } else {
            esp32MapMarker.setIcon(customIcon);
            esp32MapMarker.setPopupContent(popupContent);
        }
    }

    // 1. Telemetry Sync Poller (Every 2000ms)
    async function pollEsp32Status() {
        try {
            const res = await fetch(`${API_BASE}/esp32/status`);
            if (res.ok) {
                const data = await res.json();
                const sensors = data.sensors || {};
                const alertState = data.alertState || {};
                const alertUnit = data.localAlertUnit || {};
                const risk = data.riskAssessment || {};
                const block = data.blockDiagram || {};
                const statusPath = data.statusPath || block.statusPath || "Normal";

                // Update gauges
                if (waterVal && sensors.waterLevelCm !== undefined) {
                    waterVal.innerText = `${sensors.waterLevelCm.toFixed(1)} cm`;
                    if (waterBar) {
                        const pct = Math.min(100, (sensors.waterLevelCm / 200.0) * 100);
                        waterBar.style.width = `${pct}%`;
                        waterBar.style.background = sensors.waterLevelCm >= 150 ? "#ef4444" : (sensors.waterLevelCm >= 100 ? "#f59e0b" : "var(--accent-cyan-light)");
                    }
                }
                if (rainVal && sensors.rainfallRateMmHr !== undefined) {
                    rainVal.innerText = `${sensors.rainfallRateMmHr.toFixed(1)} mm/h`;
                    if (rainBar) {
                        const pct = Math.min(100, (sensors.rainfallRateMmHr / 60.0) * 100);
                        rainBar.style.width = `${pct}%`;
                        rainBar.style.background = sensors.rainfallRateMmHr >= 45 ? "#ef4444" : (sensors.rainfallRateMmHr >= 25 ? "#f59e0b" : "#60a5fa");
                    }
                }
                if (soilVal && sensors.soilMoisturePct !== undefined) {
                    soilVal.innerText = `${Math.round(sensors.soilMoisturePct)}%`;
                    if (soilBar) {
                        soilBar.style.width = `${Math.min(100, sensors.soilMoisturePct)}%`;
                        soilBar.style.background = sensors.soilMoisturePct >= 90 ? "#ef4444" : "var(--accent-amber)";
                    }
                }
                if (tempVal && sensors.temperatureC !== undefined) {
                    tempVal.innerText = `${sensors.temperatureC.toFixed(1)} °C`;
                    if (tempBar) tempBar.style.width = `${Math.min(100, (sensors.temperatureC / 50.0) * 100)}%`;
                }
                if (humidityVal && sensors.humidityPct !== undefined) {
                    humidityVal.innerText = `${Math.round(sensors.humidityPct)}%`;
                    if (humidityBar) {
                        humidityBar.style.width = `${Math.min(100, sensors.humidityPct)}%`;
                        humidityBar.style.background = sensors.humidityPct >= 85 ? "#ef4444" : "#38bdf8";
                    }
                }

                // Update Java Composite Risk Score
                const score = risk.javaRiskScore !== undefined ? risk.javaRiskScore : 24.5;
                const level = risk.riskLevel || risk.level || "Low";
                if (riskScoreVal) riskScoreVal.innerText = `${score.toFixed(1)} / 100`;
                if (riskScoreBar) {
                    riskScoreBar.style.width = `${Math.min(100, score)}%`;
                    riskScoreBar.style.background = level === "Critical" ? "#ef4444" : (level === "High" ? "#f59e0b" : (level === "Medium" ? "#38bdf8" : "#10b981"));
                }
                if (riskBadge) {
                    riskBadge.innerText = `${level.toUpperCase()} RISK`;
                    riskBadge.style.color = level === "Critical" ? "#ef4444" : (level === "High" ? "#f59e0b" : (level === "Medium" ? "#38bdf8" : "#10b981"));
                }
                if (predictionTxt && risk.prediction) {
                    predictionTxt.innerText = risk.prediction;
                }

                // Update Status Path UI & Stepper Buttons
                if (statusPathCurrentTxt) {
                    statusPathCurrentTxt.innerText = statusPath;
                    statusPathCurrentTxt.style.color = statusPath === "Critical" ? "#ef4444" : (statusPath === "Warning" ? "#f59e0b" : "#10b981");
                }
                if (btnPathNormal) {
                    if (statusPath === "Normal") btnPathNormal.classList.add("active-normal");
                    else btnPathNormal.classList.remove("active-normal");
                }
                if (btnPathWarning) {
                    if (statusPath === "Warning") btnPathWarning.classList.add("active-warning");
                    else btnPathWarning.classList.remove("active-warning");
                }
                if (btnPathCritical) {
                    if (statusPath === "Critical") btnPathCritical.classList.add("active-critical");
                    else btnPathCritical.classList.remove("active-critical");
                }

                // Update Block Diagram Nodes
                if (diagSensorsVal && sensors.waterLevelCm !== undefined) {
                    diagSensorsVal.innerText = `${sensors.waterLevelCm.toFixed(1)}cm | ${sensors.rainfallRateMmHr.toFixed(1)}mm/h | ${Math.round(sensors.soilMoisturePct)}% | ${sensors.temperatureC.toFixed(1)}°C`;
                }
                if (diagEsp32Status) {
                    diagEsp32Status.innerText = `Cycle: 2000ms · Status: ${statusPath}`;
                }
                if (diagTxStatus) {
                    diagTxStatus.innerText = `200 OK · Wi-Fi HTTP JSON`;
                }
                if (diagRiskVal) {
                    diagRiskVal.innerText = `Score: ${score.toFixed(1)} (${level})`;
                }
                if (diagAlertUnitVal) {
                    const redOn = alertUnit.redLed;
                    const buzTxt = alertUnit.buzzer ? "SOUNDING (4s)" : (alertUnit.buzzerMuted ? "MUTED" : "STANDBY");
                    diagAlertUnitVal.innerText = `RED: ${redOn ? "ON" : "OFF"} | GREEN: ${!redOn ? "ON" : "OFF"} | BUZ: ${buzTxt}`;
                    diagAlertUnitVal.style.color = redOn ? "#fca5a5" : "#6ee7b7";
                }
                if (diagDashboardVal) {
                    diagDashboardVal.innerText = `Cards · Charts · Map Beacon Active`;
                }

                // Update alert state variables
                esp32IsCritical = (statusPath === "Critical") || !!alertState.isCritical;
                esp32IsMuted = !!alertUnit.buzzerMuted || !!alertState.buzzerMuted;

                // Update physical LED indicators
                if (redBulb) {
                    if (alertUnit.redLed || alertState.redLed) redBulb.classList.add("red-active");
                    else redBulb.classList.remove("red-active");
                }
                if (greenBulb) {
                    if (alertUnit.greenLed || alertState.greenLed) greenBulb.classList.add("green-active");
                    else greenBulb.classList.remove("green-active");
                }

                // Update Mute button UI
                if (btnMute && btnMuteTxt) {
                    if (esp32IsMuted) {
                        btnMute.classList.add("is-muted");
                        btnMuteTxt.innerText = "Buzzer Muted (Active)";
                    } else {
                        btnMute.classList.remove("is-muted");
                        btnMuteTxt.innerText = "Mute Buzzer";
                    }
                }

                // Update Piezo Siren status
                if (piezoIndicator && piezoStatusTxt && piezoIcon) {
                    if (esp32IsCritical) {
                        if (esp32IsMuted) {
                            piezoIndicator.classList.remove("buzzing");
                            piezoIcon.className = "fa-solid fa-volume-xmark";
                            piezoStatusTxt.innerText = "MUTED BY OPERATOR (GPIO 4)";
                        } else {
                            piezoIndicator.classList.add("buzzing");
                            piezoIcon.className = "fa-solid fa-volume-high";
                            piezoStatusTxt.innerText = "CRITICAL ALARM (4s CYCLE)";
                        }
                    } else {
                        piezoIndicator.classList.remove("buzzing");
                        piezoIcon.className = "fa-solid fa-volume-high";
                        piezoStatusTxt.innerText = "STANDBY (4s CYCLE)";
                    }
                }

                // Update Tactical Incident Map Beacon
                updateMapStationMarker(statusPath, sensors.waterLevelCm || 42.5, sensors.rainfallRateMmHr || 12.0, score, level);

                // Sync mini-gauges in tab-capture
                const miniWater = document.getElementById("mini-water-val");
                const miniRain = document.getElementById("mini-rain-val");
                const miniStatus = document.getElementById("mini-status-path");
                if (miniWater && sensors.waterLevelCm !== undefined) {
                    miniWater.innerText = `${sensors.waterLevelCm.toFixed(1)} cm`;
                }
                if (miniRain && sensors.rainfallRateMmHr !== undefined) {
                    miniRain.innerText = `${sensors.rainfallRateMmHr.toFixed(1)} mm/h`;
                }
                if (miniStatus) {
                    miniStatus.innerText = statusPath;
                    miniStatus.style.color = statusPath === "Critical" ? "#ef4444" : (statusPath === "Warning" ? "#f59e0b" : "#10b981");
                }

                // Log to simulated serial terminal in dedicated tab
                const terminal = document.getElementById("esp32-serial-terminal");
                if (terminal) {
                    const time = new Date().toLocaleTimeString();
                    const isCrit = statusPath === "Critical";
                    const isWarn = statusPath === "Warning";
                    const colorClass = isCrit ? "terminal-line-crit" : (isWarn ? "terminal-line-warn" : "terminal-line-success");
                    const logLine = document.createElement("div");
                    logLine.innerHTML = `<span class="terminal-line-timestamp">[${time}]</span> <span class="${colorClass}">[UPLINK 200 OK]</span> Water: <b>${(sensors.waterLevelCm || 42.5).toFixed(1)}cm</b> | Rain: <b>${(sensors.rainfallRateMmHr || 12.0).toFixed(1)}mm/h</b> | Soil: <b>${Math.round(sensors.soilMoisturePct || 52)}%</b> | Path: <b>${statusPath}</b> | Java: <b>${score.toFixed(1)} (${level})</b>`;
                    terminal.appendChild(logLine);
                    while (terminal.childNodes.length > 20) {
                        terminal.removeChild(terminal.firstChild);
                    }
                    terminal.scrollTop = terminal.scrollHeight;
                }
            }
        } catch (e) {
            // Offline fallback
            if (waterVal) {
                let cur = parseFloat(waterVal.innerText) || 42.5;
                cur += (Math.random() - 0.49) * 0.4;
                waterVal.innerText = `${cur.toFixed(1)} cm`;
            }
        }
    }

    // Initialize Chart and Map Beacon
    initEsp32HistoryChart();
    fetchEsp32History();
    pollEsp32Status();

    setInterval(pollEsp32Status, 2000);
    setInterval(fetchEsp32History, 4000);

    // Continuous 4-Second Audible Piezo Repetition Engine
    setInterval(() => {
        if (esp32IsCritical && !esp32IsMuted) {
            playEsp32PiezoTone();
        }
    }, 4000);

    // Interactive Mute Button Listener
    if (btnMute) {
        btnMute.addEventListener("click", async () => {
            try {
                const res = await fetch(`${API_BASE}/esp32/mute`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({})
                });
                if (res.ok) {
                    const data = await res.json();
                    esp32IsMuted = data.buzzerMuted;
                    if (btnMuteTxt) btnMuteTxt.innerText = esp32IsMuted ? "Buzzer Muted (Active)" : "Mute Buzzer";
                    if (esp32IsMuted) {
                        btnMute.classList.add("is-muted");
                        if (piezoIndicator) piezoIndicator.classList.remove("buzzing");
                        if (piezoStatusTxt) piezoStatusTxt.innerText = "MUTED BY OPERATOR (GPIO 4)";
                    } else {
                        btnMute.classList.remove("is-muted");
                    }
                }
            } catch (err) {
                esp32IsMuted = !esp32IsMuted;
                if (btnMuteTxt) btnMuteTxt.innerText = esp32IsMuted ? "Buzzer Muted (Active)" : "Mute Buzzer";
            }
        });
    }

    // Status Path Buttons Click Handlers
    async function triggerStatusPath(level) {
        try {
            await fetch(`${API_BASE}/esp32/telemetry?level=${level}`);
            await pollEsp32Status();
            await fetchEsp32History();
        } catch (e) {
            console.error(`Status path trigger error (${level}):`, e);
        }
    }

    if (btnPathNormal) btnPathNormal.addEventListener("click", () => triggerStatusPath("normal"));
    if (btnPathWarning) btnPathWarning.addEventListener("click", () => triggerStatusPath("warning"));
    if (btnPathCritical) btnPathCritical.addEventListener("click", () => triggerStatusPath("critical"));

    // Legacy buttons if present
    const btnSurge = document.getElementById("btn-esp32-surge");
    const btnNormal = document.getElementById("btn-esp32-normal");
    if (btnSurge) btnSurge.addEventListener("click", () => triggerStatusPath("critical"));
    if (btnNormal) btnNormal.addEventListener("click", () => triggerStatusPath("normal"));

    // Navigation Buttons
    if (btnGotoIncidentMap) {
        btnGotoIncidentMap.addEventListener("click", () => {
            const tacticalTab = document.getElementById("tab-btn-tactical");
            if (tacticalTab) tacticalTab.click();
            if (map) {
                setTimeout(() => {
                    map.invalidateSize();
                    map.flyTo([12.9792, 80.2185], 13);
                    if (esp32MapMarker) esp32MapMarker.openPopup();
                }, 150);
            }
        });
    }

    if (btnGotoEarlyWarning) {
        btnGotoEarlyWarning.addEventListener("click", () => {
            const ewTab = document.getElementById("tab-btn-earlywarning");
            if (ewTab) ewTab.click();
        });
    }
}

// ==========================================================================
// CALIBRATED MULTI-FACTOR HYDROLOGICAL FLOOD ENGINE (MODULE 3)
// ==========================================================================
function initHydrologicalFloodEngine() {
    const rainSlider = document.getElementById("flood-input-rain");
    const soilSlider = document.getElementById("flood-input-soil");
    const riverSlider = document.getElementById("flood-input-river");
    const slopeSlider = document.getElementById("flood-input-slope");
    const historySlider = document.getElementById("flood-input-history");

    const valRain = document.getElementById("val-flood-rain");
    const valSoil = document.getElementById("val-flood-soil");
    const valRiver = document.getElementById("val-flood-river");
    const valSlope = document.getElementById("val-flood-slope");
    const valHistory = document.getElementById("val-flood-history");

    const btnEval = document.getElementById("btn-eval-flood-risk");
    if (!btnEval) return;

    // Slider display synchronizers
    if (rainSlider && valRain) rainSlider.addEventListener("input", () => valRain.innerText = `${parseFloat(rainSlider.value).toFixed(1)} mm`);
    if (soilSlider && valSoil) soilSlider.addEventListener("input", () => valSoil.innerText = `${parseFloat(soilSlider.value).toFixed(1)}%`);
    if (riverSlider && valRiver) riverSlider.addEventListener("input", () => valRiver.innerText = `${parseFloat(riverSlider.value).toFixed(1)}%`);
    if (slopeSlider && valSlope) slopeSlider.addEventListener("input", () => valSlope.innerText = `${parseFloat(slopeSlider.value).toFixed(1)} m`);
    if (historySlider && valHistory) historySlider.addEventListener("input", () => valHistory.innerText = `${historySlider.value} events`);

    // Presets
    const presets = [
        { btn: "preset-basin-chennai", rain: 215, soil: 88, river: 94, slope: 6.5, hist: 21, city: "Chennai (Velachery / Pallikaranai Delta)", region: "Tamil Nadu & Coromandel Coast" },
        { btn: "preset-basin-wayanad", rain: 180, soil: 92, river: 75, slope: 45, hist: 12, city: "Wayanad (Meppadi Incline)", region: "Kerala & Western Ghats" },
        { btn: "preset-basin-assam", rain: 240, soil: 95, river: 98, slope: 8.0, hist: 28, city: "Brahmaputra (Majuli Floodplain)", region: "Assam & North-East" },
        { btn: "preset-basin-normal", rain: 35, soil: 40, river: 30, slope: 50, hist: 2, city: "Indo-Gangetic Basin", region: "Central Plains" }
    ];

    presets.forEach(p => {
        const el = document.getElementById(p.btn);
        if (el) {
            el.addEventListener("click", () => {
                presets.forEach(other => {
                    const oEl = document.getElementById(other.btn);
                    if (oEl) oEl.classList.remove("active");
                });
                el.classList.add("active");

                if (rainSlider) { rainSlider.value = p.rain; valRain.innerText = `${p.rain}.0 mm`; }
                if (soilSlider) { soilSlider.value = p.soil; valSoil.innerText = `${p.soil}.0%`; }
                if (riverSlider) { riverSlider.value = p.river; valRiver.innerText = `${p.river}.0%`; }
                if (slopeSlider) { slopeSlider.value = p.slope; valSlope.innerText = `${p.slope} m`; }
                if (historySlider) { historySlider.value = p.hist; valHistory.innerText = `${p.hist} events`; }

                const cityEl = document.getElementById("flood-target-city");
                const regEl = document.getElementById("flood-target-region");
                if (cityEl) cityEl.innerText = p.city;
                if (regEl) regEl.innerText = p.region;

                // Auto calculate
                btnEval.click();
            });
        }
    });

    btnEval.addEventListener("click", async () => {
        const rVal = parseFloat(rainSlider ? rainSlider.value : 215);
        const sVal = parseFloat(soilSlider ? soilSlider.value : 88);
        const rivVal = parseFloat(riverSlider ? riverSlider.value : 94);
        const slVal = parseFloat(slopeSlider ? slopeSlider.value : 6.5);
        const hVal = parseInt(historySlider ? historySlider.value : 21);

        btnEval.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> CALCULATING HYDROLOGICAL MATRIX...`;

        try {
            const url = `${API_BASE}/flood-risk?rainfall=${rVal}&soil=${sVal}&river=${rivVal}&slope=${slVal}&history=${hVal}`;
            const res = await fetch(url);
            if (res.ok) {
                const data = await res.json();

                // Score & Alert
                const scoreEl = document.getElementById("flood-score-val");
                if (scoreEl) scoreEl.innerText = data.floodRiskScore.toFixed(1);

                const alertBadge = document.getElementById("flood-alert-badge");
                if (alertBadge) {
                    alertBadge.innerText = data.officialAlert;
                    if (data.severityCategory === "CRITICAL") alertBadge.className = "badge badge-critical";
                    else if (data.severityCategory === "HIGH") alertBadge.className = "badge badge-warning";
                    else alertBadge.className = "badge badge-success";
                }

                // Sub indices bars
                const sub = data.subIndices || {};
                const fillRain = document.getElementById("fill-sub-rain");
                const valSubRain = document.getElementById("val-sub-rain");
                if (fillRain && valSubRain) {
                    fillRain.style.width = `${sub.rainfallVulnerability}%`;
                    valSubRain.innerText = `${sub.rainfallVulnerability.toFixed(1)}%`;
                }

                const fillSoil = document.getElementById("fill-sub-soil");
                const valSubSoil = document.getElementById("val-sub-soil");
                if (fillSoil && valSubSoil) {
                    fillSoil.style.width = `${sub.soilSaturationRunoff}%`;
                    valSubSoil.innerText = `${sub.soilSaturationRunoff.toFixed(1)}%`;
                }

                const fillRiver = document.getElementById("fill-sub-river");
                const valSubRiver = document.getElementById("val-sub-river");
                if (fillRiver && valSubRiver) {
                    fillRiver.style.width = `${sub.fluvialDrainageBackwater}%`;
                    valSubRiver.innerText = `${sub.fluvialDrainageBackwater.toFixed(1)}%`;
                }

                const fillSlope = document.getElementById("fill-sub-slope");
                const valSubSlope = document.getElementById("val-sub-slope");
                if (fillSlope && valSubSlope) {
                    fillSlope.style.width = `${sub.topographicDepressionRisk}%`;
                    valSubSlope.innerText = `${sub.topographicDepressionRisk.toFixed(1)}%`;
                }

                // Evidence list
                const evBox = document.getElementById("flood-evidence-box");
                if (evBox && data.triggerEvidence) {
                    evBox.innerHTML = "";
                    data.triggerEvidence.forEach(ev => {
                        const div = document.createElement("div");
                        div.className = "evidence-chip-item";
                        div.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> ${ev}`;
                        evBox.appendChild(div);
                    });
                }

                // Actions list
                const actBox = document.getElementById("flood-actions-box");
                if (actBox && data.precautionaryActions) {
                    actBox.innerHTML = "";
                    data.precautionaryActions.forEach(act => {
                        const div = document.createElement("div");
                        div.className = "action-chip-item";
                        div.innerHTML = `<i class="fa-solid fa-person-walking-arrow-right"></i> ${act}`;
                        actBox.appendChild(div);
                    });
                }
            }
        } catch (err) {
            console.error("Hydrological Flood Engine fetch failed:", err);
        } finally {
            btnEval.innerHTML = `<i class="fa-solid fa-calculator"></i> Run Hydrological Risk Assessment`;
        }
    });
}

// ==========================================================================
// LIVE SYNOPTIC WEATHER INTEGRATION (MODULE 1: OPEN-METEO REST API)
// ==========================================================================
async function initLiveWeatherFeed() {
    try {
        const weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=13.0827&longitude=80.2707&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m";
        const res = await fetch(weatherUrl);
        if (res.ok) {
            const data = await res.json();
            const cur = data.current || {};
            console.log("[Aegis Synoptic Weather] Live observations received:", cur);
        }
    } catch (e) {
        console.log("[Aegis Synoptic Weather] Baseline telemetry active.");
    }
}

// ==========================================================================
// 48-HOUR EARLY WARNING & EVACUATION ADVISORY MODULE
// ==========================================================================

function initEarlyWarningModule() {
    // Top banner Evac button
    const bannerEvacBtn = document.getElementById("banner-view-evac-btn");
    if (bannerEvacBtn) {
        bannerEvacBtn.addEventListener("click", () => {
            const evacTabBtn = document.getElementById("tab-btn-earlywarning");
            if (evacTabBtn) evacTabBtn.click();
        });
    }

    // Top banner Dismiss button
    const bannerDismissBtn = document.getElementById("banner-dismiss-btn");
    if (bannerDismissBtn) {
        bannerDismissBtn.addEventListener("click", () => {
            const banner = document.getElementById("early-warning-banner");
            if (banner) banner.style.display = "none";
        });
    }

    // Refresh Early Warnings button
    const refreshBtn = document.getElementById("refresh-early-warnings-btn");
    if (refreshBtn) {
        refreshBtn.addEventListener("click", () => {
            fetchEarlyWarnings(true);
        });
    }

    // SMS Modal Close
    const closeSmsBtn = document.getElementById("close-sms-modal-btn");
    if (closeSmsBtn) {
        closeSmsBtn.addEventListener("click", () => {
            document.getElementById("sms-broadcast-modal").classList.add("hidden");
        });
    }

    // Copy SMS English
    const copyEnBtn = document.getElementById("copy-sms-en-btn");
    if (copyEnBtn) {
        copyEnBtn.addEventListener("click", () => {
            const txt = document.getElementById("modal-sms-en-text").value;
            navigator.clipboard.writeText(txt).then(() => {
                showSmsCopyToast();
            });
        });
    }

    // Copy SMS Tamil
    const copyTaBtn = document.getElementById("copy-sms-ta-btn");
    if (copyTaBtn) {
        copyTaBtn.addEventListener("click", () => {
            const txt = document.getElementById("modal-sms-ta-text").value;
            navigator.clipboard.writeText(txt).then(() => {
                showSmsCopyToast();
            });
        });
    }

    // CSV Drag & Drop and Upload
    const dropZone = document.getElementById("csv-drop-zone");
    const fileInput = document.getElementById("csv-file-input");
    if (dropZone && fileInput) {
        dropZone.addEventListener("click", () => fileInput.click());
        dropZone.addEventListener("dragover", (e) => {
            e.preventDefault();
            dropZone.classList.add("dragover");
        });
        dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));
        dropZone.addEventListener("drop", (e) => {
            e.preventDefault();
            dropZone.classList.remove("dragover");
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                handleCsvUpload(e.dataTransfer.files[0]);
            }
        });
        fileInput.addEventListener("change", (e) => {
            if (e.target.files && e.target.files[0]) {
                handleCsvUpload(e.target.files[0]);
            }
        });
    }

    // Test 30s Countdown button (Module 6 testability)
    const test30sBtn = document.getElementById("btn-test-30s");
    if (test30sBtn) {
        test30sBtn.addEventListener("click", async () => {
            test30sBtn.disabled = true;
            test30sBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Arming 30s...`;
            try {
                const res = await fetch(`${API_BASE}/countdowns/reset?seconds=30`, { method: "POST" });
                if (res.ok) {
                    await syncPersistentCountdowns();
                    await fetchEarlyWarnings(true);
                    updateEarlyWarningCountdown();
                }
            } catch (e) {
                console.error("Failed to reset countdown to 30s", e);
            } finally {
                test30sBtn.disabled = false;
                test30sBtn.innerHTML = `<i class="fa-solid fa-stopwatch-20" style="color: #f59e0b;"></i> Test 30s Countdown`;
            }
        });
    }

    // Reset to 30h Countdown button
    const reset30hBtn = document.getElementById("btn-reset-30h") || document.getElementById("btn-reset-48h");
    if (reset30hBtn) {
        reset30hBtn.addEventListener("click", async () => {
            reset30hBtn.disabled = true;
            reset30hBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Resetting...`;
            try {
                const res = await fetch(`${API_BASE}/countdowns/reset?seconds=108000`, { method: "POST" });
                if (res.ok) {
                    localStorage.removeItem("aegis_primary_target_ts");
                    await syncPersistentCountdowns();
                    await fetchEarlyWarnings(true);
                    updateEarlyWarningCountdown();
                }
            } catch (e) {
                console.error("Failed to reset countdown to 30h", e);
            } finally {
                reset30hBtn.disabled = false;
                reset30hBtn.innerHTML = `<i class="fa-solid fa-clock-rotate-left" style="color: #38bdf8;"></i> Reset to 30h`;
            }
        });
    }

    // Uiverse.io Tactical Cards Click Listeners (From Uiverse.io by Samalander0)
        const cardChennai = document.getElementById("card-alert-chennai");
        if (cardChennai) {
            cardChennai.addEventListener("click", () => {
                const predTabBtn = document.getElementById("tab-btn-prediction");
                if (predTabBtn) predTabBtn.click();
                const btnPreset = document.getElementById("preset-basin-chennai");
                if (btnPreset) btnPreset.click();
            });
        }

        const cardWayanad = document.getElementById("card-alert-wayanad");
        if (cardWayanad) {
            cardWayanad.addEventListener("click", () => {
                const predTabBtn = document.getElementById("tab-btn-prediction");
                if (predTabBtn) predTabBtn.click();
                const btnPreset = document.getElementById("preset-basin-wayanad");
                if (btnPreset) btnPreset.click();
            });
        }

        const cardAssam = document.getElementById("card-alert-assam");
        if (cardAssam) {
            cardAssam.addEventListener("click", () => {
                const predTabBtn = document.getElementById("tab-btn-prediction");
                if (predTabBtn) predTabBtn.click();
                const btnPreset = document.getElementById("preset-basin-assam");
                if (btnPreset) btnPreset.click();
            });
        }

        const cardEsp32 = document.getElementById("card-alert-esp32");
        if (cardEsp32) {
            cardEsp32.addEventListener("click", () => {
                const capTabBtn = document.getElementById("tab-btn-capture");
                if (capTabBtn) capTabBtn.click();
                const consoleCard = document.querySelector(".esp32-console-card");
                if (consoleCard) consoleCard.scrollIntoView({ behavior: "smooth" });
            });
        }

        // Clear stale expired local storage caches from earlier sessions
        try {
            const cached = localStorage.getItem("aegis_countdowns_cache");
            if (cached) {
                const parsed = JSON.parse(cached);
                let allOld = true;
                for (const k in parsed) {
                    if (parsed[k].targetTimestamp > Date.now()) allOld = false;
                }
                if (allOld) {
                    localStorage.removeItem("aegis_countdowns_cache");
                    localStorage.removeItem("aegis_primary_target_ts");
                }
            }
        } catch (e) { }

        // Initialize Persistent Countdown Engine (Module 6)
        syncPersistentCountdowns().then(() => {
            updateEarlyWarningCountdown();
        });

        // Immediately fetch early warnings data on load
        fetchEarlyWarnings(true);

        // Update countdown every second (1000ms) for high-accuracy display
        setInterval(updateEarlyWarningCountdown, 1000);
        // Periodically sync persistent timestamps from backend every 10 seconds
        setInterval(syncPersistentCountdowns, 10000);
    }

    // ==========================================================================
    // PERSISTENT EVENT COUNTDOWN ENGINE (Module 6)
    // Fixed target timestamps stored in backend/countdowns.json & cached locally.
    // Accurate across browser closure, laptop shutdown, and reboot.
    // Ticks every 1000ms. Displays "EVENT TIME REACHED" at 0s. Zero clock drift.
    // ==========================================================================

    let persistentCountdowns = {};
    let isCountdownFetching = false;

    async function syncPersistentCountdowns() {
        if (isCountdownFetching) return;
        isCountdownFetching = true;
        try {
            const res = await fetch(`${API_BASE}/countdowns`);
            if (res.ok) {
                const data = await res.json();
                if (data.countdowns && Array.isArray(data.countdowns)) {
                    data.countdowns.forEach(cd => {
                        persistentCountdowns[cd.id] = cd;
                    });
                    localStorage.setItem("aegis_countdowns_cache", JSON.stringify(persistentCountdowns));
                }
            }
        } catch (e) {
            const cached = localStorage.getItem("aegis_countdowns_cache");
            if (cached) {
                try {
                    persistentCountdowns = JSON.parse(cached);
                } catch (err) { }
            }
        } finally {
            isCountdownFetching = false;
        }
    }

    function formatCountdownDiff(diffMs) {
        if (diffMs <= 0) {
            return {
                isExpired: true,
                text: "EVENT TIME REACHED",
                html: `<span class="event-time-reached" style="color:#ef4444; font-weight:800; animation: livePulse 1.2s infinite;"><i class="fa-solid fa-triangle-exclamation"></i> EVENT TIME REACHED</span>`,
                badgeText: "EVENT REACHED",
                hrs: 0, mins: 0, secs: 0
            };
        }

        const pad = (n) => String(n).padStart(2, '0');
        const hrs = Math.floor(diffMs / 3600000);
        const mins = Math.floor((diffMs % 3600000) / 60000);
        const secs = Math.floor((diffMs % 60000) / 1000);

        return {
            isExpired: false,
            text: `${hrs}h ${pad(mins)}m ${pad(secs)}s remaining`,
            html: `<i class="fa-solid fa-stopwatch" style="margin-right: 4px; animation: livePulse 1s infinite;"></i> ${hrs}h ${pad(mins)}m ${pad(secs)}s remaining`,
            badgeText: `T-${hrs}:${pad(mins)}:${pad(secs)}`,
            hrs, mins, secs
        };
    }

    function updateEarlyWarningCountdown() {
        const now = Date.now();

        // 1. Primary Top Banner Countdown (Chennai Inundation EW-TN-30H or EW-TN-48H)
        const primaryCd = persistentCountdowns["EW-TN-30H"] || persistentCountdowns["EW-TN-48H"];
        let primaryTarget = primaryCd ? primaryCd.targetTimestamp : null;

        if (!primaryTarget || primaryTarget <= now) {
            const stored = localStorage.getItem("aegis_primary_target_ts");
            if (stored && parseInt(stored, 10) > now && (parseInt(stored, 10) - now) <= (32 * 3600 * 1000)) {
                primaryTarget = parseInt(stored, 10);
            } else {
                primaryTarget = now + (29 * 3600 + 58 * 60 + 20) * 1000;
                localStorage.setItem("aegis_primary_target_ts", primaryTarget);
            }
        }

        const primaryDiff = primaryTarget - now;
        const bannerInfo = formatCountdownDiff(primaryDiff);

        const el = document.getElementById("early-warning-countdown");
        if (el) {
            el.innerHTML = bannerInfo.html;
        }

        // 2. Individual Card Countdown Badges (Each advisory has its own persistent targetTimestamp)
        document.querySelectorAll(".card-countdown-badge").forEach(badge => {
            const id = badge.getAttribute("data-countdown-id");
            let targetTs = parseInt(badge.getAttribute("data-target-ts"), 10);

            if (id && persistentCountdowns[id]) {
                targetTs = persistentCountdowns[id].targetTimestamp;
            }

            if (!targetTs || isNaN(targetTs)) {
                targetTs = primaryTarget;
            }

            const cardDiff = targetTs - now;
            const cardInfo = formatCountdownDiff(cardDiff);

            if (cardInfo.isExpired) {
                badge.style.background = "rgba(239, 68, 68, 0.15)";
                badge.style.borderColor = "rgba(239, 68, 68, 0.6)";
                badge.style.color = "#ef4444";
                badge.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> RE-ARMING LIVE...`;
            } else {
                badge.style.background = "rgba(16, 185, 129, 0.15)";
                badge.style.borderColor = "rgba(16, 185, 129, 0.5)";
                badge.style.color = "#10b981";
                badge.innerHTML = `<i class="fa-solid fa-clock" style="animation: livePulse 1.5s infinite;"></i> ${cardInfo.badgeText}`;
            }
        });
    }

    function showSmsCopyToast() {
        const toast = document.getElementById("sms-copy-toast");
        if (toast) {
            toast.style.display = "inline";
            setTimeout(() => { toast.style.display = "none"; }, 2500);
        }
    }

    async function fetchEarlyWarnings(force = false) {
        const now = Date.now();
        // Throttle to every 8 seconds unless forced
        if (!force && (now - lastEarlyWarningSync < 8000)) return;
        lastEarlyWarningSync = now;

        try {
            const res = await fetch(`${API_BASE}/early-warning`);
            if (res.ok) {
                const data = await res.json();
                earlyWarningData = data;
                renderEarlyWarnings(data);
            }
        } catch (e) {
            console.warn("Could not fetch early-warning API", e);
        }
    }

    function renderEarlyWarnings(data) {
        if (!data || !data.advisories) return;

        // 1. Update KPI numbers
        const totalPopEl = document.getElementById("evac-kpi-total-pop");
        const targetEvacEl = document.getElementById("evac-kpi-target-evac");
        if (totalPopEl) totalPopEl.innerText = data.totalVulnerablePopulation ? data.totalVulnerablePopulation.toLocaleString() : "550,000";
        if (targetEvacEl) targetEvacEl.innerText = data.totalTargetEvacuation ? data.totalTargetEvacuation.toLocaleString() : "72,500";

        // 2. Update Top Banner with primary advisory
        const primary = data.advisories[0];
        const bannerText = document.getElementById("banner-early-warning-text");
        if (bannerText && primary) {
            bannerText.innerHTML = `
            <strong>${primary.leadTimeHours}H ADVANCE WARNING:</strong> High Probability (${primary.probability}%) ${primary.hazardType} in <strong>${primary.zone}</strong>. Mandatory Evacuation Advisory in effect.
        `;
        }

        // 3. Render Warning Cards
        const container = document.getElementById("evac-cards-container");
        if (!container) return;

        container.innerHTML = "";

        data.advisories.forEach((adv, idx) => {
            const isCritical = adv.severity === "CRITICAL";
            const cardClass = isCritical ? "evac-alert-card critical" : "evac-alert-card high";

            // Build Trigger Indicators HTML
            let indicatorsHtml = "";
            if (adv.triggerIndicators) {
                indicatorsHtml = adv.triggerIndicators.map(ind => `<div><i class="fa-solid fa-gauge-high" style="color:#ea580c; margin-right:6px;"></i>${ind}</div>`).join("");
            }

            // Build Priority Groups HTML
            let priorityGroupsHtml = "";
            if (adv.priorityGroups) {
                priorityGroupsHtml = adv.priorityGroups.map(pg => `
                <div style="display:flex; justify-content:space-between; font-size:11px; padding:3px 0; border-bottom:1px dashed #e2e8f0;">
                    <span style="color:#475569;">${pg.group}:</span>
                    <strong style="color:#0f172a;">${pg.count.toLocaleString()} people</strong>
                </div>
            `).join("");
            }

            // Build Shelters HTML
            let sheltersHtml = "";
            if (adv.safeShelters) {
                sheltersHtml = adv.safeShelters.map(s => `
                <div class="shelter-card">
                    <div class="shelter-title">
                        <span><i class="fa-solid fa-shield-halved" style="margin-right:6px;"></i>${s.name}</span>
                        <span style="font-size:11px; background:#ecfdf5; color:#059669; padding:2px 6px; border-radius:4px; font-weight:600;">Safe Elev: ${s.elevation}</span>
                    </div>
                    <div class="shelter-meta">
                        <span><i class="fa-solid fa-users"></i> Capacity: <strong>${s.capacity.toLocaleString()}</strong></span>
                        <span><i class="fa-solid fa-phone"></i> ${s.contactOfficer}</span>
                    </div>
                    <div style="font-size:11px; color:#64748b; margin-top:2px;">
                        Facilities: ${s.facilities.join(" • ")}
                    </div>
                </div>
            `).join("");
            }

            const card = document.createElement("div");
            card.className = cardClass;
            card.innerHTML = `
            <div class="evac-card-header">
                <div>
                    <div class="evac-zone-title">
                        <i class="fa-solid fa-triangle-exclamation" style="color:${isCritical ? '#dc2626' : '#ea580c'};"></i>
                        ${adv.zone}
                    </div>
                    <div style="font-size:12px; color:var(--text-muted); margin-top:4px;">
                        ${adv.region} • <strong>${adv.hazardType}</strong>
                    </div>
                </div>
                <div style="text-align:right;">
                    <span class="evac-leadtime-badge card-countdown-badge" data-countdown-id="${adv.id || ''}" data-target-ts="${adv.targetTimestamp || ''}">
                        <i class="fa-solid fa-clock"></i> T-30:00:00
                    </span>
                </div>
            </div>

            <div class="evac-card-body">
                <!-- Probability Bar -->
                <div>
                    <div style="display:flex; justify-content:space-between; font-size:12px; font-weight:600; margin-bottom:4px;">
                        <span>Probability of Impact: <strong style="color:${isCritical ? '#dc2626' : '#ea580c'};">${adv.probability}%</strong></span>
                        <span style="font-size:11px; color:#64748b;">Target: ${adv.targetDate}</span>
                    </div>
                    <div style="background:#e2e8f0; height:8px; border-radius:4px; overflow:hidden;">
                        <div style="background:${isCritical ? '#dc2626' : '#ea580c'}; width:${adv.probability}%; height:100%; border-radius:4px;"></div>
                    </div>
                </div>

                <!-- 10-Year Kaggle Recurrence Insight -->
                <div style="background:rgba(2,132,199,0.05); border-left:3px solid #0284c7; padding:8px 12px; border-radius:4px; font-size:11px; color:#0369a1; line-height:1.4;">
                    <strong><i class="fa-solid fa-brain"></i> 10-Year Kaggle Recurrence Pattern:</strong> ${adv.pastRecurrencePattern}
                </div>

                <!-- Environmental Triggers -->
                <div class="evac-indicators-list">
                    <div style="font-weight:700; color:#1e293b; margin-bottom:2px; font-size:11px; text-transform:uppercase;">Precursor Thresholds Exceeded:</div>
                    ${indicatorsHtml}
                </div>

                <!-- Priority Groups -->
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:6px; padding:10px 12px;">
                    <div style="font-size:11px; font-weight:700; color:#1e293b; margin-bottom:6px; text-transform:uppercase;">
                        Immediate Priority Evacuation (${adv.priorityEvacuationCount.toLocaleString()} Citizens):
                    </div>
                    ${priorityGroupsHtml}
                </div>

                <!-- Safe Shelters -->
                <div>
                    <div style="font-size:11px; font-weight:700; color:#1e293b; margin-bottom:6px; text-transform:uppercase;">
                        Designated Safe High-Ground Shelters:
                    </div>
                    ${sheltersHtml}
                </div>
            </div>

            <div class="evac-actions">
                <button type="button" class="btn-evac-map" id="btn-map-${idx}">
                    <i class="fa-solid fa-route"></i> Plot Evacuation Corridors on Map
                </button>
                <button type="button" class="btn-evac-sms" id="btn-sms-${idx}">
                    <i class="fa-solid fa-tower-broadcast"></i> Citizen SMS Broadcast
                </button>
                <button type="button" class="btn-evac-deploy" id="btn-deploy-${idx}">
                    <i class="fa-solid fa-truck-ramp-box"></i> Pre-Stage Logistics (${adv.logisticsDeployment.evacuationBuses} Buses)
                </button>
            </div>
        `;

            container.appendChild(card);

            // Bind Card Action Buttons
            document.getElementById(`btn-map-${idx}`).addEventListener("click", () => {
                plotEvacuationOnMap(adv);
            });

            document.getElementById(`btn-sms-${idx}`).addEventListener("click", () => {
                openSmsModal(adv);
            });

            document.getElementById(`btn-deploy-${idx}`).addEventListener("click", () => {
                prestageEvacuationLogistics(adv);
            });
        });
    }

    function openSmsModal(adv) {
        const modal = document.getElementById("sms-broadcast-modal");
        if (!modal) return;

        const enText = document.getElementById("modal-sms-en-text");
        const taText = document.getElementById("modal-sms-ta-text");

        if (enText && adv.citizenAdvisoryNotice) enText.value = adv.citizenAdvisoryNotice.english || "";
        if (taText && adv.citizenAdvisoryNotice) taText.value = adv.citizenAdvisoryNotice.tamil || "";

        modal.classList.remove("hidden");
    }

    function prestageEvacuationLogistics(adv) {
        const buses = adv.logisticsDeployment.evacuationBuses || 30;
        const boats = adv.logisticsDeployment.rescueBoats || 10;
        const rations = adv.logisticsDeployment.foodWaterRations || 15000;

        // Show temporary confirmation
        alert(`✅ Logistics Pre-Staging Activated for ${adv.zone}!\n\n• ${buses} Evacuation Transit Buses deployed to assembly points.\n• ${boats} Inflatable Rescue Boats stationed along flood buffer.\n• ${rations.toLocaleString()} Rations & Water Packets stocked at designated relief shelters.\n• 120 NDRF Personnel mobilized.`);
    }

    function plotEvacuationOnMap(advisory) {
        // 1. Switch to Tactical Map Tab
        const tacticalTab = document.getElementById("tab-btn-tactical");
        if (tacticalTab) tacticalTab.click();

        if (!map) return;

        // 2. Clear old evacuation layers
        if (evacDangerCircle) {
            map.removeLayer(evacDangerCircle);
            evacDangerCircle = null;
        }
        evacShelterMarkers.forEach(m => map.removeLayer(m));
        evacShelterMarkers = [];
        evacRouteLayers.forEach(l => map.removeLayer(l));
        evacRouteLayers = [];

        // 3. Draw danger threat zone circle
        evacDangerCircle = L.circle([advisory.lat, advisory.lng], {
            color: '#dc2626',
            fillColor: '#ef4444',
            fillOpacity: 0.32,
            radius: 3500,
            weight: 2
        }).addTo(map);

        evacDangerCircle.bindPopup(`
        <div style="font-family:var(--font-body); padding:4px;">
            <div style="font-weight:700; color:#dc2626; font-size:13px; margin-bottom:4px;">⚠️ ${advisory.hazardType} [PROJECTED]</div>
            <div style="font-size:12px; color:#1e293b; margin-bottom:4px;"><strong>Zone:</strong> ${advisory.zone}</div>
            <div style="font-size:11px; color:#475569;"><strong>Probability:</strong> ${advisory.probability}% | <strong>Priority Evacuation:</strong> ${advisory.priorityEvacuationCount.toLocaleString()} citizens</div>
        </div>
    `);

        // 4. Place Safe High-Ground Shelters
        const shelterIcon = L.divIcon({
            className: 'custom-shelter-pin',
            html: `<div style="background:#059669; color:#fff; border-radius:50%; width:34px; height:34px; display:flex; align-items:center; justify-content:center; box-shadow:0 0 12px rgba(5,150,105,0.7); border:2px solid #ffffff; cursor:pointer;"><i class="fa-solid fa-shield-halved" style="font-size:15px;"></i></div>`,
            iconSize: [34, 34],
            iconAnchor: [17, 17]
        });

        const bounds = L.latLngBounds([[advisory.lat, advisory.lng]]);

        if (advisory.safeShelters) {
            advisory.safeShelters.forEach(s => {
                const marker = L.marker([s.lat, s.lng], { icon: shelterIcon }).addTo(map);
                marker.bindPopup(`
                <div style="font-family:var(--font-body); padding:6px; min-width:220px;">
                    <div style="font-size:13px; font-weight:700; color:#059669; margin-bottom:4px;"><i class="fa-solid fa-building-shield"></i> ${s.name}</div>
                    <div style="font-size:11px; color:#1e293b; margin-bottom:3px;"><strong>Safe Elevation:</strong> ${s.elevation}</div>
                    <div style="font-size:11px; color:#1e293b; margin-bottom:3px;"><strong>Capacity:</strong> ${s.capacity} persons (Occupancy: ${s.currentOccupancy || 0})</div>
                    <div style="font-size:11px; color:#475569; margin-bottom:4px;"><strong>Officer:</strong> ${s.contactOfficer}</div>
                    <div style="font-size:10px; color:#059669; background:#ecfdf5; padding:3px 6px; border-radius:4px; margin-top:4px;">✅ Facilities: ${s.facilities.join(', ')}</div>
                </div>
            `);
                evacShelterMarkers.push(marker);
                bounds.extend([s.lat, s.lng]);
            });
        }

        // 5. Draw Evacuation Corridors
        if (advisory.evacuationRoutes) {
            advisory.evacuationRoutes.forEach(r => {
                if (r.waypoints && r.waypoints.length > 1) {
                    const line = L.polyline(r.waypoints, {
                        color: '#059669',
                        weight: 5,
                        opacity: 0.9,
                        className: 'leaflet-evac-route'
                    }).addTo(map);

                    line.bindTooltip(`🚶‍♂️ ${r.name}: ${r.pathDescription}`, { sticky: true });
                    evacRouteLayers.push(line);
                    r.waypoints.forEach(pt => bounds.extend(pt));
                }
            });
        }

        map.fitBounds(bounds, { padding: [60, 60] });

        // Show banner on Tactical map
        const banner = document.getElementById("global-alert-banner");
        if (banner) {
            banner.className = "alert-banner";
            banner.querySelector(".alert-text").innerHTML = `
            <i class="fa-solid fa-person-walking-arrow-right" style="margin-right: 8px; color: #10b981;"></i>
            <strong>EVACUATION CORRIDORS ACTIVE:</strong> Showing safe high-ground shelters & transit routes for <strong>${advisory.zone}</strong>.
        `;
        }
    }

    function handleCsvUpload(file) {
        const statusEl = document.getElementById("csv-upload-status");
        if (statusEl) {
            statusEl.style.display = "block";
            statusEl.style.color = "#0284c7";
            statusEl.innerText = `Reading "${file.name}"...`;
        }

        const reader = new FileReader();
        reader.onload = async (e) => {
            const text = e.target.result;
            try {
                const resp = await fetch(`${API_BASE}/upload-dataset`, {
                    method: "POST",
                    headers: { "Content-Type": "text/plain" },
                    body: text
                });
                if (resp.ok) {
                    const result = await resp.json();
                    if (statusEl) {
                        statusEl.style.color = "#059669";
                        statusEl.innerHTML = `✅ Successfully merged <strong>${result.recordsAdded}</strong> new disaster records! Total Database: <strong>${result.totalRecords}</strong> events. Recalculating models...`;
                    }
                    syncData();
                    fetchEarlyWarnings(true);
                } else {
                    throw new Error("Server rejected CSV data");
                }
            } catch (err) {
                if (statusEl) {
                    statusEl.style.color = "#dc2626";
                    statusEl.innerText = `❌ Error uploading CSV: ${err.message}. Ensure columns match Kaggle standard.`;
                }
            }
        };
        reader.readAsText(file);
    }