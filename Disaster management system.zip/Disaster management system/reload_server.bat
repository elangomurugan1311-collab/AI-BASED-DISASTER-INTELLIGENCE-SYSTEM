@echo off
echo ==================================================================
echo      Aegis Disaster Intelligence System - Instant Server Reload
echo ==================================================================

echo [1/4] Stopping any existing backend/frontend server processes...
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":8080" ^| findstr "LISTENING"') do (
    echo Stopping old process PID %%a on port 8080...
    taskkill /f /pid %%a >nul 2>&1
)
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":8000" ^| findstr "LISTENING"') do (
    echo Stopping old process PID %%a on port 8000...
    taskkill /f /pid %%a >nul 2>&1
)
timeout /t 1 >nul

echo [2/4] Recompiling Java DisasterServer...
javac backend\DisasterServer.java
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Compilation failed! Please check DisasterServer.java syntax.
    pause
    exit /b 1
)

echo [3/4] Launching Java Backend Server on port 8080...
start "Aegis Java Backend" java backend.DisasterServer

echo [4/4] Launching Python Frontend Web Server on port 8000...
start "Aegis Frontend Web Server" cmd /c "cd frontend && python -m http.server 8000"

timeout /t 2 >nul
echo [OK] Opening refreshed dashboard in default browser...
start http://localhost:8000/index.html

echo ==================================================================
echo [SUCCESS] Both servers cleanly reloaded and running!
echo Backend:  http://localhost:8080/api/hazards
echo Frontend: http://localhost:8000/index.html
echo ==================================================================
pause
