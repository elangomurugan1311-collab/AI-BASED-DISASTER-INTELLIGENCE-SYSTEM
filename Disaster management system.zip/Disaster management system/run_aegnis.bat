﻿@echo off
echo ===============================================================================
echo AegisAI - Multimodal Disaster Intelligence ^& Emergency Decision Support
echo ===============================================================================
echo Starting AegisAI Streamlit Dashboard...
echo.
python -m streamlit run app.py
pause

