@echo off
echo ===============================================================================
echo Opening Disaster Management System in VS Code and starting Streamlit Dashboard
echo ===============================================================================
echo.
echo 1. Opening VS Code Workspace...
call code "c:\Users\ADMIN\Disaster management system" -g "app.py:1"
echo 2. Launching Streamlit Dashboard (Port 8501)...
python -m streamlit run app.py --server.port 8501
pause