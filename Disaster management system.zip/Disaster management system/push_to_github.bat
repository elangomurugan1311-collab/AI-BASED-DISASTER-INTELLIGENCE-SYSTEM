@echo off
title Push to GitHub - Disaster Intelligence System
color 0b
echo ========================================================
echo    Pushing AI Disaster Intelligence System to GitHub
echo ========================================================
echo.
echo Target Repository: https://github.com/shyam365-ai/disaster-management-system.git
echo Target Branch: main
echo.
echo Pushing files...
git push -u origin main
echo.
if %ERRORLEVEL% EQU 0 (
    color 0a
    echo ========================================================
    echo    SUCCESS! Files uploaded to GitHub!
    echo    Vercel is now automatically building your dashboard.
    echo    Check: https://disaster-management-system-snowy.vercel.app/
    echo ========================================================
) else (
    color 0c
    echo ========================================================
    echo    Push encountered an issue.
    echo    Please check the message above.
    echo ========================================================
)
echo.
pause
