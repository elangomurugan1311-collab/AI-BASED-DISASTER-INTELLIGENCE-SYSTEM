export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const now = Date.now();

  return res.status(200).json({
    status: "success",
    timestamp: new Date().toISOString(),
    totalVulnerablePopulation: 550000,
    totalTargetEvacuation: 72500,
    totalSheltersActive: 7,
    advisories: [
      {
        id: "EW-TN-48H",
        zone: "Chennai (Velachery, Madipakkam & Pallikaranai Delta)",
        region: "Tamil Nadu & Coromandel Coast",
        hazardType: "Flash Flood / Coastal Tidal Surge",
        probability: 94,
        severity: "CRITICAL",
        leadTimeHours: 48,
        targetDate: "T-48h Advance Horizon",
        targetTimestamp: now + 172800000,
        triggerIndicators: [
          "10-Year Kaggle Recurrence Pattern Match (2016, 2020, 2023 cyclonic surges)",
          "48h cumulative precipitation forecast: 215.0 mm exceeds drainage capacity",
          "Pallikaranai Marsh retention capacity at 94% saturation"
        ],
        priorityGroups: [
          { group: "Elderly & Mobility-Impaired", count: 18500 },
          { group: "Infants & Young Children", count: 24000 },
          { group: "Ground-Floor & Lowland Dwellers", count: 30000 }
        ],
        safeShelters: [
          {
            name: "Guru Nanak College Relief Camp (Velachery High Rd)",
            capacity: 6500,
            elevation: "18.5m MSL",
            contactOfficer: "Inspector M. Anand (+91 94440 12345)",
            facilities: ["Water Purification", "Emergency Power", "Doctor On-Duty"]
          },
          {
            name: "Tambaram Community Relief Center",
            capacity: 4500,
            elevation: "24.0m MSL",
            contactOfficer: "Sub-Collector K. Priya (+91 94440 67890)",
            facilities: ["Maternity Ward", "Hot Meal Kitchen", "Satellite Phone"]
          }
        ]
      },
      {
        id: "EW-KL-36H",
        zone: "Wayanad (Meppadi, Chooralmala & Mundakkai Slopes)",
        region: "Kerala & Western Ghats",
        hazardType: "Debris Flow & Landslide",
        probability: 88,
        severity: "CRITICAL",
        leadTimeHours: 36,
        targetDate: "T-36h Advance Horizon",
        targetTimestamp: now + 129600000,
        triggerIndicators: [
          "Wayanad Tea Plantation geological fracture telemetry",
          "Soil saturation index reached 92% pore-water pressure",
          "Steep 45° incline runoff velocity exceeds safety threshold"
        ],
        priorityGroups: [
          { group: "Plantation Labour Settlements", count: 14000 },
          { group: "Hillside Roadside Habitations", count: 12500 }
        ],
        safeShelters: [
          {
            name: "Meppadi St. Joseph Higher Secondary Camp",
            capacity: 3500,
            elevation: "780m MSL (Flat Ridge)",
            contactOfficer: "Tahsildar R. Nair (+91 94470 54321)",
            facilities: ["Blankets & Cots", "Helipad Access", "Emergency Trauma Unit"]
          }
        ]
      },
      {
        id: "EW-AS-24H",
        zone: "Assam (Majuli Island & Brahmaputra Lowlands)",
        region: "Assam & North-East",
        hazardType: "Riverbank Inundation Surge",
        probability: 82,
        severity: "HIGH",
        leadTimeHours: 24,
        targetDate: "T-24h Advance Horizon",
        targetTimestamp: now + 86400000,
        triggerIndicators: [
          "Brahmaputra stage at Nimati Ghat exceeded danger mark by 1.2m",
          "Majuli sandbank embankment breach alert",
          "Catchment rainfall in Arunachal upstream recorded at 185 mm"
        ],
        priorityGroups: [
          { group: "River Island Tribal Habitations", count: 28000 },
          { group: "Livestock & Farmer Families", count: 15000 }
        ],
        safeShelters: [
          {
            name: "Garamur Central High School Relief Center",
            capacity: 5000,
            elevation: "88m MSL",
            contactOfficer: "District Project Officer S. Gogoi (+91 94350 98765)",
            facilities: ["Rescue Zodiacs", "Dry Rations Supply", "Solar Power"]
          }
        ]
      }
    ]
  });
}
