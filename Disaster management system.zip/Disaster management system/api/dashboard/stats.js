export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const query = req.query || {};
  const year = query.year || "All";
  const type = query.type || "All";
  const region = query.region || "All";

  return res.status(200).json({
    status: "success",
    filterCriteria: { year, type, region },
    filteredCount: 63,
    totalHazardsInDb: 63,
    totalAffectedPopulation: 34500000,
    totalDamageCostCr: 1248.5,
    severityBreakdown: {
      CRITICAL: 22,
      HIGH: 31,
      MEDIUM: 10,
      LOW: 0
    }
  });
}
