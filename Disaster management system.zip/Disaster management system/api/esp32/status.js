﻿// Vercel serverless function for /api/esp32/status
export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  return res.status(200).json({
    status: "success",
    hardwareGateway: "ESP32-AEGIS-IN-01",
    firmwareVersion: "v2.4-FreeRTOS-AlertLatching",
    sensors: {
      waterLevelCm: 42.5,
      rainfallRateMmHr: 12.0,
      soilMoisturePct: 52.0,
      temperatureC: 28.5
    },
    alertState: {
      isCritical: false,
      redLed: false,
      greenLed: true,
      buzzerBeepCycleMs: 4000,
      buzzerBeepDurationMs: 250,
      buzzerMuted: false,
      audibleAlarmActive: false
    },
    rulesConfig: {
      criticalWaterLevelCm: 150.0,
      criticalRainfallMmHr: 45.0,
      criticalSoilMoisturePct: 90.0,
      autoResetClearWaterLevelCm: 100.0,
      autoResetClearRainfallMmHr: 20.0
    },
    scientificNotice: "Sensor observations measure micro-scale physical phenomena; basin-wide forecasts require synoptic radar integration."
  });
}
