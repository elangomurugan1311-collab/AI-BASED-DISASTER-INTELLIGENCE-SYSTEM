export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const now = Date.now();
  // Persistent 48-Hour baseline targets
  const countdowns = {
    "EW-TN-48H": {
      id: "EW-TN-48H",
      zone: "Chennai (Velachery, Madipakkam & Pallikaranai Delta)",
      hazardType: "Flash Flood / Coastal Tidal Surge",
      targetTimestamp: now + 172800000,
      leadTimeHours: 48,
      severity: "CRITICAL",
      description: "T-48h Advance Evacuation Advisory based on CWC/IMD antecedent runoff"
    },
    "EW-KL-36H": {
      id: "EW-KL-36H",
      zone: "Wayanad (Meppadi, Chooralmala & Mundakkai Slopes)",
      hazardType: "Debris Flow & Landslide",
      targetTimestamp: now + 129600000,
      leadTimeHours: 36,
      severity: "CRITICAL",
      description: "Steep terrain pore-pressure threshold breached"
    },
    "EW-AS-24H": {
      id: "EW-AS-24H",
      zone: "Assam (Majuli Island & Brahmaputra Lowlands)",
      hazardType: "Riverbank Inundation Surge",
      targetTimestamp: now + 86400000,
      leadTimeHours: 24,
      severity: "HIGH",
      description: "Brahmaputra bankfull discharge exceeded by 18%"
    }
  };

  return res.status(200).json({
    status: "success",
    systemTimestamp: now,
    persistenceEngine: "Vercel-Serverless-ZeroDrift",
    countdowns: countdowns,
    scientificSafetyNotice: "Demonstration timers for simulation and rehearsal purposes."
  });
}
