export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const query = req.query || {};
  const rainfall = parseFloat(query.rainfall) || 215.0;
  const soil = parseFloat(query.soil) || 88.0;
  const river = parseFloat(query.river) || 94.0;
  const slope = parseFloat(query.slope) || 6.5;
  const history = parseInt(query.history) || 21;

  // Multi-factor formula
  const iRain = Math.min(100.0, (rainfall / 240.0) * 100.0);
  const iSoil = Math.min(100.0, soil);
  const iRiver = Math.min(100.0, (river / 100.0) * 100.0);
  const iTerrain = slope < 15.0 ? Math.min(100.0, ((15.0 - slope) / 15.0) * 100.0) : Math.max(5.0, (1.0 - (slope / 150.0)) * 30.0);
  const iHist = Math.min(100.0, (history / 20.0) * 100.0);

  const score = (0.35 * iRain) + (0.25 * iSoil) + (0.20 * iRiver) + (0.15 * iTerrain) + (0.05 * iHist);

  let category = "LOW";
  let alert = "GREEN (MONITORING)";
  if (score >= 80.0) {
    category = "CRITICAL";
    alert = "RED ALERT (MANDATORY EVACUATION)";
  } else if (score >= 65.0) {
    category = "HIGH";
    alert = "ORANGE ADVISORY (STANDBY EVACUATION)";
  } else if (score >= 45.0) {
    category = "MODERATE";
    alert = "YELLOW WATCH";
  }

  const evidence = [];
  if (rainfall >= 120.0) evidence.push(`48h cumulative rainfall of ${rainfall.toFixed(1)} mm surpasses IMD critical threshold`);
  if (soil >= 80.0) evidence.push(`Catchment soil saturation at ${soil.toFixed(1)}% inhibits infiltration`);
  if (river >= 90.0) evidence.push(`River/drainage conduits operating at ${river.toFixed(1)}% bankfull capacity`);
  if (slope <= 10.0) evidence.push(`Lowland elevation of ${slope.toFixed(1)}m delays gravity drainage`);
  if (evidence.length === 0) evidence.push("Hydrological observations within normal non-critical baselines.");

  const actions = [
    "Relocate vulnerable populations (elderly, infants, ground-floor dwellers) to high-ground shelters",
    "Pre-position NDRF zodiac rescue teams and inflatable boats at low-lying ward junctions",
    "Suspend power substations in flooded basements to prevent electrocution hazards",
    "Keep municipal emergency helpline 1070/112 staffed 24/7 with satellite wireless backups"
  ];

  return res.status(200).json({
    status: "success",
    modelDesignator: "Calibrated Multi-Factor Hydrological Flood Engine (v2.4)",
    methodology: "Physics-based Hydrological Index combining antecedent precipitation, catchment saturation, and elevation hydraulics",
    targetCity: "Chennai (Velachery / Pallikaranai Delta)",
    region: "Tamil Nadu & Coromandel Coast",
    hydrologicalParameters: {
      forecastRainfall48hMm: rainfall,
      soilSaturationPct: soil,
      elevationAboveMslM: slope,
      riverStageDangerPct: river,
      basinHistoricalEventsCount: history
    },
    subIndices: {
      rainfallVulnerability: parseFloat(iRain.toFixed(1)),
      soilSaturationRunoff: parseFloat(iSoil.toFixed(1)),
      topographicDepressionRisk: parseFloat(iTerrain.toFixed(1)),
      fluvialDrainageBackwater: parseFloat(iRiver.toFixed(1)),
      historicalRecurrenceWeight: parseFloat(iHist.toFixed(1))
    },
    floodRiskScore: parseFloat(score.toFixed(1)),
    severityCategory: category,
    officialAlert: alert,
    triggerEvidence: evidence,
    precautionaryActions: actions,
    scientificNotice: "Hydrological rule-based model calibrated on CWC & IMD guidelines."
  });
}
