import time
import random
import requests

# Threshold Values
WATER_THRESHOLD = 80.0  # cm (Higher water = Flood risk)
SOIL_THRESHOLD = 30.0   # % (Lower stability = Landslide risk)

def send_alert(disaster_type, severity, value):
    print(f"\n🚨 [CRITICAL ALERT] {disaster_type} Detected! Severity: {severity} | Sensor Value: {value}")
    # Example: Telegram / Webhook integration for real-time mobile notification
    # webhook_url = "YOUR_WEBHOOK_OR_TELEGRAM_API"
    # requests.post(webhook_url, json={"message": f"ALERT: {disaster_type}"})

def run_disaster_monitor():
    print("🌐 AntiGravity Disaster Early Warning System Started...\n")
    print("Monitoring Live Sensor Streams (Press Ctrl+C to stop)...")
    print("-" * 60)
    
    while True:
        # Simulating live hardware inputs
        water_level = round(random.uniform(10.0, 100.0), 2)
        soil_moisture = round(random.uniform(10.0, 60.0), 2)
        
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] Water Level: {water_level}cm | Soil Stability: {soil_moisture}%")
        
        # Real-time Evaluation Logic
        if water_level > WATER_THRESHOLD:
            send_alert("FLOOD RISK", "HIGH", f"{water_level}cm")
        
        if soil_moisture < SOIL_THRESHOLD:
            send_alert("LANDSLIDE RISK", "MODERATE", f"{soil_moisture}%")
            
        time.sleep(2) # Reads data every 2 seconds

if __name__ == "__main__":
    run_disaster_monitor()
