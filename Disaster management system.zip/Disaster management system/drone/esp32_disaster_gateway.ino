/**
 * AEGIS-AI: ESP32-S3 Node Autonomous Early-Warning Gateway
 * Architecture: Sensors -> ESP32-S3 Node -> Local Alert Unit / Validation & Transmission -> History & Risk -> Dashboard
 * Status Path: Normal -> Warning -> Critical
 * 
 * Hardware Architecture:
 * - Microcontroller: ESP32-S3 (Dual-Core Xtensa LX7, Wi-Fi 2.4GHz + BLE 5)
 * - 1. Sensors:
 *     - Water Level: HC-SR04 Ultrasonic (Trig=GPIO 5, Echo=GPIO 17)
 *     - Rain Gauge: Tipping Bucket Pulse (GPIO 16, Interrupt Edge)
 *     - Soil Moisture: Capacitive Probe (GPIO 34, ADC1)
 *     - Ambient: DHT11 Temp & Relative Humidity (GPIO 25)
 * - 2. Local Alert Unit:
 *     - Green Heartbeat LED: GPIO 19 (Normal status pulse)
 *     - Red Emergency LED: GPIO 18 (Warning blinking / Critical latch)
 *     - Piezo Buzzer / Siren: GPIO 23 (2.4kHz acoustic alarm, 250ms beep every 4s)
 *     - Hardware Mute Button: GPIO 4 (Debounced interrupt)
 * - 3. Validation & Transmission:
 *     - Protocol: Wi-Fi REST HTTP JSON Uplink to Java Backend (port 8080)
 */

  Hardware:
  1. ESP32-WROOM-32
  2. DHT11 Temperature & Humidity Sensor
  3. Active Buzzer

  Functions:
  - Temperature Monitoring
  - Humidity Monitoring
  - Normal / Warning / Critical Status
  - Local Buzzer Alert
  - WiFi Connectivity
  - JSON Transmission to Java Backend
*/

#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>

// ============== PIN CONFIGURATION ==============

// ================= STATUS PATH ENUM =================
enum StatusPath {
  STATUS_NORMAL,    // Green LED, Baseline limits
  STATUS_WARNING,   // Green + Red blink, Precursor alert
  STATUS_CRITICAL   // Red LED solid + Piezo Siren, Evacuation
};

// ================= THRESHOLD CONSTANTS =================
// Warning Thresholds
const float WARN_WATER_LEVEL_CM = 105.0;
const float WARN_RAIN_RATE_MM_HR = 22.0;
const float WARN_SOIL_MOISTURE_PCT = 75.0;

// Critical Thresholds
const float CRITICAL_WATER_LEVEL_CM = 150.0;
const float CRITICAL_RAIN_RATE_MM_HR = 45.0;
const float CRITICAL_SOIL_MOISTURE_PCT = 90.0;

// Hysteresis Clearing Thresholds
const float CLEAR_WATER_LEVEL_CM = 95.0;
const float CLEAR_RAIN_RATE_MM_HR = 18.0;
const float CLEAR_SOIL_MOISTURE_PCT = 70.0;

// ================= TIMING CONSTANTS (NON-BLOCKING) =================
const unsigned long BUZZER_CYCLE_MS = 4000;         // 4 seconds cycle
const unsigned long BUZZER_BEEP_DURATION_MS = 250;  // 250ms piercing beep
const unsigned long TELEMETRY_INTERVAL_MS = 3000;   // 3 seconds HTTP JSON sync
const unsigned long SENSOR_POLL_INTERVAL_MS = 1000; // 1 second sample tick
const unsigned long HEARTBEAT_INTERVAL_MS = 1000;   // 1 second green pulse

// ============== WIFI CONFIGURATION ==============

// ================= STATE VARIABLES =================
volatile StatusPath currentStatusPath = STATUS_NORMAL;
volatile bool buzzerMuted = false;
volatile unsigned long lastButtonInterruptTime = 0;
volatile unsigned long rainPulseCount = 0;

const char* BACKEND_URL =
"http://192.168.1.100:8080/api/esp32/telemetry";
bool redBlinkState = false;

// Current Sensor Readings (HC-SR04, Rain, Soil, DHT11)
// ============== THRESHOLDS ==============
float currentHumidityPct = 65.0;

// ================= INTERRUPT SERVICE ROUTINES =================
void IRAM_ATTR handleMuteButtonISR() {
  unsigned long now = millis();
  if (now - lastButtonInterruptTime > 250) { // 250ms debounce
    if (currentStatusPath == STATUS_CRITICAL || currentStatusPath == STATUS_WARNING) {
      buzzerMuted = true;
      digitalWrite(PIN_PIEZO_BUZZER, LOW);
    }
    lastButtonInterruptTime = now;
  }
}

const float HUM_WARNING = 80.0;
const float HUM_CRITICAL = 90.0;

// ============== TIMING ==============

unsigned long lastSensorRead = 0;
unsigned long lastTelemetry = 0;
unsigned long lastBuzzerCycle = 0;

const unsigned long SENSOR_INTERVAL = 2000;
const unsigned long TELEMETRY_INTERVAL = 3000;

const unsigned long BUZZER_INTERVAL = 4000;
const unsigned long BUZZER_DURATION = 250;

// ============== SENSOR VALUES ==============

float temperature = 0;
float humidity = 0;

String statusPath = "Normal";

bool sensorValid = false;

// ============== SETUP ==============

void setup() {

  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(BUZZER_PIN, LOW);

  dht.begin();

  Serial.println();
  Serial.println("================================");
  Serial.println("       AEGIS-AI SYSTEM");
  Serial.println("   ESP32-WROOM-32 NODE IN-01");
  Serial.println("================================");

  Serial.println("[SYSTEM] Initializing DHT11...");
  
  Serial.println("[SYSTEM] Buzzer initialized.");

  WiFi.mode(WIFI_STA);

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.println("[SYSTEM] Connecting to WiFi...");

}

// ============== SENSOR MONITORING ==============

  long duration = pulseIn(PIN_ECHO, HIGH, 30000);
  if (duration == 0) return currentWaterLevelCm;
  float distance = (duration * 0.0343) / 2.0;
  float stageLevel = 250.0 - distance; // Sensor mounted at 250cm
  if (stageLevel < 0) stageLevel = 0;
  return stageLevel;
}

float readSoilMoisturePercentage() {
  int rawAdc = analogRead(PIN_SOIL_ADC);
  float pct = (1.0 - ((float)(rawAdc - 1200) / (4095.0 - 1200.0))) * 100.0;
  if (pct < 0.0) pct = 0.0;
  if (pct > 100.0) pct = 100.0;
  return pct;
}

void evaluateHazardThresholds() {
  // Check Critical State
  if (currentWaterLevelCm >= CRITICAL_WATER_LEVEL_CM ||
      currentRainRateMmHr >= CRITICAL_RAIN_RATE_MM_HR ||
      currentSoilMoisturePct >= CRITICAL_SOIL_MOISTURE_PCT) {
    currentStatusPath = STATUS_CRITICAL;
    digitalWrite(PIN_RED_LED, HIGH); // Solid RED
    digitalWrite(PIN_GREEN_LED, LOW);
  }
  // Check Warning State
  else if (currentWaterLevelCm >= WARN_WATER_LEVEL_CM ||
           currentRainRateMmHr >= WARN_RAIN_RATE_MM_HR ||
           currentSoilMoisturePct >= WARN_SOIL_MOISTURE_PCT) {
    currentStatusPath = STATUS_WARNING;
  }
  // Check Normal State with Hysteresis
  else {
    if (currentWaterLevelCm < CLEAR_WATER_LEVEL_CM &&
        currentRainRateMmHr < CLEAR_RAIN_RATE_MM_HR &&
        currentSoilMoisturePct < CLEAR_SOIL_MOISTURE_PCT) {
      currentStatusPath = STATUS_NORMAL;
      buzzerMuted = false;
      digitalWrite(PIN_RED_LED, LOW);
      digitalWrite(PIN_PIEZO_BUZZER, LOW);
    }

    if (currentMillis - lastBuzzerCycle <
        BUZZER_DURATION) {

      digitalWrite(BUZZER_PIN, HIGH);

    }

    else {

      digitalWrite(BUZZER_PIN, LOW);

    }

  }

  else {

    digitalWrite(BUZZER_PIN, LOW);

  }

}

// ================= SETUP =================
void setup() {
  Serial.begin(115200);
  Serial.println(F("[AEGIS ESP32-S3] Initializing Node IN-01..."));
  Serial.println(F("[BLOCK DIAGRAM] Sensors -> ESP32-S3 -> Local Alert -> Transmission -> Risk"));

void checkWiFi() {

  if (WiFi.status() == WL_CONNECTED) {

    Serial.print("[WIFI] Connected. IP: ");

    Serial.println(WiFi.localIP());

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.println(F("[AEGIS ESP32-S3] Wi-Fi initialized. Ready for JSON transmission."));
}

// ================= NON-BLOCKING LOOP =================
void loop() {
  unsigned long currentMillis = millis();

void sendTelemetry() {

  if (WiFi.status() != WL_CONNECTED ||
      !sensorValid) {
    currentRainRateMmHr = rainPulseCount * 0.2 * 3600.0 / (SENSOR_POLL_INTERVAL_MS / 1000.0);
    rainPulseCount = 0;

  HTTPClient http;

  http.begin(BACKEND_URL);

  http.addHeader(
    "Content-Type",
    "application/json"
  );

  String jsonPayload = "{";

  jsonPayload += "\"node\":\"AEGIS-IN-01\",";

  jsonPayload += "\"temperatureC\":";
  jsonPayload += String(temperature, 1);
  jsonPayload += ",";

  jsonPayload += "\"humidityPct\":";
  jsonPayload += String(humidity, 1);
  jsonPayload += ",";

  jsonPayload += "\"statusPath\":\"";
  jsonPayload += statusPath;
  jsonPayload += "\"";

  jsonPayload += "}";

  Serial.println("[JSON] Sending Telemetry...");

  int httpCode = http.POST(jsonPayload);

  if (httpCode > 0) {

    Serial.print("[UPLINK] HTTP Response: ");

    Serial.println(httpCode);

  }

  // 2. LOCAL ALERT UNIT ACTUATION
  if (currentStatusPath == STATUS_CRITICAL) {
    digitalWrite(PIN_GREEN_LED, LOW);
    digitalWrite(PIN_RED_LED, HIGH);

    if (!buzzerMuted) {
      unsigned long cycleElapsed = (currentMillis - lastBuzzerCycleStart) % BUZZER_CYCLE_MS;
      if (cycleElapsed < BUZZER_BEEP_DURATION_MS) {
        digitalWrite(PIN_PIEZO_BUZZER, HIGH);
      } else {
        digitalWrite(PIN_PIEZO_BUZZER, LOW);
      }
    } else {
      digitalWrite(PIN_PIEZO_BUZZER, LOW);
    }
  } else if (currentStatusPath == STATUS_WARNING) {
    // Green solid, Red blinking (500ms)
    digitalWrite(PIN_GREEN_LED, HIGH);
    if (currentMillis % 500 < 250) {
      digitalWrite(PIN_RED_LED, HIGH);
    } else {
      digitalWrite(PIN_RED_LED, LOW);
    }
    digitalWrite(PIN_PIEZO_BUZZER, LOW);
  } else {
    // Normal: Green 1Hz heartbeat pulse, Red OFF, Buzzer OFF
    digitalWrite(PIN_RED_LED, LOW);
    digitalWrite(PIN_PIEZO_BUZZER, LOW);
    if (currentMillis - lastHeartbeatTime >= HEARTBEAT_INTERVAL_MS) {
      lastHeartbeatTime = currentMillis;
      greenLedState = !greenLedState;
      digitalWrite(PIN_GREEN_LED, greenLedState ? HIGH : LOW);
    }
  }

  // 3. VALIDATION & TRANSMISSION (Wi-Fi · HTTP · JSON)
  if (WiFi.status() == WL_CONNECTED && (currentMillis - lastTelemetryTime >= TELEMETRY_INTERVAL_MS)) {
    lastTelemetryTime = currentMillis;

  controlBuzzer();

    String statusStr = (currentStatusPath == STATUS_CRITICAL) ? "Critical" : ((currentStatusPath == STATUS_WARNING) ? "Warning" : "Normal");

    String jsonPayload = "{";
    jsonPayload += "\"node\":\"ESP32-S3 Node\",";
    jsonPayload += "\"waterLevelCm\":" + String(currentWaterLevelCm, 1) + ",";
    jsonPayload += "\"rainfallRateMmHr\":" + String(currentRainRateMmHr, 1) + ",";
    jsonPayload += "\"soilMoisturePct\":" + String(currentSoilMoisturePct, 1) + ",";
    jsonPayload += "\"temperatureC\":" + String(currentTemperatureC, 1) + ",";
    jsonPayload += "\"humidityPct\":" + String(currentHumidityPct, 1) + ",";
    jsonPayload += "\"statusPath\":\"" + statusStr + "\",";
    jsonPayload += "\"mute\":" + String(buzzerMuted ? "true" : "false");
    jsonPayload += "}";

    int httpCode = http.POST(jsonPayload);
    if (httpCode > 0) {
      Serial.println(F("[UPLINK SUCCESS] JSON telemetry transmitted to Java Backend."));
    }

  }

}