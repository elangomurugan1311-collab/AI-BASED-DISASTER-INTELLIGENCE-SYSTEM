# Aegis - Disaster Management System with Drone Monitoring

Aegis is an integrated disaster management and response coordination platform. It utilizes a **Java REST Backend**, a **Python Drone Simulation & Ground Control GUI**, and a **Modern Web Dashboard** to simulate real-time aerial disaster reconnaissance, automated risk detection, and resource allocation.

---

## System Architecture

1. **Java Backend Server** (`backend/DisasterServer.java`):
   - A zero-dependency REST API server built using Java's native `com.sun.net.httpserver.HttpServer`.
   - Coordinates drone telemetries, hazard notifications, dispatch commands, and resource distribution logistics.
2. **Python Drone Simulator & Ground Control** (`drone/drone_simulator.py`):
   - A Python Ground Control GUI built using `tkinter`.
   - Simulates a drone flight physics model, updates telemetry parameters (altitude, GPS, battery), and includes a mock infrared sensor camera feed with automated hazard recognition.
   - Syncs real-time updates to the backend and polls for dispatch commands via HTTP requests.
3. **Command Dashboard** (`frontend/index.html`, `style.css`, `app.js`):
   - A glowing dark-themed web application utilizing glassmorphism aesthetics.
   - Renders a Leaflet.js-based tactical map, tracks drone locations, handles manual/map-click dispatches, displays active alerts, and offers a resource allocation manager.
   - Plays a synthesized browser audio warning siren upon detection of new critical incidents.

---

## Getting Started

### Prerequisites
- **Java Development Kit (JDK 8 or higher)** installed.
- **Python 3.x** installed.
  - *Note:* The Python script uses only standard library modules (`tkinter`, `urllib`, `json`, `math`, `random`, `time`, `threading`), requiring **zero** third-party package installations (`pip`).
- A modern web browser (Chrome, Edge, Firefox, or Safari).

---

## Launch Instructions

To launch the system, open three command prompt/terminal windows or run the applications in the background:

### Step 1: Start the Java Backend
Navigate to the root directory `Disaster management system` and run:
```bash
# Compile the Java Server
javac backend/DisasterServer.java

# Run the Server
java backend.DisasterServer
```
You should see: `Disaster Management System Java Backend running on port 8080`.

### Step 2: Start the Python Drone Ground Control
In a new terminal window, run:
```bash
python drone/drone_simulator.py
```
A **Ground Control Station** Tkinter window will open and display:
- **Telemetry Readout** (Drone ID, Latitude, Longitude, Battery, Altitude, Speed, Current Mission state).
- **Radar Telemetry Matrix Canvas** (displays home base, drone location, active target path, and a rotating sweep animation).
- **Multispectral Infrared Camera Canvas** (simulates real-time video feed and heat hazard boundary boxes).
- **Manual Overrides** (buttons to force Patrolling, Return-To-Base, or report manual hazards).

### Step 3: Launch the Command Dashboard
Simply open the `frontend/index.html` file in your web browser.
- Double-click the file or drag and drop it into a browser tab.
- The dashboard will load a tactical map.
- The top-right status bar should glow green indicating `SERVER LINK: ACTIVE`.
- You will see live drone cards showing state updates synced with the Python simulator.

---

## E2E Simulation Walkthrough

1. **Observe Synchronized Telemetry:**
   - Look at the web dashboard and the Python Ground Control GUI. Observe the latitude/longitude and battery percentages updating synchronously in real-time.
2. **Dispatch the Drone via Web Dashboard:**
   - Select `Drone-1 (Active Sim)` in the **Rapid Deployment Controller** select box.
   - Click any location on the map. The input boxes will automatically fill with the clicked coordinate points.
   - Alternatively, enter a latitude/longitude manually (e.g. `40.7188` and `-74.0080`).
   - Click **Dispatch Drone Unit**.
3. **Observe the Flight:**
   - Watch the Python Ground Control radar canvas. The drone marker will turn blue, align itself towards the target, and fly step-by-step.
   - The web dashboard will update the drone's position in real-time on the map and set its status badge to `DISPATCHED`.
4. **Trigger Hazard Scan:**
   - Once the drone reaches the target coordinate, it will halt, descend to scanning altitude, and initiate an infrared scan.
   - After a 2-second scan, it will locate a thermal anomaly (e.g. **FIRE**), highlight it with a red bounding box on the infrared camera canvas, and automatically transmit the disaster report.
5. **Acknowledge the Crisis:**
   - The web dashboard will immediately receive the report.
   - A critical hazard warning siren will play through your speakers.
   - A red flashing warning modal will cover the screen showing the hazard description.
   - Click **Acknowledge Alert** to clear the modal. A glowing hazard marker will remain on the map.
6. **Distribute Relief Logistics:**
   - Go to the **Relief Resource Logistics** panel on the web dashboard.
   - Select a resource (e.g., **Medical Kits**), enter an amount to dispatch (e.g., `50`), and click **Allocate**.
   - The inventory ledger will update and show the remaining supplies.
7. **Recall Drone:**
   - In the Python Ground Control GUI, click **Return to Base**. The drone will fly back to HQ coordinates and land, recharging its battery.
